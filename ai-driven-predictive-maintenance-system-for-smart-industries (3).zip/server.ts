import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      system: "AI-Driven Predictive Maintenance System for Smart Industries",
      version: "2.5.0-mini-project",
      timestamp: new Date().toISOString(),
    });
  });

  // REST API Machine endpoints
  app.get("/api/machines", (req, res) => {
    res.json({ status: "success", timestamp: new Date().toISOString() });
  });

  app.post("/api/machines/:id/start", (req, res) => {
    const { id } = req.params;
    res.json({
      status: "success",
      message: `Machine ${id} started`,
      machineStatus: "RUNNING",
      timestamp: new Date().toISOString(),
    });
  });

  app.post("/api/machines/:id/stop", (req, res) => {
    const { id } = req.params;
    res.json({
      status: "success",
      message: `Machine ${id} stopped`,
      machineStatus: "STOPPED",
      timestamp: new Date().toISOString(),
    });
  });

  // Work assignments endpoints
  app.post("/api/work-assignments", (req, res) => {
    const { machineId, durationHours, taskName } = req.body;
    res.json({
      status: "success",
      message: `Work assigned to ${machineId}: ${durationHours}h`,
      assignment: { machineId, durationHours, taskName, timestamp: new Date().toISOString() },
    });
  });

  app.post("/api/work-assignments/redistribute", (req, res) => {
    const { sourceMachineId, targetMachineId, workloadHours } = req.body;
    res.json({
      status: "success",
      message: `Redistributed ${workloadHours}h from ${sourceMachineId} to ${targetMachineId}`,
      timestamp: new Date().toISOString(),
    });
  });

  // Alerts endpoints
  app.get("/api/alerts", (req, res) => {
    res.json({ status: "success", timestamp: new Date().toISOString() });
  });

  app.post("/api/alerts/:id/acknowledge", (req, res) => {
    const { id } = req.params;
    const { workerName } = req.body;
    res.json({
      status: "success",
      message: `Alert ${id} acknowledged by ${workerName || "operator"}`,
      acknowledgedAt: new Date().toISOString(),
    });
  });

  app.post("/api/alerts/:id/resolve", (req, res) => {
    const { id } = req.params;
    const { actionNote } = req.body;
    res.json({
      status: "success",
      message: `Alert ${id} resolved`,
      actionNote,
      resolvedAt: new Date().toISOString(),
    });
  });

  // Worker endpoints
  app.get("/api/workers", (req, res) => {
    res.json({ status: "success", count: 5 });
  });

  app.post("/api/workers/register-device", (req, res) => {
    const { workerId, deviceToken, platform } = req.body;
    res.json({
      status: "success",
      message: `Device registered for ${workerId} on ${platform || "Android"}`,
      deviceToken,
    });
  });

  app.post("/api/notifications/send", (req, res) => {
    const { alertId, title, message, priority } = req.body;
    res.json({
      status: "success",
      message: `Push notification dispatched to 5 on-duty technicians`,
      dispatchStats: {
        sent: 5,
        delivered: 5,
        opened: 0,
        acknowledged: 0,
      },
    });
  });

  // Maintenance endpoints
  app.get("/api/maintenance", (req, res) => {
    res.json({ status: "success" });
  });

  app.post("/api/maintenance/schedule", (req, res) => {
    const { machineId, type, scheduledDate, notes } = req.body;
    res.json({
      status: "success",
      record: {
        id: `MAINT-${Date.now()}`,
        machineId,
        type,
        scheduledDate,
        notes,
        status: "UPCOMING",
      },
    });
  });

  app.post("/api/maintenance/:id/complete", (req, res) => {
    const { id } = req.params;
    res.json({
      status: "success",
      message: `Maintenance ${id} marked as completed`,
      completedDate: new Date().toISOString().split("T")[0],
    });
  });

  // AI Diagnostic endpoint using Gemini API
  app.post("/api/ai/diagnose", async (req, res) => {
    try {
      const { machine, workloadRatio, recentAlerts } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.json({
          source: "local-ml-engine",
          explanation: [
            `Assigned workload of ${((machine?.assignedHours || 2) / (machine?.safeHours || 1) * 100).toFixed(0)}% exceeds safe rated capacity limit.`,
            `Machine health score degraded to ${machine?.healthScore || 48}% due to thermal and mechanical overload stress.`,
            `Cumulative overload count is ${machine?.overloadEvents || 3}, significantly increasing bearing fatigue probability.`,
            `Historical failure telemetry indicates similar stress patterns cause spindle motor stator overheating within 4.2 operating hours.`
          ],
          recommendation: `Immediately halt excessive workload on ${machine?.name || 'Machine'} or initiate Smart Work Redistribution to an under-utilized machine with sufficient capacity buffer.`,
          mttfHours: Math.max(1.2, (machine?.healthScore || 48) * 0.08).toFixed(1),
          failureRiskPercent: Math.min(98, Math.round(((machine?.assignedHours || 2) / (machine?.safeHours || 1)) * 48)),
        });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const prompt = `You are a Chief Industrial Reliability and Predictive Maintenance AI Engineer for a Smart Industrial Factory.
Analyze this machine telemetry and overload status:
- Machine: ${machine?.id} (${machine?.name})
- Type / Function: ${machine?.type || "Industrial Machine"}
- Safe Rated Capacity: ${machine?.safeHours} hours
- Assigned Work Hours: ${machine?.assignedHours} hours (Workload Ratio: ${((machine?.assignedHours / machine?.safeHours) * 100).toFixed(1)}%)
- Health Score: ${machine?.healthScore}%
- Overload Events Recorded: ${machine?.overloadEvents || machine?.historicalOverloadCount || 0}
- Temperature: ${machine?.temperature}°C (Normal: 40-65°C)
- Vibration RMS: ${machine?.vibration} mm/s (Normal: < 2.5 mm/s)
- Total Operating Hours: ${machine?.totalOperatingHours || machine?.operatingHours} hrs

Provide a concise, highly realistic engineering diagnosis in JSON format:
{
  "explanation": [
    "Bullet point 1 detailing why machine is at risk mathematically and mechanically",
    "Bullet point 2 regarding health and thermal/vibration stress",
    "Bullet point 3 regarding historical failure correlation",
    "Bullet point 4 regarding component vulnerability (e.g. bearings, motor coil, hydraulic valve)"
  ],
  "recommendation": "One clear, actionable engineering directive (e.g. redistribute work to Machine X or perform cooling cycle)",
  "mttfHours": "Estimated Mean Time To Failure in hours (e.g. 2.4)",
  "failureRiskPercent": 85
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({
        source: "gemini-3.7-flash",
        ...parsed,
      });
    } catch (error) {
      console.error("AI Diagnose error:", error);
      const { machine } = req.body;
      return res.json({
        source: "local-ml-engine-fallback",
        explanation: [
          `Workload ratio of ${((machine?.assignedHours || 2) / (machine?.safeHours || 1) * 100).toFixed(0)}% exceeds critical safety threshold.`,
          `Elevated mechanical vibration (${machine?.vibration || 4.2} mm/s) and thermal dissipation (${machine?.temperature || 78}°C) detected.`,
          `Historical telemetry matches bearing race defect signature resulting from prolonged load.`,
          `Estimated health reduction penalty applied: -${Math.round(100 - (machine?.healthScore || 50))}% score drop.`
        ],
        recommendation: `Transfer pending task queue to an alternative machine to avert catastrophic spindle breakdown.`,
        mttfHours: "2.1",
        failureRiskPercent: 92,
      });
    }
  });

  // AI Factory Report generator
  app.post("/api/ai/generate-report", async (req, res) => {
    try {
      const { factorySummary } = req.body;
      const apiKey = process.env.GEMINI_API_KEY;

      if (!apiKey) {
        return res.json({
          executiveSummary: "Factory operations are currently stable with proactive predictive interventions preventing unscheduled downtime. Workload distribution algorithms have mitigated 14 potential overload incidents across 10 monitored production assets.",
          keyInsights: [
            "Heavy milling and stamping units (M-01, M-04) require closest capacity monitoring during peak shift cycles.",
            "Average factory availability maintained at 97.4% through dynamic workload redistribution.",
            "Preventative maintenance schedules have reduced mean time to repair (MTTR) by 38%."
          ],
          safetyIndex: 94.2
        });
      }

      const ai = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });

      const prompt = `Generate an Executive Smart Factory Reliability and Predictive Maintenance Report based on these metrics:
${JSON.stringify(factorySummary, null, 2)}

Return JSON format:
{
  "executiveSummary": "A 2-3 sentence executive overview of factory reliability and predictive risk management.",
  "keyInsights": [
    "Insight 1",
    "Insight 2",
    "Insight 3"
  ],
  "safetyIndex": 94.5
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        },
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json(parsed);
    } catch (err) {
      console.error("AI Report error:", err);
      return res.json({
        executiveSummary: "Automated report generated from smart industrial telemetry engine. Predictive maintenance policies have successfully isolated high-risk machine loads.",
        keyInsights: [
          "Dynamic workload redistribution effectively neutralized overload vectors.",
          "Preventative inspection suggested for machines with health ratings under 70%.",
          "Zero uncontained catastrophic mechanical failures recorded in simulated period."
        ],
        safetyIndex: 91.8
      });
    }
  });

  // Vite middleware in dev or static files in prod
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`AI Smart Factory Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
