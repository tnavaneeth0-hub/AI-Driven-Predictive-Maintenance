import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  Sliders,
  Cpu,
  AlertTriangle,
  Flame,
  ShieldCheck,
  Zap,
  CheckCircle2,
  Clock,
  ArrowRight
} from 'lucide-react';
import { PriorityLevel } from '../types';

export const WorkloadEntryPanel: React.FC = () => {
  const {
    machines,
    assignWork,
    selectedMachineId,
    setSelectedMachineId,
    enableAudio
  } = useFactory();

  const [machineId, setMachineId] = useState<string>(selectedMachineId || 'M-01');
  const [durationHours, setDurationHours] = useState<number>(2.0);
  const [taskName, setTaskName] = useState<string>('Standard Production Batch');
  const [workType, setWorkType] = useState<string>('Heavy 5-Axis Milling');
  const [priority, setPriority] = useState<PriorityLevel>('HIGH');
  const [lastAssignedResult, setLastAssignedResult] = useState<{
    machineCode: string;
    hours: number;
    safeHours: number;
    isOverload: boolean;
  } | null>(null);

  const selectedMachine = machines.find((m) => m.id === machineId) || machines[0];
  const safeCapacity = selectedMachine ? selectedMachine.safeHours : 1.0;
  const isOverloaded = durationHours > safeCapacity;
  const overloadRatio = safeCapacity > 0 ? (durationHours / safeCapacity) : 1;
  const overloadPercent = Math.round(overloadRatio * 100);

  const handleAssignWork = (e: React.FormEvent) => {
    e.preventDefault();
    // Unlock audio context so siren plays immediately if overloaded
    enableAudio();

    const result = assignWork(machineId, durationHours, taskName, workType, priority);
    setSelectedMachineId(machineId);

    setLastAssignedResult({
      machineCode: selectedMachine.code,
      hours: durationHours,
      safeHours: safeCapacity,
      isOverload: isOverloaded,
    });
  };

  return (
    <div className="glass-card p-4 sm:p-5 border-cyan-500/30 bg-cyan-500/[0.02] shadow-lg">
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-3 pb-3.5 mb-4 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center shrink-0">
            <Sliders className="w-4 h-4 text-cyan-400" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              Assign Workload to Machine
            </h2>
            <p className="text-[11px] text-slate-400">
              Enter the duration of work to assign. If the work exceeds safe operating capacity, an instant <strong className="text-red-400">Siren Alert & Worker Push Message</strong> will be dispatched automatically.
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleAssignWork} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {/* 1. Machine Selection */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              1. Target Machine
            </label>
            <select
              value={machineId}
              onChange={(e) => {
                setMachineId(e.target.value);
                setSelectedMachineId(e.target.value);
              }}
              className="w-full bg-black/60 border border-white/15 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400 font-mono"
            >
              {machines.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                  {m.code} (Safe Limit: {m.safeHours}h | Currently: {m.assignedHours}h)
                </option>
              ))}
            </select>
          </div>

          {/* 2. Workload Hours Input */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300">
                2. Workload Duration
              </label>
              <span className="text-[10px] font-mono text-cyan-400 font-bold">
                Safe Limit: {safeCapacity}h
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="24"
                value={durationHours}
                onChange={(e) => setDurationHours(parseFloat(e.target.value) || 0)}
                className={`w-full bg-black/60 border text-white rounded-lg px-3 py-2 text-xs font-mono font-bold focus:outline-none ${
                  isOverloaded
                    ? 'border-red-500 text-red-300 focus:border-red-400 bg-red-950/20'
                    : 'border-white/15 focus:border-cyan-400'
                }`}
                required
              />
              <span className="absolute right-3 top-2 text-xs text-slate-400 font-mono">hours</span>
            </div>
          </div>

          {/* 3. Task Name */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              3. Task / Batch Description
            </label>
            <input
              type="text"
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              placeholder="e.g. Turbine Rotor Milling Batch"
              className="w-full bg-black/60 border border-white/15 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400 placeholder:text-slate-600"
              required
            />
          </div>

          {/* 4. Priority */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              4. Shift Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as PriorityLevel)}
              className="w-full bg-black/60 border border-white/15 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
            >
              <option value="NORMAL" className="bg-slate-900 text-slate-200">Normal Priority</option>
              <option value="HIGH" className="bg-slate-900 text-amber-300">High Priority</option>
              <option value="URGENT" className="bg-slate-900 text-red-300">Urgent Priority</option>
            </select>
          </div>
        </div>

        {/* Quick Duration Preset Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-1">
          <span className="text-[10px] text-slate-400 uppercase font-mono">Quick Set:</span>
          <button
            type="button"
            onClick={() => setDurationHours(0.5)}
            className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-[10px] font-mono transition"
          >
            0.5h
          </button>
          <button
            type="button"
            onClick={() => setDurationHours(safeCapacity)}
            className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-[10px] font-mono font-bold transition"
            title={`Set to maximum safe capacity (${safeCapacity}h)`}
          >
            Safe Max ({safeCapacity}h)
          </button>
          <button
            type="button"
            onClick={() => setDurationHours(Number((safeCapacity + 1.0).toFixed(1)))}
            className="px-2 py-0.5 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 border border-red-500/30 text-[10px] font-mono font-bold transition"
            title={`Set to overloaded capacity (${(safeCapacity + 1.0).toFixed(1)}h)`}
          >
            Overload Test ({(safeCapacity + 1.0).toFixed(1)}h)
          </button>
          <button
            type="button"
            onClick={() => setDurationHours(2.0)}
            className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-[10px] font-mono transition"
          >
            2.0h
          </button>
          <button
            type="button"
            onClick={() => setDurationHours(3.0)}
            className="px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-[10px] font-mono transition"
          >
            3.0h
          </button>
        </div>

        {/* Live Validation & Action Bar */}
        <div className={`p-3 rounded-lg border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-all ${
          isOverloaded
            ? 'bg-red-950/30 border-red-500/50 shadow-[0_0_15px_rgba(255,62,62,0.15)]'
            : 'bg-emerald-950/20 border-emerald-500/30'
        }`}>
          <div className="flex items-center gap-2.5">
            {isOverloaded ? (
              <Flame className="w-5 h-5 text-red-400 animate-pulse shrink-0" />
            ) : (
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <div>
              <div className="flex items-center gap-2">
                <span className={`text-xs font-bold font-mono ${isOverloaded ? 'text-red-300' : 'text-emerald-300'}`}>
                  {isOverloaded
                    ? `⚠️ OVERLOAD DETECTED: ${durationHours}h / ${safeCapacity}h (${overloadPercent}%)`
                    : `✓ SAFE WORKLOAD: ${durationHours}h / ${safeCapacity}h (${overloadPercent}%)`}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isOverloaded
                  ? `Entering ${durationHours}h exceeds ${selectedMachine.code}'s safe limit of ${safeCapacity}h. Submitting will trigger the Emergency Audio Siren and send immediate push notifications to all 5 on-duty workers.`
                  : `Workload duration is within the machine's safe rated operating limit.`}
              </p>
            </div>
          </div>

          <button
            type="submit"
            className={`w-full sm:w-auto px-5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center justify-center gap-2 transition shrink-0 ${
              isOverloaded
                ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(255,62,62,0.4)] animate-pulse'
                : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(0,212,255,0.3)]'
            }`}
          >
            {isOverloaded ? (
              <>
                <Flame className="w-4 h-4" />
                <span>Assign Overload & Trigger Siren</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                <span>Assign Safe Workload</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
