import React from 'react';
import { useFactory } from '../context/FactoryContext';
import { Volume2, VolumeX, ShieldAlert, X, ArrowRight, Smartphone, BellRing } from 'lucide-react';

export const SirenBanner: React.FC = () => {
  const {
    isSirenActive,
    stopSiren,
    toggleAudioMute,
    isAudioMuted,
    isAudioUnlocked,
    enableAudio,
    alerts,
    setActiveTab,
    setSelectedMachineId,
    setIsWorkerMobileOpen,
  } = useFactory();

  if (!isSirenActive) {
    // Show one-time prompt to unlock audio if not yet unlocked
    if (!isAudioUnlocked) {
      return (
        <div className="bg-slate-900/90 border-b border-cyan-500/30 px-4 py-2 text-xs text-slate-300 flex items-center justify-between gap-2 z-30">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>
              <strong className="text-white">Emergency Audio Standby:</strong> Click below to enable browser audio siren and acoustic alert notifications.
            </span>
          </div>
          <button
            onClick={enableAudio}
            className="px-3 py-1 bg-cyan-500 hover:bg-cyan-400 text-black font-bold rounded-lg text-[11px] uppercase tracking-wider shadow-[0_0_10px_rgba(0,212,255,0.4)] transition shrink-0"
          >
            🔊 Enable Audio
          </button>
        </div>
      );
    }
    return null;
  }

  const criticalAlert = alerts.find((a) => a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL');

  return (
    <div
      id="siren-emergency-banner"
      className="relative bg-red-950/95 border-y-2 border-red-500 text-white shadow-[0_0_40px_rgba(239,68,68,0.5)] px-4 py-3 z-40 backdrop-blur-xl transition-all duration-300 animate-pulse"
    >
      <div className="w-full max-w-[1850px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Left Side: Strobe Icon & Description */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600 border border-red-400 flex items-center justify-center shadow-[0_0_20px_rgba(239,68,68,0.7)] shrink-0">
            <ShieldAlert className="w-6 h-6 text-white animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-red-500 text-white font-mono text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded shadow">
                🚨 CRITICAL SOFTWARE SIREN ACTIVE
              </span>
              <span className="text-red-200 text-xs font-mono">
                [Modulated 750Hz Industrial Sweep Siren]
              </span>
            </div>
            <p className="text-xs font-bold text-white mt-1">
              {criticalAlert
                ? criticalAlert.title + ': ' + criticalAlert.message
                : 'CRITICAL OVERLOAD: Active machine overload detected! Immediate action required.'}
            </p>
          </div>
        </div>

        {/* Right Side: Action Controls */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            onClick={() => setIsWorkerMobileOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 shadow transition"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Worker Mobile</span>
          </button>

          {criticalAlert && (
            <button
              onClick={() => {
                setSelectedMachineId(criticalAlert.machineId);
                setActiveTab('alerts');
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-white/15 hover:bg-white/25 text-white shadow transition"
            >
              <span>Review Alert</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          <button
            id="siren-mute-toggle-btn"
            onClick={toggleAudioMute}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/20 text-red-200 border border-red-400/30 transition"
            title={isAudioMuted ? 'Unmute Audio Siren' : 'Mute Audio Siren'}
          >
            {isAudioMuted ? <VolumeX className="w-3.5 h-3.5 text-red-300" /> : <Volume2 className="w-3.5 h-3.5 text-white animate-spin" />}
            <span>{isAudioMuted ? 'Unmute' : 'Mute'}</span>
          </button>

          <button
            id="siren-stop-btn"
            onClick={stopSiren}
            className="flex items-center gap-1 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-black/50 hover:bg-black/70 text-white border border-white/20 transition uppercase tracking-wider"
          >
            <X className="w-4 h-4" />
            <span>STOP SIREN</span>
          </button>
        </div>
      </div>
    </div>
  );
};
