import React, { useState, useMemo } from 'react';
import { useFactory } from '../context/FactoryContext';
import { Machine, AlertItem } from '../types';
import { findBestRedistributionTarget } from '../services/predictiveEngine';
import {
  ArrowRight,
  CheckCircle2,
  AlertTriangle,
  Cpu,
  ShieldCheck,
  Zap,
  X,
  Sliders,
  Flame,
  ShieldAlert,
  RotateCcw
} from 'lucide-react';

interface RedistributionModalProps {
  sourceMachine: Machine;
  alert?: AlertItem;
  onClose: () => void;
}

export const RedistributionModal: React.FC<RedistributionModalProps> = ({
  sourceMachine,
  alert,
  onClose,
}) => {
  const { machines, redistributeWork, haltAndInspectMachine } = useFactory();

  // Overload calculations
  const isOverloaded = sourceMachine.assignedHours > sourceMachine.safeHours;
  const excessHours = isOverloaded
    ? Number((sourceMachine.assignedHours - sourceMachine.safeHours).toFixed(1))
    : sourceMachine.assignedHours > 0
    ? sourceMachine.assignedHours
    : 1.0;

  const fullHours = sourceMachine.assignedHours > 0 ? sourceMachine.assignedHours : 1.0;

  // Transfer mode state: 'EXCESS' | 'FULL' | 'CUSTOM'
  const [transferMode, setTransferMode] = useState<'EXCESS' | 'FULL' | 'CUSTOM'>(
    isOverloaded ? 'EXCESS' : 'FULL'
  );
  const [customHours, setCustomHours] = useState<number>(excessHours);

  const transferAmount = useMemo(() => {
    if (transferMode === 'EXCESS') return excessHours;
    if (transferMode === 'FULL') return fullHours;
    return Math.max(0.1, Number(customHours) || 0.1);
  }, [transferMode, excessHours, fullHours, customHours]);

  // AI Recommendation engine evaluated against current transferAmount
  const {
    targetMachine: recommended,
    allCandidates,
    reason,
  } = useMemo(() => {
    return findBestRedistributionTarget(sourceMachine.id, transferAmount, machines);
  }, [sourceMachine.id, transferAmount, machines]);

  // Selected target state (defaults to top recommended candidate)
  const [selectedTargetId, setSelectedTargetId] = useState<string>('');

  // Synchronize target selection if not set or if current selection becomes invalid
  const chosenTargetEval = useMemo(() => {
    if (selectedTargetId) {
      const match = allCandidates.find((c) => c.machine.id === selectedTargetId);
      if (match) return match;
    }
    // Default to best recommended safe target
    if (recommended) {
      return allCandidates.find((c) => c.machine.id === recommended.id) || null;
    }
    return allCandidates.find((c) => c.canAccommodate) || allCandidates[0] || null;
  }, [selectedTargetId, allCandidates, recommended]);

  const chosenTarget = chosenTargetEval?.machine || null;

  // Post-transfer metrics calculation
  const sourceAfterAssigned = sourceMachine.assignedHours > 0
    ? Math.max(0, Number((sourceMachine.assignedHours - transferAmount).toFixed(1)))
    : 0;
  const sourceAfterRatio = sourceMachine.safeHours > 0 ? sourceAfterAssigned / sourceMachine.safeHours : 0;

  const targetAfterTotal = chosenTarget
    ? Number((chosenTarget.assignedHours + transferAmount).toFixed(1))
    : 0;
  const targetAfterRatio = chosenTarget && chosenTarget.safeHours > 0
    ? targetAfterTotal / chosenTarget.safeHours
    : 0;
  const isTargetSafeAfter = chosenTarget ? targetAfterTotal <= chosenTarget.safeHours : false;

  const handleExecute = () => {
    if (!chosenTarget || !isTargetSafeAfter) return;
    redistributeWork(sourceMachine.id, chosenTarget.id, alert?.id, transferAmount);
    onClose();
  };

  const handleHaltSource = () => {
    haltAndInspectMachine(sourceMachine.id, alert?.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="glass-card-dark max-w-2xl w-full p-6 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in duration-200 max-h-[92vh] flex flex-col justify-between overflow-y-auto">
        {/* Glow Accent */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header */}
        <div>
          <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400 shadow-[0_0_10px_rgba(0,212,255,0.2)]">
                <Zap className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  Intelligent Work Balancing Engine
                  <span className="text-[10px] bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 px-2 py-0.5 rounded font-mono font-bold">
                    AI GUARANTEED SAFE
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Dynamically balances workloads without pushing recipient machines into secondary overload.
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-200 p-1.5 rounded-lg hover:bg-white/5"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Transfer Mode Selector Pills */}
          <div className="bg-black/40 border border-white/10 p-2.5 rounded-xl mb-4">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="text-[10px] font-mono uppercase tracking-wider text-slate-300 font-bold">
                Transfer Strategy Mode:
              </span>
              <span className="text-xs font-mono font-bold text-cyan-400">
                Amount to Move: {transferAmount} hrs
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {/* Option 1: Excess Only */}
              <button
                type="button"
                onClick={() => setTransferMode('EXCESS')}
                className={`p-2 rounded-lg border text-left text-xs transition ${
                  transferMode === 'EXCESS'
                    ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_10px_rgba(0,212,255,0.2)]'
                    : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>⚡ Excess Overload</span>
                  <span className="font-mono text-cyan-300">{excessHours}h</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Relieves only the unsafe excess. Keeps source at 100% safe capacity.
                </p>
              </button>

              {/* Option 2: Full Workload */}
              <button
                type="button"
                onClick={() => setTransferMode('FULL')}
                className={`p-2 rounded-lg border text-left text-xs transition ${
                  transferMode === 'FULL'
                    ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_10px_rgba(0,212,255,0.2)]'
                    : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>🔄 Full Batch</span>
                  <span className="font-mono text-cyan-300">{fullHours}h</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Moves entire batch. Sets source machine to safe idle state.
                </p>
              </button>

              {/* Option 3: Custom Slider */}
              <button
                type="button"
                onClick={() => setTransferMode('CUSTOM')}
                className={`p-2 rounded-lg border text-left text-xs transition ${
                  transferMode === 'CUSTOM'
                    ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_10px_rgba(0,212,255,0.2)]'
                    : 'bg-white/[0.02] border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="font-bold flex items-center justify-between">
                  <span>🎚️ Custom Hours</span>
                  <span className="font-mono text-cyan-300">{customHours}h</span>
                </div>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  Manually calibrate transfer quota.
                </p>
              </button>
            </div>

            {transferMode === 'CUSTOM' && (
              <div className="mt-3 pt-2 border-t border-white/5 flex items-center gap-3">
                <input
                  type="range"
                  min="0.1"
                  max={Math.max(5.0, sourceMachine.assignedHours || 5.0)}
                  step="0.1"
                  value={customHours}
                  onChange={(e) => setCustomHours(parseFloat(e.target.value))}
                  className="flex-1 accent-cyan-400 cursor-pointer"
                />
                <span className="font-mono text-xs font-bold text-cyan-400 w-12 text-right">
                  {customHours.toFixed(1)}h
                </span>
              </div>
            )}
          </div>

          {/* Side-by-side Transfer Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            {/* Source Machine Card */}
            <div className="glass-card bg-red-500/5 border-red-500/30 p-3.5">
              <div className="flex items-center justify-between text-xs text-red-300 font-semibold mb-2">
                <span className="text-[10px] uppercase font-bold text-red-400 tracking-wider">
                  Source Machine (Relieved)
                </span>
                <span className="bg-red-500/20 text-red-400 border border-red-500/30 px-1.5 py-0.5 rounded font-mono text-[9px]">
                  {sourceMachine.code}
                </span>
              </div>

              <div className="flex items-center gap-2 mb-2">
                <Cpu className="w-4 h-4 text-red-400" />
                <div className="flex-1 truncate">
                  <h4 className="text-xs font-bold text-white truncate">{sourceMachine.name}</h4>
                  <p className="text-[10px] text-slate-400">Safe Limit: {sourceMachine.safeHours}h</p>
                </div>
              </div>

              <div className="space-y-1 text-xs bg-black/40 p-2 rounded-lg border border-white/5 font-mono">
                <div className="flex justify-between text-slate-400 text-[10px]">
                  <span>Current Assigned:</span>
                  <span className="text-red-400 font-bold">{sourceMachine.assignedHours}h</span>
                </div>
                <div className="flex justify-between text-cyan-300 text-[10px] font-bold">
                  <span>After Balancing:</span>
                  <span className="text-emerald-400">{sourceAfterAssigned}h ({(sourceAfterRatio * 100).toFixed(0)}%)</span>
                </div>
                <div className="flex justify-between text-slate-400 text-[10px]">
                  <span>Health Forecast:</span>
                  <span className="text-emerald-400 font-bold">96% (OPTIMAL)</span>
                </div>
              </div>
            </div>

            {/* Target Machine Card */}
            <div className="glass-card bg-cyan-500/5 border-cyan-400/30 p-3.5">
              <div className="flex items-center justify-between text-xs text-cyan-300 font-semibold mb-2">
                <span className="text-[10px] uppercase font-bold text-cyan-400 tracking-wider">
                  Recipient Machine
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded font-mono text-[9px] font-bold ${
                    isTargetSafeAfter
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse'
                  }`}
                >
                  {isTargetSafeAfter ? 'SAFE ABSORPTION' : 'OVERLOAD RISK'}
                </span>
              </div>

              {chosenTarget ? (
                <>
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="w-4 h-4 text-cyan-400" />
                    <div className="flex-1 truncate">
                      <h4 className="text-xs font-bold text-white truncate">{chosenTarget.code} — {chosenTarget.name}</h4>
                      <p className="text-[10px] text-slate-400">Safe Limit: {chosenTarget.safeHours}h</p>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs bg-black/40 p-2 rounded-lg border border-white/5 font-mono">
                    <div className="flex justify-between text-slate-400 text-[10px]">
                      <span>Current Assigned:</span>
                      <span className="text-slate-200">{chosenTarget.assignedHours}h</span>
                    </div>
                    <div className="flex justify-between text-[10px] font-bold">
                      <span className={isTargetSafeAfter ? 'text-emerald-300' : 'text-red-400'}>
                        After Transfer Total:
                      </span>
                      <span className={isTargetSafeAfter ? 'text-emerald-400' : 'text-red-400'}>
                        {targetAfterTotal}h / {chosenTarget.safeHours}h ({(targetAfterRatio * 100).toFixed(0)}%)
                      </span>
                    </div>
                    <div className="flex justify-between text-slate-400 text-[10px]">
                      <span>Remaining Buffer:</span>
                      <span className={isTargetSafeAfter ? 'text-cyan-400 font-bold' : 'text-red-400'}>
                        {(chosenTarget.safeHours - targetAfterTotal).toFixed(1)}h Headroom
                      </span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-4 text-xs text-amber-400">
                  No candidate machine available.
                </div>
              )}
            </div>
          </div>

          {/* AI Recommendation Explanation Banner */}
          <div className="glass-card bg-black/40 p-3 mb-4 border-white/5">
            <div className="flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
              <div>
                <h5 className="text-[10px] font-bold text-cyan-400 uppercase tracking-wide">
                  AI Dynamic Optimization Directive
                </h5>
                <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">{reason}</p>
              </div>
            </div>

            {/* Target Selector Dropdown with Safety Badges */}
            <div className="mt-3 pt-2.5 border-t border-white/5 flex flex-col sm:flex-row items-center gap-2">
              <label className="text-xs text-slate-400 whitespace-nowrap">Choose Recipient:</label>
              <select
                value={chosenTarget?.id || ''}
                onChange={(e) => setSelectedTargetId(e.target.value)}
                className="bg-black/80 border border-white/10 text-slate-200 text-xs rounded-lg px-3 py-1.5 w-full focus:outline-none focus:border-cyan-400"
              >
                {allCandidates.map((c) => {
                  const label = c.canAccommodate
                    ? `🟢 ${c.machine.code} — ${c.machine.name} (Safe Cap: ${c.machine.safeHours}h | Free: ${(c.remainingSafeBefore).toFixed(1)}h | New: ${(c.projectedRatio * 100).toFixed(0)}%)`
                    : `⛔ ${c.machine.code} — OVERLOAD RISK (Needs ${c.projectedNewTotal}h > ${c.machine.safeHours}h cap)`;
                  return (
                    <option
                      key={c.machine.id}
                      value={c.machine.id}
                      disabled={!c.canAccommodate}
                      className={c.canAccommodate ? 'bg-slate-900 text-slate-100 font-semibold' : 'bg-red-950 text-red-400 opacity-60'}
                    >
                      {label}
                    </option>
                  );
                })}
              </select>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/5">
          {/* Halt Machine (Special handler for Case 2 or emergency stop) */}
          <button
            type="button"
            onClick={handleHaltSource}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-red-500/10 hover:bg-red-500/20 text-red-300 border border-red-500/30 transition uppercase tracking-wider"
            title="Immediately stop this machine safely"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Halt & Clear Source</span>
          </button>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-400 hover:text-slate-200 hover:bg-white/5 transition uppercase tracking-wider"
            >
              Cancel
            </button>
            <button
              id="btn-confirm-redistribute-work"
              type="button"
              onClick={handleExecute}
              disabled={!chosenTarget || !isTargetSafeAfter}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-xs font-bold transition active:scale-95 uppercase tracking-wider ${
                isTargetSafeAfter
                  ? 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.4)] cursor-pointer'
                  : 'bg-slate-800 text-slate-500 border border-white/5 cursor-not-allowed opacity-50'
              }`}
            >
              <span>{isTargetSafeAfter ? 'APPLY SAFE REDISTRIBUTION' : 'SELECT SAFE MACHINE'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
