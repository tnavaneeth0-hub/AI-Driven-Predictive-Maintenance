import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import { Machine } from '../types';
import { calculateWorkloadRatio } from '../services/predictiveEngine';
import { RedistributionModal } from './RedistributionModal';
import { WorkAssignmentModal } from './WorkAssignmentModal';
import {
  Cpu,
  Play,
  Square,
  Plus,
  Sliders,
  Sparkles,
  Zap,
  Clock,
  Flame,
  Activity,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';

interface MachineCardProps {
  machine: Machine;
  onOpenAssign?: (machine: Machine) => void;
  onOpenDiagnose?: (machine: Machine) => void;
}

export const MachineCard: React.FC<MachineCardProps> = ({ machine, onOpenAssign, onOpenDiagnose }) => {
  const {
    setActiveTab,
    setSelectedMachineId,
    startMachine,
    stopMachine,
    simulateMachineOperation,
  } = useFactory();

  const [showRedistributeModal, setShowRedistributeModal] = useState(false);
  const [showAssignModal, setShowAssignModal] = useState(false);

  const workloadRatio = calculateWorkloadRatio(machine.assignedHours, machine.safeHours);
  const workloadPercent = Math.round(workloadRatio * 100);
  const operatingHours = machine.actualOperatingHours || machine.currentOperatingHours || 0;

  // Condition checks
  const isCondition1Overload = machine.assignedHours > machine.safeHours;
  const isCondition2Unassigned = machine.assignedHours === 0 && machine.status === 'RUNNING';
  const isCondition2Critical = isCondition2Unassigned && operatingHours > machine.safeHours;
  const isCondition2Warning = isCondition2Unassigned && operatingHours <= machine.safeHours;

  const isCritical = isCondition1Overload || isCondition2Critical || machine.status === 'CRITICAL' || machine.status === 'OVERLOADED';
  const isHighRisk = machine.riskLevel === 'HIGH_RISK';
  const isCaution = isCondition2Warning || machine.riskLevel === 'CAUTION';

  // Health color styling
  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-emerald-400';
    if (score >= 75) return 'text-cyan-400';
    if (score >= 50) return 'text-amber-400';
    return 'text-red-400';
  };

  // Card border and background styling
  const getCardBorder = () => {
    if (isCritical) {
      return 'border-red-500/60 bg-red-950/20 shadow-[0_0_25px_rgba(255,62,62,0.25)]';
    }
    if (isCondition2Warning) {
      return 'border-amber-500/50 bg-amber-950/20 shadow-[0_0_15px_rgba(245,158,11,0.15)]';
    }
    if (isHighRisk) {
      return 'border-orange-500/40 bg-orange-500/5';
    }
    if (isCaution) {
      return 'border-amber-500/30 bg-amber-500/5';
    }
    return 'border-white/5 bg-white/[0.02] hover:border-cyan-400/30 hover:bg-white/[0.04]';
  };

  return (
    <>
      <div
        id={`machine-card-${machine.id}`}
        className={`glass-card p-4 transition-all duration-200 flex flex-col justify-between relative overflow-hidden backdrop-blur-md ${getCardBorder()}`}
      >
        {/* Top Header */}
        <div>
          <div className="flex items-center justify-between gap-1.5 mb-2">
            <div className="flex items-center gap-1.5">
              <span className="text-[10px] text-slate-300 font-mono font-bold tracking-wider uppercase">
                {machine.code}
              </span>
              <span
                className={`text-[8px] uppercase font-mono px-1.5 py-0.2 rounded font-bold ${
                  isCritical
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40 animate-pulse'
                    : isCondition2Warning
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : isHighRisk
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                    : isCaution
                    ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                    : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                {machine.riskLevel}
              </span>
            </div>

            {/* Status Indicator */}
            <div className="flex items-center gap-1.5">
              <div
                className={`w-2 h-2 rounded-full ${
                  isCritical
                    ? 'indicator-red animate-pulse'
                    : isCondition2Warning
                    ? 'indicator-orange animate-pulse'
                    : machine.status === 'RUNNING'
                    ? 'indicator-green'
                    : 'bg-slate-600'
                }`}
              />
              <span
                className={`text-[9px] font-mono font-bold uppercase tracking-tight ${
                  isCritical ? 'text-red-400' : isCondition2Warning ? 'text-amber-400' : 'text-slate-300'
                }`}
              >
                {machine.status}
              </span>
            </div>
          </div>

          <h3
            className="text-xs font-bold text-white tracking-tight leading-snug line-clamp-1 mb-0.5"
            title={machine.name}
          >
            {machine.name}
          </h3>
          <p className="text-[9px] text-slate-400 uppercase tracking-tight mb-2.5 line-clamp-1">
            {machine.type}
          </p>

          {/* Condition 2 Warning Badge */}
          {isCondition2Warning && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-md p-1.5 mb-2.5 text-[9px] text-amber-300 flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span className="leading-tight">
                <strong>UNASSIGNED:</strong> Operating without an active task assignment.
              </span>
            </div>
          )}

          {/* Condition 2B Critical Badge */}
          {isCondition2Critical && (
            <div className="bg-red-500/15 border border-red-500/40 rounded-md p-1.5 mb-2.5 text-[9px] text-red-300 flex items-center gap-1.5 animate-pulse">
              <ShieldAlert className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="leading-tight">
                <strong>CRITICAL UNASSIGNED:</strong> Operating {operatingHours}h &gt; {machine.safeHours}h safe capacity.
              </span>
            </div>
          )}

          {/* Condition 1 Overload Badge */}
          {isCondition1Overload && (
            <div className="bg-red-500/15 border border-red-500/40 rounded-md p-1.5 mb-2.5 text-[9px] text-red-300 flex items-center gap-1.5 animate-pulse">
              <Flame className="w-3.5 h-3.5 text-red-400 shrink-0" />
              <span className="leading-tight">
                <strong>CRITICAL OVERLOAD:</strong> Assigned {machine.assignedHours}h exceeds {machine.safeHours}h cap ({workloadPercent}%).
              </span>
            </div>
          )}

          {/* Metrics 4-Box Grid */}
          <div className="grid grid-cols-2 gap-1.5 mb-2.5 bg-black/40 border border-white/5 rounded-lg p-2 text-[10px] font-mono">
            <div>
              <span className="text-[8px] uppercase tracking-wider text-slate-400 block">Safe Capacity</span>
              <span className="text-xs font-bold text-emerald-400">{machine.safeHours}h</span>
            </div>

            <div>
              <span className="text-[8px] uppercase tracking-wider text-slate-400 block">Assigned Work</span>
              <span
                className={`text-xs font-bold ${
                  machine.assignedHours > machine.safeHours ? 'text-red-400' : 'text-cyan-400'
                }`}
              >
                {machine.assignedHours}h
              </span>
            </div>

            <div>
              <span className="text-[8px] uppercase tracking-wider text-slate-400 block">Operating Time</span>
              <span
                className={`text-xs font-bold ${
                  operatingHours > machine.safeHours && machine.assignedHours === 0
                    ? 'text-red-400'
                    : 'text-slate-200'
                }`}
              >
                {operatingHours}h
              </span>
            </div>

            <div>
              <span className="text-[8px] uppercase tracking-wider text-slate-400 block">Health / Risk</span>
              <span className={`text-xs font-bold ${getHealthColor(machine.healthScore)}`}>
                {machine.healthScore}% ({machine.riskScore || 0})
              </span>
            </div>
          </div>

          {/* Workload Progress Bar */}
          <div className="mb-2.5">
            <div className="flex justify-between items-center text-[9px] mb-1 font-mono">
              <span className="text-slate-400 uppercase text-[8px] tracking-wider">Workload Capacity</span>
              <span
                className={`font-bold ${
                  workloadPercent > 100
                    ? 'text-red-400'
                    : workloadPercent > 85
                    ? 'text-amber-400'
                    : 'text-emerald-400'
                }`}
              >
                {workloadPercent}%
              </span>
            </div>
            <div className="health-bar w-full">
              <div
                className={`h-full transition-all duration-300 ${
                  workloadPercent > 100
                    ? 'bg-red-500 shadow-[0_0_8px_#ff3e3e]'
                    : workloadPercent > 85
                    ? 'bg-amber-400'
                    : 'bg-emerald-400'
                }`}
                style={{ width: `${Math.min(100, workloadPercent)}%` }}
              />
            </div>
          </div>

          {/* Machine Control Buttons Bar (Start, Stop, Simulate +0.5h) */}
          <div className="flex items-center gap-1 mb-2">
            {machine.status === 'RUNNING' ? (
              <button
                onClick={() => stopMachine(machine.id)}
                className="flex-1 py-1 rounded bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[9px] font-mono font-bold flex items-center justify-center gap-1 transition"
                title="Stop Machine"
              >
                <Square className="w-2.5 h-2.5 fill-amber-400" />
                <span>STOP</span>
              </button>
            ) : (
              <button
                onClick={() => startMachine(machine.id)}
                className="flex-1 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[9px] font-mono font-bold flex items-center justify-center gap-1 transition"
                title="Start Machine"
              >
                <Play className="w-2.5 h-2.5 fill-emerald-400" />
                <span>START</span>
              </button>
            )}

            <button
              onClick={() => simulateMachineOperation(machine.id, 0.5)}
              className="py-1 px-2 rounded bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-[9px] font-mono font-bold flex items-center gap-0.5 transition"
              title="Simulate +0.5 hours runtime"
            >
              <Plus className="w-2.5 h-2.5 text-cyan-400" />
              <span>0.5h</span>
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="pt-2 border-t border-white/5 flex items-center gap-1.5">
          {isCondition1Overload ? (
            <button
              onClick={() => setShowRedistributeModal(true)}
              className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[10px] font-bold bg-red-600/30 hover:bg-red-600/40 text-red-300 border border-red-500/50 shadow-[0_0_12px_rgba(255,62,62,0.25)] transition uppercase tracking-wider"
              title="Redistribute workload to an available machine"
            >
              <Zap className="w-3 h-3" />
              <span>REDISTRIBUTE</span>
            </button>
          ) : (
            <button
              onClick={() => {
                if (onOpenAssign) {
                  onOpenAssign(machine);
                } else {
                  setShowAssignModal(true);
                }
              }}
              className="flex-1 flex items-center justify-center gap-1 py-1.5 rounded-lg text-[10px] font-medium bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 transition uppercase tracking-wider"
            >
              <Sliders className="w-3 h-3 text-cyan-400" />
              <span>Assign Work</span>
            </button>
          )}

          <button
            onClick={() => {
              if (onOpenDiagnose) {
                onOpenDiagnose(machine);
              } else {
                setSelectedMachineId(machine.id);
                setActiveTab('predictions');
              }
            }}
            className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-white/5 hover:bg-white/10 text-cyan-400 border border-cyan-400/30 hover:shadow-[0_0_10px_rgba(0,212,255,0.2)] transition"
            title="AI Predictive Diagnosis & Root Cause"
          >
            <Sparkles className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {showAssignModal && (
        <WorkAssignmentModal
          machine={machine}
          onClose={() => setShowAssignModal(false)}
        />
      )}

      {showRedistributeModal && (
        <RedistributionModal
          sourceMachine={machine}
          onClose={() => setShowRedistributeModal(false)}
        />
      )}
    </>
  );
};
