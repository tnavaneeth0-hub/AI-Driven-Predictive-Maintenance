import React, { useState, useEffect } from 'react';
import { useFactory } from '../context/FactoryContext';
import { MobileScreen, Worker, WorkerNotification } from '../types';
import {
  Smartphone,
  X,
  ShieldAlert,
  Bell,
  CheckCircle2,
  AlertTriangle,
  User,
  Settings,
  ListTodo,
  History,
  Activity,
  Volume2,
  VolumeX,
  Vibrate,
  ArrowLeft,
  ChevronRight,
  LogOut,
  Clock,
  MapPin,
  Cpu,
  Radio,
  Sparkles
} from 'lucide-react';

export const WorkerMobileAppModal: React.FC = () => {
  const {
    isWorkerMobileOpen,
    setIsWorkerMobileOpen,
    workers,
    currentMobileWorker,
    setCurrentMobileWorker,
    alerts,
    workerNotifications,
    openWorkerNotification,
    acknowledgeWorkerNotification,
    workAssignments,
    isSirenActive,
    stopSiren,
  } = useFactory();

  const [currentScreen, setCurrentScreen] = useState<MobileScreen>('dashboard');
  const [selectedNotificationId, setSelectedNotificationId] = useState<string | null>(null);
  const [pushEnabled, setPushEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [vibrationEnabled, setVibrationEnabled] = useState(true);
  const [selectedMobileTask, setSelectedMobileTask] = useState<string | null>(null);

  // Auto-open emergency screen when a new critical alert occurs if phone modal is active
  const activeCriticalAlert = alerts.find((a) => a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL');

  useEffect(() => {
    if (activeCriticalAlert && isWorkerMobileOpen) {
      setCurrentScreen('emergency');
    }
  }, [activeCriticalAlert, isWorkerMobileOpen]);

  if (!isWorkerMobileOpen) return null;

  // Filter notifications for current mobile worker
  const myNotifications = workerNotifications.filter(
    (n) => n.workerId === currentMobileWorker.id || !n.workerId
  );
  const unreadCount = myNotifications.filter((n) => n.status !== 'ACKNOWLEDGED').length;

  // Tasks for this worker or department
  const myTasks = workAssignments.filter((w) => w.status === 'ACTIVE');

  return (
    <div
      id="worker-mobile-app-modal"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200"
    >
      {/* Container with Device Frame and Worker Switcher Header */}
      <div className="relative flex flex-col items-center max-w-lg w-full">
        {/* Top Floating Control Bar */}
        <div className="w-full flex items-center justify-between bg-[#0f172a] border border-cyan-500/30 rounded-t-2xl px-4 py-2 text-white text-xs mb-1">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-cyan-400" />
            <span className="font-bold tracking-wider uppercase text-[11px]">
              Android Worker Companion App
            </span>
            <span className="text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-1.5 py-0.2 rounded font-mono">
              FCM Connected
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Worker Selector */}
            <select
              value={currentMobileWorker.id}
              onChange={(e) => {
                const found = workers.find((w) => w.id === e.target.value);
                if (found) setCurrentMobileWorker(found);
              }}
              className="bg-black/60 border border-white/10 text-cyan-300 text-[11px] rounded px-2 py-0.5 focus:outline-none focus:border-cyan-400 font-mono"
            >
              {workers.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.role.split(' ')[0]})
                </option>
              ))}
            </select>

            <button
              onClick={() => setIsWorkerMobileOpen(false)}
              className="p-1 hover:bg-white/10 rounded-full text-slate-400 hover:text-white transition"
              title="Close Mobile Emulator"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Realistic Android Phone Mockup Frame */}
        <div className="w-[360px] h-[720px] bg-black rounded-[40px] p-3 shadow-[0_0_50px_rgba(0,212,255,0.2)] border-4 border-slate-800 relative flex flex-col overflow-hidden">
          {/* Phone Speaker & Camera Notch */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-full flex items-center justify-center gap-2 z-30">
            <div className="w-10 h-1 bg-slate-700 rounded-full"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-slate-950 border border-slate-800"></div>
          </div>

          {/* Screen Display Area */}
          <div className="w-full h-full bg-[#0a0f1d] rounded-[32px] overflow-hidden flex flex-col text-white relative pt-5 border border-slate-800/80">
            {/* Android Status Bar */}
            <div className="px-4 py-1 flex items-center justify-between text-[10px] text-slate-400 font-mono select-none">
              <span>08:42</span>
              <div className="flex items-center gap-1.5">
                <Radio className="w-3 h-3 text-emerald-400" />
                <span>5G</span>
                <span>88%</span>
              </div>
            </div>

            {/* In-Screen Content Switcher */}
            <div className="flex-1 overflow-y-auto scrollbar-none p-3 pb-16">
              {/* Screen 1: Splash Screen */}
              {currentScreen === 'splash' && (
                <div className="h-full flex flex-col items-center justify-center text-center p-4">
                  <div className="w-16 h-16 rounded-2xl bg-cyan-500 flex items-center justify-center text-black font-black text-2xl shadow-[0_0_20px_rgba(0,212,255,0.6)] mb-4 animate-bounce">
                    AI
                  </div>
                  <h2 className="text-sm font-bold uppercase tracking-wider text-white">
                    Smart Factory Worker
                  </h2>
                  <p className="text-[10px] text-slate-400 mt-1">Predictive Telemetry & Emergency Alerts</p>
                  <button
                    onClick={() => setCurrentScreen('dashboard')}
                    className="mt-6 w-full py-2 bg-cyan-500 text-black font-bold text-xs rounded-xl shadow-[0_0_15px_rgba(0,212,255,0.4)]"
                  >
                    Enter App
                  </button>
                </div>
              )}

              {/* Screen 2: Login Screen */}
              {currentScreen === 'login' && (
                <div className="h-full flex flex-col justify-center p-3">
                  <h3 className="text-sm font-bold text-white mb-1">Worker Authentication</h3>
                  <p className="text-[10px] text-slate-400 mb-4">Select technician ID to log in</p>
                  <div className="space-y-2 mb-4">
                    {workers.map((w) => (
                      <button
                        key={w.id}
                        onClick={() => {
                          setCurrentMobileWorker(w);
                          setCurrentScreen('dashboard');
                        }}
                        className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between text-xs transition ${
                          currentMobileWorker.id === w.id
                            ? 'bg-cyan-500/10 border-cyan-400 text-cyan-300'
                            : 'bg-white/5 border-white/10 text-slate-300'
                        }`}
                      >
                        <div>
                          <div className="font-bold">{w.name}</div>
                          <div className="text-[10px] text-slate-400">{w.role}</div>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Screen 3: Worker Dashboard */}
              {currentScreen === 'dashboard' && (
                <div className="space-y-3 animate-in fade-in duration-150">
                  {/* Worker Header Card */}
                  <div className="bg-gradient-to-br from-slate-900 to-slate-950 p-3 rounded-2xl border border-cyan-500/20 shadow-md">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className="w-9 h-9 rounded-xl bg-cyan-500 text-black font-bold text-xs flex items-center justify-center shadow-[0_0_10px_rgba(0,212,255,0.4)]">
                          {currentMobileWorker.avatarInitials}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold text-white">{currentMobileWorker.name}</h4>
                          <span className="text-[9px] text-cyan-400 font-mono">{currentMobileWorker.role}</span>
                        </div>
                      </div>
                      <span className="w-2 h-2 rounded-full indicator-green" title="Active On Shift" />
                    </div>

                    <div className="grid grid-cols-2 gap-1.5 text-[9px] font-mono text-slate-400 border-t border-white/5 pt-2">
                      <div>Shift: {currentMobileWorker.shift.split(' ')[0]}</div>
                      <div>Dept: {currentMobileWorker.department.split(' ')[0]}</div>
                    </div>
                  </div>

                  {/* Active Emergency Alert Callout (If any) */}
                  {activeCriticalAlert && (
                    <div
                      onClick={() => setCurrentScreen('emergency')}
                      className="bg-red-950/80 border border-red-500 p-3 rounded-2xl shadow-[0_0_20px_rgba(255,62,62,0.4)] cursor-pointer animate-pulse"
                    >
                      <div className="flex items-center gap-2 text-red-400 font-bold text-xs mb-1">
                        <ShieldAlert className="w-4 h-4 text-red-400 animate-bounce" />
                        <span>EMERGENCY MACHINE ALERT</span>
                      </div>
                      <p className="text-[10px] text-red-200 line-clamp-2">{activeCriticalAlert.title}</p>
                      <div className="mt-2 text-right text-[9px] font-bold text-red-400 uppercase tracking-wider flex items-center justify-end gap-1">
                        <span>Tap to Respond</span>
                        <ChevronRight className="w-3 h-3" />
                      </div>
                    </div>
                  )}

                  {/* Quick Status Stats Grid */}
                  <div className="grid grid-cols-2 gap-2">
                    <div
                      onClick={() => setCurrentScreen('tasks')}
                      className="bg-white/5 border border-white/10 p-2.5 rounded-xl cursor-pointer hover:bg-white/10 transition"
                    >
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <span className="text-[9px] uppercase font-mono">Assigned Jobs</span>
                        <ListTodo className="w-3 h-3 text-cyan-400" />
                      </div>
                      <div className="text-base font-bold font-mono text-white">{myTasks.length}</div>
                    </div>

                    <div
                      onClick={() => setCurrentScreen('alerts')}
                      className="bg-white/5 border border-white/10 p-2.5 rounded-xl cursor-pointer hover:bg-white/10 transition"
                    >
                      <div className="flex items-center justify-between text-slate-400 mb-1">
                        <span className="text-[9px] uppercase font-mono">Push Alerts</span>
                        <Bell className="w-3 h-3 text-amber-400" />
                      </div>
                      <div className="text-base font-bold font-mono text-amber-400">{unreadCount}</div>
                    </div>
                  </div>

                  {/* Recent Live Notifications Feed */}
                  <div>
                    <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                      <span>Recent Dispatches</span>
                      <button
                        onClick={() => setCurrentScreen('alerts')}
                        className="text-cyan-400 text-[9px] hover:underline"
                      >
                        View All
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      {myNotifications.slice(0, 3).map((n) => (
                        <div
                          key={n.id}
                          onClick={() => {
                            openWorkerNotification(n.id);
                            if (n.priority === 'CRITICAL') setCurrentScreen('emergency');
                          }}
                          className={`p-2 rounded-xl border text-[10px] cursor-pointer transition ${
                            n.status === 'ACKNOWLEDGED'
                              ? 'bg-white/[0.02] border-white/5 text-slate-400'
                              : 'bg-red-500/10 border-red-500/30 text-white'
                          }`}
                        >
                          <div className="flex items-center justify-between font-bold mb-0.5">
                            <span className="text-red-400">{n.machineCode}</span>
                            <span className="text-[8px] font-mono text-slate-400">{n.sentAt}</span>
                          </div>
                          <p className="line-clamp-1 text-slate-300 text-[9px]">{n.message}</p>
                        </div>
                      ))}
                      {myNotifications.length === 0 && (
                        <div className="text-center py-4 text-[10px] text-slate-500">
                          No active notifications. Fleet status nominal.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Screen 4: Emergency Alert Screen */}
              {currentScreen === 'emergency' && (
                <div className="space-y-3 animate-in zoom-in-95 duration-150">
                  <div className="bg-red-600 p-3 rounded-2xl text-center shadow-[0_0_30px_rgba(255,62,62,0.6)]">
                    <ShieldAlert className="w-8 h-8 text-white mx-auto mb-1 animate-bounce" />
                    <h3 className="text-xs font-black uppercase tracking-wider text-white">
                      EMERGENCY MACHINE ALERT
                    </h3>
                    <p className="text-[9px] text-red-100 font-mono mt-0.5">
                      HIGH-PRIORITY SAFETY DISPATCH
                    </p>
                  </div>

                  {activeCriticalAlert ? (
                    <div className="bg-black/60 border border-red-500/50 p-3 rounded-2xl space-y-2.5">
                      <div className="flex items-center justify-between border-b border-white/10 pb-2">
                        <div>
                          <span className="text-[10px] font-mono font-bold text-red-400">
                            {activeCriticalAlert.machineCode}
                          </span>
                          <h4 className="text-xs font-bold text-white">{activeCriticalAlert.machineName}</h4>
                        </div>
                        <span className="text-[9px] bg-red-500/20 text-red-300 border border-red-500 px-2 py-0.5 rounded font-mono font-bold">
                          CRITICAL
                        </span>
                      </div>

                      <div className="bg-red-950/40 p-2.5 rounded-xl border border-red-500/30 text-[10px] text-slate-200">
                        <p className="font-semibold text-white mb-1">{activeCriticalAlert.title}</p>
                        <p className="text-slate-300 leading-relaxed text-[9px]">{activeCriticalAlert.message}</p>
                      </div>

                      {/* AI Root Cause Bullet Points */}
                      {activeCriticalAlert.aiExplanation && (
                        <div className="bg-white/5 p-2 rounded-xl border border-white/10 text-[9px] space-y-1">
                          <span className="text-cyan-400 font-bold uppercase block text-[8px]">
                            AI Telemetry Diagnostics:
                          </span>
                          {activeCriticalAlert.aiExplanation.map((exp, i) => (
                            <div key={i} className="text-slate-300 flex items-start gap-1">
                              <span>•</span>
                              <span>{exp}</span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Recommendation */}
                      {activeCriticalAlert.aiRecommendation && (
                        <div className="bg-cyan-500/10 p-2 rounded-xl border border-cyan-400/30 text-[9px] text-cyan-300">
                          <strong>Directive:</strong> {activeCriticalAlert.aiRecommendation}
                        </div>
                      )}

                      {/* Action Buttons */}
                      <div className="space-y-1.5 pt-2">
                        <button
                          onClick={() => {
                            acknowledgeWorkerNotification(
                              `NOTIF-${activeCriticalAlert.id}`,
                              currentMobileWorker.name
                            );
                            stopSiren();
                            setCurrentScreen('dashboard');
                          }}
                          className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs rounded-xl shadow-[0_0_15px_rgba(0,255,136,0.4)] uppercase tracking-wider flex items-center justify-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>ACKNOWLEDGE & RESPOND</span>
                        </button>

                        <button
                          onClick={() => setCurrentScreen('dashboard')}
                          className="w-full py-1.5 bg-white/10 text-slate-300 text-[10px] rounded-xl font-medium"
                        >
                          Dismiss to Dashboard
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white/5 border border-white/10 p-6 rounded-2xl text-center text-xs text-slate-400">
                      <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                      <p className="font-bold text-white">No Active Emergency</p>
                      <p className="text-[10px] text-slate-500 mt-1">All monitored machine nodes operating safely.</p>
                      <button
                        onClick={() => setCurrentScreen('dashboard')}
                        className="mt-4 px-4 py-1.5 bg-cyan-500/20 text-cyan-300 text-xs rounded-xl"
                      >
                        Return to Dashboard
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Screen 5: My Tasks Screen */}
              {currentScreen === 'tasks' && (
                <div className="space-y-2.5 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between text-xs font-bold border-b border-white/10 pb-2">
                    <span className="text-white">Active Shift Tasks</span>
                    <span className="text-cyan-400 font-mono text-[10px]">{myTasks.length} Assigned</span>
                  </div>

                  <div className="space-y-2">
                    {myTasks.map((task) => (
                      <div
                        key={task.id}
                        className="bg-white/5 border border-white/10 p-2.5 rounded-xl text-[10px] space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-xs">{task.taskName}</span>
                          <span className="text-[8px] bg-cyan-500/20 text-cyan-300 px-1.5 py-0.2 rounded font-mono">
                            {task.priority}
                          </span>
                        </div>
                        <div className="text-slate-400 font-mono">Node: {task.machineCode}</div>
                        <div className="flex items-center justify-between text-slate-500 text-[9px] pt-1">
                          <span>Duration: {task.durationHours}h</span>
                          <span>ETA: {task.expectedCompletionTime}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Screen 6: Notifications List */}
              {currentScreen === 'alerts' && (
                <div className="space-y-2 animate-in fade-in duration-150">
                  <div className="flex items-center justify-between text-xs font-bold border-b border-white/10 pb-2">
                    <span className="text-white">Push Alert Feed</span>
                    <span className="text-amber-400 text-[10px] font-mono">{unreadCount} Unread</span>
                  </div>

                  <div className="space-y-1.5">
                    {myNotifications.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => {
                          openWorkerNotification(n.id);
                          if (n.priority === 'CRITICAL') setCurrentScreen('emergency');
                        }}
                        className={`p-2.5 rounded-xl border text-[10px] cursor-pointer transition ${
                          n.status === 'ACKNOWLEDGED'
                            ? 'bg-white/[0.02] border-white/5 text-slate-400'
                            : 'bg-red-500/10 border-red-500/40 text-white'
                        }`}
                      >
                        <div className="flex items-center justify-between font-bold mb-1">
                          <span className="text-red-400">{n.machineCode}</span>
                          <span className="text-[8px] font-mono text-slate-400">{n.sentAt}</span>
                        </div>
                        <p className="text-[9px] text-slate-300 leading-snug">{n.message}</p>
                        <div className="mt-1.5 flex items-center justify-between text-[8px] font-mono text-slate-400">
                          <span>Status: {n.status}</span>
                          {n.status !== 'ACKNOWLEDGED' && (
                            <span className="text-emerald-400 font-bold">Tap to Acknowledge</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Screen 7: Alert History */}
              {currentScreen === 'history' && (
                <div className="space-y-2 animate-in fade-in duration-150">
                  <h4 className="text-xs font-bold text-white border-b border-white/10 pb-2">
                    Incident History
                  </h4>
                  <div className="space-y-2">
                    {alerts.map((a) => (
                      <div
                        key={a.id}
                        className="bg-white/5 border border-white/10 p-2.5 rounded-xl text-[10px]"
                      >
                        <div className="flex items-center justify-between font-bold">
                          <span className="text-cyan-300">{a.machineCode}</span>
                          <span
                            className={`text-[8px] font-mono px-1.5 py-0.2 rounded ${
                              a.status === 'RESOLVED'
                                ? 'bg-emerald-500/20 text-emerald-300'
                                : 'bg-red-500/20 text-red-300'
                            }`}
                          >
                            {a.status}
                          </span>
                        </div>
                        <p className="text-[9px] text-slate-400 mt-1">{a.message}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Screen 8: Worker Profile */}
              {currentScreen === 'profile' && (
                <div className="space-y-3 text-center animate-in fade-in duration-150">
                  <div className="w-14 h-14 rounded-2xl bg-cyan-500 text-black font-bold text-xl mx-auto flex items-center justify-center shadow-[0_0_20px_rgba(0,212,255,0.4)]">
                    {currentMobileWorker.avatarInitials}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">{currentMobileWorker.name}</h3>
                    <p className="text-[10px] text-cyan-400 font-mono">{currentMobileWorker.role}</p>
                  </div>
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-3 text-[10px] space-y-2 text-left">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Department:</span>
                      <span className="text-white font-mono">{currentMobileWorker.department}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Shift Schedule:</span>
                      <span className="text-white font-mono">{currentMobileWorker.shift}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Device Token:</span>
                      <span className="text-emerald-400 font-mono text-[8px]">
                        {currentMobileWorker.deviceToken || 'FCM Active'}
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Screen 9: Settings */}
              {currentScreen === 'settings' && (
                <div className="space-y-3 animate-in fade-in duration-150 text-xs">
                  <h4 className="font-bold text-white border-b border-white/10 pb-2">
                    Notification Settings
                  </h4>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between bg-white/5 p-2.5 rounded-xl border border-white/10">
                      <div>
                        <div className="font-bold text-white text-[11px]">Emergency Push</div>
                        <div className="text-[9px] text-slate-400">High priority alert dispatches</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={pushEnabled}
                        onChange={(e) => setPushEnabled(e.target.checked)}
                        className="accent-cyan-500 w-4 h-4"
                      />
                    </div>

                    <div className="flex items-center justify-between bg-white/5 p-2.5 rounded-xl border border-white/10">
                      <div>
                        <div className="font-bold text-white text-[11px]">Audio Siren Chime</div>
                        <div className="text-[9px] text-slate-400">Loud audible buzzer</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={soundEnabled}
                        onChange={(e) => setSoundEnabled(e.target.checked)}
                        className="accent-cyan-500 w-4 h-4"
                      />
                    </div>

                    <div className="flex items-center justify-between bg-white/5 p-2.5 rounded-xl border border-white/10">
                      <div>
                        <div className="font-bold text-white text-[11px]">Haptic Vibration</div>
                        <div className="text-[9px] text-slate-400">Pulsed tactile alarm</div>
                      </div>
                      <input
                        type="checkbox"
                        checked={vibrationEnabled}
                        onChange={(e) => setVibrationEnabled(e.target.checked)}
                        className="accent-cyan-500 w-4 h-4"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Android Navigation Bar */}
            <div className="absolute bottom-0 left-0 right-0 h-14 bg-slate-950/95 border-t border-white/10 px-2 flex items-center justify-around z-20 backdrop-blur-md">
              <button
                onClick={() => setCurrentScreen('dashboard')}
                className={`p-1.5 flex flex-col items-center gap-0.5 text-[8px] font-mono transition ${
                  currentScreen === 'dashboard' ? 'text-cyan-400 font-bold' : 'text-slate-500'
                }`}
              >
                <Activity className="w-4 h-4" />
                <span>Home</span>
              </button>

              <button
                onClick={() => setCurrentScreen('tasks')}
                className={`p-1.5 flex flex-col items-center gap-0.5 text-[8px] font-mono transition ${
                  currentScreen === 'tasks' ? 'text-cyan-400 font-bold' : 'text-slate-500'
                }`}
              >
                <ListTodo className="w-4 h-4" />
                <span>Tasks</span>
              </button>

              <button
                onClick={() => setCurrentScreen('alerts')}
                className={`p-1.5 flex flex-col items-center gap-0.5 text-[8px] font-mono relative transition ${
                  currentScreen === 'alerts' || currentScreen === 'emergency'
                    ? 'text-red-400 font-bold'
                    : 'text-slate-500'
                }`}
              >
                <Bell className="w-4 h-4" />
                <span>Alerts</span>
                {unreadCount > 0 && (
                  <span className="absolute top-0 right-1 w-2 h-2 rounded-full bg-red-500 animate-ping" />
                )}
              </button>

              <button
                onClick={() => setCurrentScreen('profile')}
                className={`p-1.5 flex flex-col items-center gap-0.5 text-[8px] font-mono transition ${
                  currentScreen === 'profile' ? 'text-cyan-400 font-bold' : 'text-slate-500'
                }`}
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </button>

              <button
                onClick={() => setCurrentScreen('settings')}
                className={`p-1.5 flex flex-col items-center gap-0.5 text-[8px] font-mono transition ${
                  currentScreen === 'settings' ? 'text-cyan-400 font-bold' : 'text-slate-500'
                }`}
              >
                <Settings className="w-4 h-4" />
                <span>Config</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
