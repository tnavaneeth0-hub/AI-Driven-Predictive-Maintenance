import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import { Machine, PriorityLevel } from '../types';
import {
  X,
  Sliders,
  Flame,
  ShieldCheck,
  Zap,
  Smartphone,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface WorkAssignmentModalProps {
  machine: Machine;
  onClose: () => void;
}

export const WorkAssignmentModal: React.FC<WorkAssignmentModalProps> = ({ machine, onClose }) => {
  const { assignWork, setIsWorkerMobileOpen, enableAudio } = useFactory();

  const [durationHours, setDurationHours] = useState<number>(machine.assignedHours > 0 ? machine.assignedHours : 2.0);
  const [taskName, setTaskName] = useState<string>(machine.currentTaskName || 'Production Job Batch');
  const [workType, setWorkType] = useState<string>('Standard Precision Machining');
  const [priority, setPriority] = useState<PriorityLevel>('HIGH');

  const safeCapacity = machine.safeHours;
  const isOverloaded = durationHours > safeCapacity;
  const overloadRatio = safeCapacity > 0 ? (durationHours / safeCapacity) : 1;
  const overloadPercent = Math.round(overloadRatio * 100);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    enableAudio();
    assignWork(machine.id, durationHours, taskName, workType, priority);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg glass-card border-white/20 bg-slate-900/95 shadow-2xl p-6 rounded-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center">
              <Sliders className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white uppercase tracking-wider">
                Assign Work: {machine.code}
              </h3>
              <p className="text-xs text-slate-400">
                {machine.name} • Safe Capacity: <strong className="text-emerald-400 font-mono">{machine.safeHours}h</strong>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Workload Duration */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
                Enter Workload (Hours)
              </label>
              <span className="text-xs font-mono text-cyan-400 font-bold">
                Max Safe: {safeCapacity}h
              </span>
            </div>
            <div className="relative">
              <input
                type="number"
                step="0.1"
                min="0.1"
                max="24"
                value={durationHours}
                onChange={(e) => setDurationHours(parseFloat(e.target.value) || 0)}
                className={`w-full bg-black/70 border text-white rounded-lg px-4 py-2.5 text-sm font-mono font-bold focus:outline-none ${
                  isOverloaded
                    ? 'border-red-500 text-red-300 focus:border-red-400 bg-red-950/20'
                    : 'border-white/15 focus:border-cyan-400'
                }`}
                required
              />
              <span className="absolute right-4 top-2.5 text-sm text-slate-400 font-mono">hours</span>
            </div>

            {/* Quick buttons */}
            <div className="flex items-center gap-2 mt-2">
              <button
                type="button"
                onClick={() => setDurationHours(0.5)}
                className="px-2.5 py-1 rounded bg-white/5 hover:bg-white/10 text-slate-300 text-xs font-mono border border-white/10 transition"
              >
                0.5h
              </button>
              <button
                type="button"
                onClick={() => setDurationHours(safeCapacity)}
                className="px-2.5 py-1 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 text-xs font-mono font-bold border border-emerald-500/30 transition"
              >
                Safe Cap ({safeCapacity}h)
              </button>
              <button
                type="button"
                onClick={() => setDurationHours(Number((safeCapacity + 1.0).toFixed(1)))}
                className="px-2.5 py-1 rounded bg-red-500/15 hover:bg-red-500/25 text-red-300 text-xs font-mono font-bold border border-red-500/30 transition"
              >
                Overload ({(safeCapacity + 1.0).toFixed(1)}h)
              </button>
            </div>
          </div>

          {/* Task Name */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Task / Batch Name
            </label>
            <input
              type="text"
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              className="w-full bg-black/70 border border-white/15 text-white rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:border-cyan-400"
              required
            />
          </div>

          {/* Priority */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-300 mb-1.5">
              Priority Level
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value as PriorityLevel)}
              className="w-full bg-black/70 border border-white/15 text-white rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:border-cyan-400"
            >
              <option value="NORMAL">Normal Priority</option>
              <option value="HIGH">High Priority</option>
              <option value="URGENT">Urgent Priority</option>
            </select>
          </div>

          {/* Status Message */}
          <div className={`p-3 rounded-lg border flex items-center gap-3 ${
            isOverloaded ? 'bg-red-950/30 border-red-500/50' : 'bg-emerald-950/20 border-emerald-500/30'
          }`}>
            {isOverloaded ? (
              <Flame className="w-5 h-5 text-red-400 animate-pulse shrink-0" />
            ) : (
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            )}
            <div className="text-xs">
              <span className={`font-bold ${isOverloaded ? 'text-red-300' : 'text-emerald-300'}`}>
                {isOverloaded
                  ? `Overload Alert: ${durationHours}h exceeds safe limit ${safeCapacity}h (${overloadPercent}%)`
                  : `Safe Workload: ${durationHours}h within limit (${overloadPercent}%)`}
              </span>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isOverloaded
                  ? 'Submitting will sound the emergency audio siren & send alerts to workers.'
                  : 'Safe operation within rated machine parameters.'}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className={`px-5 py-2 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition ${
                isOverloaded
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(255,62,62,0.4)]'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-[0_0_15px_rgba(0,212,255,0.3)]'
              }`}
            >
              {isOverloaded ? <Flame className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
              <span>{isOverloaded ? 'Assign Overload (Trigger Alert)' : 'Assign Safe Work'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
