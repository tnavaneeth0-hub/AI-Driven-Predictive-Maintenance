import React, { useState, useEffect } from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  Activity,
  Cpu,
  Sliders,
  Sparkles,
  Bell,
  Users,
  Wrench,
  History,
  FileText,
  Settings,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  BookOpen,
  Smartphone,
  Flame,
  ShieldAlert,
  AlertTriangle,
  DollarSign,
  Bot
} from 'lucide-react';

export const Navbar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    isSimulationRunning,
    toggleSimulation,
    resetFactoryToDefault,
    isSirenActive,
    isAudioMuted,
    toggleAudioMute,
    stats,
    setIsWorkerMobileOpen,
  } = useFactory();

  const [currentTime, setCurrentTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString('en-US', {
          hour12: false,
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Activity, badge: null },
    { id: 'machines', label: 'Machines', icon: Cpu, badge: '10' },
    { id: 'work-allocation', label: 'Work Allocation', icon: Sliders, badge: null },
    { id: 'predictions', label: 'Predictions', icon: Sparkles, badge: 'AI' },
    {
      id: 'alerts',
      label: 'Alerts',
      icon: Bell,
      badge: stats.activeAlerts > 0 ? stats.activeAlerts.toString() : null,
      badgeColor: stats.activeAlerts > 0 ? 'bg-red-600 text-white animate-pulse' : '',
    },
    { id: 'worker-alerts', label: 'Worker Alerts', icon: Users, badge: '5' },
    {
      id: 'maintenance',
      label: 'Maintenance',
      icon: Wrench,
      badge: stats.maintenanceRequired > 0 ? stats.maintenanceRequired.toString() : null,
      badgeColor: 'bg-amber-600 text-white',
    },
    { id: 'downtime-cost', label: 'Downtime & Costs', icon: DollarSign, badge: 'ROI' },
    { id: 'ai-assistant', label: 'AI Assistant', icon: Bot, badge: 'COPILOT' },
    { id: 'history', label: 'History', icon: History, badge: null },
    { id: 'reports', label: 'Reports', icon: FileText, badge: null },
    { id: 'architecture', label: 'Docs & API', icon: BookOpen, badge: 'SPEC' },
    { id: 'settings', label: 'Settings', icon: Settings, badge: null },
  ];

  return (
    <header className="bg-[#08090a]/90 border-b border-white/5 sticky top-0 z-30 backdrop-blur-xl">
      {/* Top Banner: Industrial Branding & Test Case Presets */}
      <div className="w-full max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8 py-2 flex flex-col xl:flex-row items-center justify-between gap-2.5 border-b border-white/5">
        {/* Brand Title */}
        <div className="flex items-center gap-3 w-full xl:w-auto justify-between xl:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-md bg-cyan-500 text-black font-black text-xs shadow-[0_0_15px_rgba(0,212,255,0.4)]">
              AI
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-400"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xs sm:text-sm font-bold tracking-wider text-white uppercase">
                  AI-Driven Predictive Maintenance
                </h1>
                <span className="bg-cyan-500/10 text-cyan-400 border border-cyan-400/30 text-[9px] font-mono px-1.5 py-0.2 rounded font-semibold tracking-wider">
                  SMART FACTORY
                </span>
              </div>
              <p className="text-[9px] text-slate-400 uppercase tracking-tight flex items-center gap-1.5 mt-0.5 font-mono">
                <span>10-Machine Fleet Grid</span>
                <span className="text-slate-600">•</span>
                <span className="text-emerald-400 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full indicator-green"></span>
                  Factory Health: {stats.averageHealth}%
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-400">{currentTime}</span>
              </p>
            </div>
          </div>

          {/* Mobile Phone Launcher Button */}
          <button
            onClick={() => setIsWorkerMobileOpen(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 xl:hidden"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile</span>
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 w-full xl:w-auto justify-end flex-wrap">
          {/* Android Mobile Worker App Modal Button */}
          <button
            onClick={() => setIsWorkerMobileOpen(true)}
            className="hidden xl:flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-bold bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 border border-cyan-400/40 shadow-[0_0_10px_rgba(0,212,255,0.2)] transition uppercase tracking-wider"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Worker Mobile</span>
          </button>

          {/* Simulation Toggle */}
          <button
            id="btn-toggle-simulation"
            onClick={toggleSimulation}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md text-xs font-semibold border transition ${
              isSimulationRunning
                ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/40 hover:bg-emerald-500/20 shadow-[0_0_10px_rgba(0,255,136,0.15)]'
                : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
            }`}
          >
            {isSimulationRunning ? <Pause className="w-3.5 h-3.5 text-emerald-400" /> : <Play className="w-3.5 h-3.5 text-slate-400" />}
            <span>{isSimulationRunning ? 'PAUSE' : 'SIMULATE'}</span>
          </button>

          {/* Reset Factory */}
          <button
            id="btn-reset-factory"
            onClick={resetFactoryToDefault}
            className="flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium bg-white/5 text-slate-400 hover:text-slate-200 border border-white/10 hover:bg-white/10 transition"
            title="Reset All Machines to Factory Default"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>RESET</span>
          </button>

          {/* Audio Siren Toggle */}
          <button
            id="btn-audio-mute-toggle"
            onClick={toggleAudioMute}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border transition ${
              isAudioMuted
                ? 'bg-red-500/10 text-red-400 border-red-500/30'
                : isSirenActive
                ? 'bg-red-600/30 text-red-300 border-red-500 shadow-[0_0_12px_rgba(255,62,62,0.4)] animate-pulse'
                : 'bg-white/5 text-slate-400 border-white/10 hover:text-slate-200'
            }`}
            title="Mute / Unmute Siren"
          >
            {isAudioMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-emerald-400" />}
            <span className="hidden sm:inline">{isAudioMuted ? 'Muted' : 'Siren ON'}</span>
          </button>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <nav className="w-full max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8 overflow-x-auto scrollbar-none flex items-center gap-1 py-1.5">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav-tab-${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all duration-150 ${
                isActive
                  ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-400/30 shadow-[0_0_12px_rgba(0,212,255,0.15)]'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-white/5 border border-transparent'
              }`}
            >
              <div
                className={`w-1.5 h-1.5 rounded-full ${
                  isActive ? 'indicator-cyan' : 'bg-slate-600'
                }`}
              />
              <span>{item.label}</span>
              {item.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-bold ${
                    item.badgeColor || (isActive ? 'bg-cyan-500/20 text-cyan-300' : 'bg-white/10 text-slate-400')
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </header>
  );
};
