import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import { sirenEngine } from '../services/sirenService';
import {
  Settings,
  Sliders,
  Volume2,
  VolumeX,
  Play,
  RotateCcw,
  ShieldCheck,
  Cpu,
  Save,
  CheckCircle2,
  Info,
  Sparkles
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    machines,
    updateMachineSafeCapacity,
    resetFactoryToDefault,
    isAudioMuted,
    toggleAudioMute,
    enableAudio,
    isAudioUnlocked,
  } = useFactory();

  const [audioVolume, setAudioVolume] = useState<number>(0.75);

  const [localCapacities, setLocalCapacities] = useState<Record<string, number>>(() => {
    const map: Record<string, number> = {};
    machines.forEach((m) => {
      map[m.id] = m.safeHours;
    });
    return map;
  });

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleCapacityChange = (machineId: string, val: number) => {
    setLocalCapacities((prev) => ({
      ...prev,
      [machineId]: val,
    }));
  };

  const handleSaveAllCapacities = () => {
    Object.entries(localCapacities).forEach(([mId, val]) => {
      updateMachineSafeCapacity(mId, Number(val));
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const testSirenSound = () => {
    enableAudio();
    sirenEngine.startSiren();
    setTimeout(() => {
      sirenEngine.stopSiren();
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-cyan-400" />
            System Configuration & Engineering Parameters
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Configure safe operating limits, test the Web Audio siren synthesizer, and manage simulation baseline state.
          </p>
        </div>

        <button
          onClick={resetFactoryToDefault}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-red-500/10 text-red-300 border border-red-500/30 hover:bg-red-500/20 transition uppercase tracking-wider"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset to Defaults</span>
        </button>
      </div>

      {/* Audio Siren Configuration */}
      <div className="glass-card p-5 shadow-2xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 mb-1">
          <Volume2 className="w-4 h-4 text-cyan-400" />
          Software Siren Synthesizer (Web Audio API)
        </h3>
        <p className="text-xs text-slate-400 mb-4">
          Browser-based frequency modulation (750 Hz ± 250 Hz LFO) generated in real-time without external audio assets.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center bg-black/40 p-4 rounded-lg border border-white/5">
          <div>
            <span className="text-[10px] uppercase font-mono font-bold text-slate-400 block mb-1">Siren Status</span>
            <button
              onClick={toggleAudioMute}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition uppercase tracking-wider ${
                isAudioMuted
                  ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 shadow-[0_0_10px_rgba(0,255,136,0.15)]'
              }`}
            >
              {isAudioMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
              <span>{isAudioMuted ? 'Muted (Silent)' : 'Audio Enabled'}</span>
            </button>
          </div>

          <div>
            <div className="flex justify-between items-center text-xs text-slate-400 mb-1">
              <span className="text-[10px] uppercase font-mono font-bold">Siren Volume</span>
              <span className="font-mono font-bold text-cyan-400">{Math.round(audioVolume * 100)}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={audioVolume}
              onChange={(e) => {
                const v = parseFloat(e.target.value);
                setAudioVolume(v);
                sirenEngine.setVolume(v);
              }}
              className="w-full accent-cyan-400 h-1.5 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

          <div className="flex justify-end">
            <button
              onClick={testSirenSound}
              className="px-4 py-2 rounded-lg text-xs font-bold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition uppercase tracking-wider"
            >
              Test 2-Sec Siren
            </button>
          </div>
        </div>
      </div>

      {/* Batch Safe Capacity Editor (All 10 Machines) */}
      <div className="glass-card p-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              Batch Safe Operating Capacity Limits (Hours)
            </h3>
            <p className="text-xs text-slate-400">
              Safe capacity determines the threshold before an overload alert and siren are triggered.
            </p>
          </div>

          <button
            onClick={handleSaveAllCapacities}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.4)] transition uppercase tracking-wider self-end sm:self-auto"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save All Limits</span>
          </button>
        </div>

        {savedSuccess && (
          <div className="bg-emerald-500/10 border border-emerald-500/40 text-emerald-300 px-3 py-2 rounded-lg text-xs flex items-center gap-2 mb-4 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Safe operating capacities successfully updated for all machines!</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {machines.map((machine) => (
            <div
              key={machine.id}
              className="p-3 bg-black/40 border border-white/5 rounded-lg flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="font-bold text-white flex items-center gap-2">
                  <span className="text-[10px] font-mono text-cyan-400">{machine.code}</span>
                  <span className="line-clamp-1">{machine.name}</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Current Limit: {machine.safeHours}h</span>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <input
                  type="number"
                  min="0.5"
                  max="10.0"
                  step="0.5"
                  value={localCapacities[machine.id] ?? machine.safeHours}
                  onChange={(e) => handleCapacityChange(machine.id, parseFloat(e.target.value))}
                  className="w-16 bg-black border border-white/10 text-white rounded px-2 py-1 text-center font-mono font-bold text-xs focus:border-cyan-400 focus:outline-none"
                />
                <span className="text-slate-400 font-mono text-[10px]">hrs</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
