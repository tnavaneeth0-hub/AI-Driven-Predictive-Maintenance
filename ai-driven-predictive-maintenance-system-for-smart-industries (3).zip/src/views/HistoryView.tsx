import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import { History, Search, Download, Filter, ShieldAlert, CheckCircle2, FileSpreadsheet } from 'lucide-react';

export const HistoryView: React.FC = () => {
  const { alerts } = useFactory();

  const [searchTerm, setSearchTerm] = useState('');
  const [riskFilter, setRiskFilter] = useState<string>('ALL');

  const filteredAlerts = alerts.filter((a) => {
    const matchSearch =
      a.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.machineCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.machineName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.message.toLowerCase().includes(searchTerm.toLowerCase());
    const matchRisk = riskFilter === 'ALL' || a.riskLevel === riskFilter;
    return matchSearch && matchRisk;
  });

  const exportCSV = () => {
    const headers = ['Alert ID', 'Timestamp', 'Machine Code', 'Machine Name', 'Safe Hours', 'Workload Hours', 'Workload Ratio', 'Risk Level', 'Status', 'Action Taken'];
    const rows = filteredAlerts.map((a) => [
      a.id,
      `"${a.timestamp}"`,
      a.machineCode,
      `"${a.machineName}"`,
      a.safeCapacityHours,
      a.workloadHours,
      `${(a.workloadRatio * 100).toFixed(0)}%`,
      a.riskLevel,
      a.status,
      `"${a.actionTaken || 'N/A'}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smart_factory_alerts_export_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <History className="w-5 h-5 text-cyan-400" />
            Factory Incident & Alert History Audit Log
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Complete historical record of machine overload events, telemetry threshold breaches, and worker dispatches.
          </p>
        </div>

        <button
          onClick={exportCSV}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition active:scale-95 uppercase tracking-wider"
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
          <span>Export CSV</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center gap-3 glass-card p-3">
        <div className="flex items-center gap-2 bg-black/40 border border-white/5 rounded-lg px-3 py-1.5 w-full sm:flex-1">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Alert ID, Machine Code, or Description..."
            className="bg-transparent text-xs text-white focus:outline-none w-full placeholder:text-slate-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={riskFilter}
            onChange={(e) => setRiskFilter(e.target.value)}
            className="bg-black/40 border border-white/5 text-xs text-white rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-400 w-full sm:w-auto"
          >
            <option value="ALL" className="bg-[#121418] text-white">All Risk Levels</option>
            <option value="CRITICAL" className="bg-[#121418] text-white">CRITICAL (&gt;1.25)</option>
            <option value="HIGH_RISK" className="bg-[#121418] text-white">HIGH RISK (1.01-1.25)</option>
            <option value="CAUTION" className="bg-[#121418] text-white">CAUTION (0.91-1.00)</option>
            <option value="NORMAL" className="bg-[#121418] text-white">NORMAL (0.71-0.90)</option>
            <option value="SAFE" className="bg-[#121418] text-white">SAFE (0-0.70)</option>
          </select>
        </div>
      </div>

      {/* History Log Table */}
      <div className="glass-card overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-black/40 text-slate-400 uppercase tracking-wider border-b border-white/5 text-[9px]">
              <tr>
                <th className="py-3 px-4">Alert ID</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Machine</th>
                <th className="py-3 px-4">Safe Cap</th>
                <th className="py-3 px-4">Workload</th>
                <th className="py-3 px-4">Ratio</th>
                <th className="py-3 px-4">Risk Level</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Action Taken</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredAlerts.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-sans">
                    No historical alert logs match your query.
                  </td>
                </tr>
              ) : (
                filteredAlerts.map((alert) => (
                  <tr key={alert.id} className="hover:bg-white/[0.02] transition">
                    <td className="py-3 px-4 font-bold text-cyan-400">{alert.id}</td>
                    <td className="py-3 px-4 text-slate-400 text-[11px]">{alert.timestamp}</td>
                    <td className="py-3 px-4 font-sans font-bold text-white">
                      {alert.machineCode}
                    </td>
                    <td className="py-3 px-4 text-emerald-400 font-bold">{alert.safeCapacityHours}h</td>
                    <td className="py-3 px-4 text-red-400 font-bold">{alert.workloadHours}h</td>
                    <td className="py-3 px-4 font-bold text-orange-400">
                      {(alert.workloadRatio * 100).toFixed(0)}%
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold uppercase ${
                          alert.riskLevel === 'CRITICAL'
                            ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                            : alert.riskLevel === 'HIGH_RISK'
                            ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {alert.riskLevel}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                          alert.status === 'RESOLVED'
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : alert.status === 'ACKNOWLEDGED'
                            ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30'
                            : 'bg-red-500/10 text-red-400 border border-red-500/30 font-bold'
                        }`}
                      >
                        {alert.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-sans text-[11px] max-w-xs truncate">
                      {alert.actionTaken || 'Pending engineer review'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
