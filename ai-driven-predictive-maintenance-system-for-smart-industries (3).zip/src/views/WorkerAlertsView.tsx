import React from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  Users,
  Bell,
  CheckCircle2,
  Clock,
  ShieldAlert,
  Send,
  UserCheck,
  CheckCheck,
  Radio,
  Building,
  Smartphone,
  Check,
  Sparkles
} from 'lucide-react';

export const WorkerAlertsView: React.FC = () => {
  const {
    workers,
    workerNotifications,
    acknowledgeWorkerNotification,
    acknowledgeAllWorkerNotifications,
    alerts,
    setIsWorkerMobileOpen,
    setCurrentMobileWorker,
    workerNotificationStats,
  } = useFactory();

  const activeAlerts = alerts.filter((a) => a.status === 'ACTIVE');

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-cyan-400" />
              Synchronized Worker Mobile Dispatch Center
            </h2>
            <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded">
              FCM Simulation
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time push alert synchronization to 5 on-duty floor technicians with instant emergency sirens and acknowledgement logs.
          </p>
        </div>

        {/* Worker Mobile Launcher Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsWorkerMobileOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.4)] transition uppercase tracking-wider"
          >
            <Smartphone className="w-4 h-4" />
            <span>Launch Android Worker Emulator</span>
          </button>
        </div>
      </div>

      {/* Push Notification Delivery Funnel KPI */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="glass-card p-3">
          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Sent Broadcasts</span>
          <div className="text-xl font-light font-mono text-cyan-400 mt-0.5">{workerNotificationStats.sent}</div>
          <span className="text-[9px] text-slate-400 font-mono">100% Broadcast</span>
        </div>

        <div className="glass-card p-3">
          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Delivered to Devices</span>
          <div className="text-xl font-light font-mono text-emerald-400 mt-0.5">{workerNotificationStats.delivered}</div>
          <span className="text-[9px] text-emerald-500/80 font-mono">FCM Push Confirmed</span>
        </div>

        <div className="glass-card p-3">
          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Opened by Workers</span>
          <div className="text-xl font-light font-mono text-amber-400 mt-0.5">{workerNotificationStats.opened}</div>
          <span className="text-[9px] text-amber-500/80 font-mono">App Active</span>
        </div>

        <div className="glass-card p-3">
          <span className="text-[9px] uppercase font-bold tracking-wider text-slate-500 block">Acknowledged Responses</span>
          <div className="text-xl font-light font-mono text-purple-400 mt-0.5">{workerNotificationStats.acknowledged}</div>
          <span className="text-[9px] text-purple-500/80 font-mono">Operator Confirmed</span>
        </div>
      </div>

      {/* 5 Worker Profiles Grid */}
      <div>
        <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-3">
          On-Duty Maintenance & Safety Crew (Shift A • 06:00 - 14:00)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {workers.map((worker) => {
            const workerNotifs = workerNotifications.filter((n) => n.workerId === worker.id);
            const unreadCount = workerNotifs.filter((n) => n.status !== 'ACKNOWLEDGED').length;

            return (
              <div
                key={worker.id}
                className="glass-card p-3.5 flex flex-col justify-between hover:border-cyan-500/30 transition cursor-pointer"
                onClick={() => {
                  setCurrentMobileWorker(worker);
                  setIsWorkerMobileOpen(true);
                }}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-400/30 text-cyan-400 font-bold text-xs flex items-center justify-center font-mono">
                      {worker.avatarInitials}
                    </div>
                    <span className="text-[9px] font-mono font-semibold uppercase text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                      {worker.status}
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-white line-clamp-1">{worker.name}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-1">{worker.role}</p>
                  <p className="text-[9px] text-slate-500 font-mono mt-1 uppercase">{worker.department}</p>
                </div>

                <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400 text-[10px]">Tap to Open:</span>
                  <span
                    className={`font-mono text-[10px] font-bold ${
                      unreadCount > 0 ? 'text-red-400 animate-pulse' : 'text-slate-400'
                    }`}
                  >
                    {unreadCount} unread
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Dispatched Notification Stream */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Dispatched Alert Broadcasts ({workerNotifications.length} Events)
          </h3>

          {workerNotifications.some((n) => n.status !== 'ACKNOWLEDGED') && (
            <button
              onClick={() => {
                workerNotifications.forEach((n) => acknowledgeWorkerNotification(n.id));
              }}
              className="text-xs font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 uppercase tracking-wider"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Acknowledge All</span>
            </button>
          )}
        </div>

        {workerNotifications.length === 0 ? (
          <div className="glass-card p-10 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-200">No Active Worker Broadcasts</h4>
            <p className="text-xs text-slate-400 mt-0.5">
              Worker push alerts will be automatically triggered when any machine exceeds safe capacity.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {workerNotifications.map((notif) => {
              const isAcknowledged = notif.status === 'ACKNOWLEDGED';

              return (
                <div
                  key={notif.id}
                  className={`glass-card p-3.5 transition-all ${
                    isAcknowledged
                      ? 'opacity-70 border-white/5'
                      : notif.priority === 'CRITICAL'
                      ? 'bg-red-500/10 border-red-500/40 shadow-[0_0_15px_rgba(255,62,62,0.15)]'
                      : 'border-white/10'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                          isAcknowledged
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                        }`}
                      >
                        {isAcknowledged ? '✅ ACKNOWLEDGED' : '🚨 DELIVERED'}
                      </span>
                      <span className="text-xs font-bold text-white">{notif.workerName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">({notif.role})</span>
                    </div>

                    <div className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>Sent: {notif.sentAt}</span>
                      {notif.acknowledgedAt && <span>• Ack: {notif.acknowledgedAt}</span>}
                    </div>
                  </div>

                  <p className="text-xs text-slate-200 mb-2 leading-relaxed">{notif.message}</p>

                  <div className="flex items-center justify-between pt-2 border-t border-white/5">
                    <span className="text-[10px] font-mono text-cyan-400">Node: {notif.machineCode}</span>

                    {!isAcknowledged && (
                      <button
                        onClick={() => acknowledgeWorkerNotification(notif.id, notif.workerName)}
                        className="px-3 py-1 rounded bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 transition"
                      >
                        <Check className="w-3 h-3" />
                        <span>Acknowledge</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
