import React, { useState, useEffect } from 'react';
import { useFactory } from '../context/FactoryContext';
import { AlertItem, Machine } from '../types';
import { RedistributionModal } from '../components/RedistributionModal';
import {
  Bell,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Volume2,
  VolumeX,
  Zap,
  Wrench,
  Check,
  ArrowRight,
  Filter,
  ShieldCheck,
  Clock,
  UserCheck,
  Users,
  AlertOctagon,
  History,
  Timer
} from 'lucide-react';

export const AlertsView: React.FC = () => {
  const {
    alerts,
    machines,
    acknowledgeAlertByRole,
    resolveAlert,
    haltAndInspectMachine,
    isSirenActive,
    stopSiren,
    setActiveTab,
    setSelectedMachineId,
    escalationAuditLogs,
    escalationTimeoutSeconds,
  } = useFactory();

  const [systemRole, setSystemRole] = useState<'ADMIN' | 'SUPERVISOR' | 'WORKER'>('SUPERVISOR');
  const [filter, setFilter] = useState<'ALL' | 'ACTIVE' | 'ESCALATED' | 'RESOLVED'>('ALL');
  const [showAuditLogs, setShowAuditLogs] = useState(false);
  const [redistributeSource, setRedistributeSource] = useState<{ machine: Machine; alert: AlertItem } | null>(null);
  const [currentTime, setCurrentTime] = useState(Date.now());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const getEscalationTier = (alert: AlertItem) => {
    if (alert.escalationStage === 'ADMIN_NOTIFIED') return 'ADMIN';
    if (alert.escalationStage === 'SUPERVISOR_NOTIFIED') return 'SUPERVISOR';
    return 'WORKER';
  };

  const filteredAlerts = alerts.filter((a) => {
    const tier = getEscalationTier(a);
    if (filter === 'ACTIVE') return a.status === 'ACTIVE' || a.status === 'ACKNOWLEDGED';
    if (filter === 'ESCALATED') return tier !== 'WORKER' && a.status !== 'RESOLVED';
    if (filter === 'RESOLVED') return a.status === 'RESOLVED';
    return true;
  });

  const activeCount = alerts.filter((a) => a.status === 'ACTIVE').length;
  const escalatedCount = alerts.filter((a) => getEscalationTier(a) !== 'WORKER' && a.status !== 'RESOLVED').length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-red-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white tracking-wide">
                    Alert Command Center & 3-Tier Escalation
                  </h2>
                  {activeCount > 0 && (
                    <span className="bg-red-500/20 text-red-400 border border-red-500/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full animate-pulse">
                      {activeCount} ACTIVE
                    </span>
                  )}
                  {escalatedCount > 0 && (
                    <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full animate-pulse">
                      {escalatedCount} ESCALATED
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Tier 1 (Worker Push) → Tier 2 (Supervisor Alert & Dashboard Siren at 2m) → Tier 3 (Admin Emergency Lockout).
                </p>
              </div>
            </div>
          </div>

          {/* Role Switcher + Siren Control */}
          <div className="flex items-center gap-2.5 flex-wrap">
            {isSirenActive && (
              <div className="flex items-center gap-2 bg-red-950/80 border border-red-500/50 px-3 py-1.5 rounded-xl text-xs text-red-200 shadow-[0_0_15px_rgba(255,62,62,0.3)]">
                <span className="w-2 h-2 rounded-full indicator-red animate-pulse" />
                <span className="font-bold text-[11px] uppercase tracking-wider text-red-300">SIREN ACTIVE</span>
                <button
                  onClick={stopSiren}
                  className="ml-1 px-2 py-0.5 bg-red-600/40 hover:bg-red-600/70 border border-red-500/50 text-red-200 font-bold rounded-lg text-[10px] uppercase transition"
                >
                  STOP SIREN
                </button>
              </div>
            )}

            {/* Acting Role Toggle */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-1 flex items-center gap-1">
              <span className="text-[10px] uppercase font-bold text-slate-400 px-2 font-mono">Role:</span>
              {(['ADMIN', 'SUPERVISOR', 'WORKER'] as const).map((r) => (
                <button
                  key={r}
                  onClick={() => setSystemRole(r)}
                  className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition uppercase ${
                    systemRole === r
                      ? 'bg-cyan-500 text-black shadow-[0_0_10px_rgba(0,212,255,0.3)]'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>

            {/* Audit Log Toggle */}
            <button
              onClick={() => setShowAuditLogs(!showAuditLogs)}
              className={`px-3 py-2 rounded-xl text-xs font-bold border transition flex items-center gap-1.5 ${
                showAuditLogs
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
                  : 'bg-white/5 text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              <span>Audit Trail ({escalationAuditLogs.length})</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3-Tier Escalation Architecture Explainer Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="bg-[#0b0e14] border border-blue-500/20 rounded-xl p-3.5 flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400 shrink-0 font-mono font-bold text-xs">
            T1
          </div>
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">Tier 1: Worker Notification</div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Targeted Android push + vibration dispatched immediately to assigned technician.
            </p>
          </div>
        </div>

        <div className="bg-[#0b0e14] border border-amber-500/20 rounded-xl p-3.5 flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0 font-mono font-bold text-xs">
            T2
          </div>
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">Tier 2: Supervisor Escalation</div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Triggered after 2 min unacknowledged. Sounds siren and highlights supervisor console.
            </p>
          </div>
        </div>

        <div className="bg-[#0b0e14] border border-red-500/20 rounded-xl p-3.5 flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 shrink-0 font-mono font-bold text-xs">
            T3
          </div>
          <div>
            <div className="text-xs font-bold text-white uppercase tracking-wider">Tier 3: Admin Emergency Lockout</div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Triggered after 4 min. Machine automatically locked into safe mode until inspected.
            </p>
          </div>
        </div>
      </div>

      {/* Escalation Audit Trail Panel */}
      {showAuditLogs && (
        <div className="bg-[#0b0e14] border border-cyan-500/30 rounded-2xl p-5 shadow-xl space-y-3">
          <div className="flex items-center justify-between border-b border-white/5 pb-2">
            <div className="flex items-center gap-2 text-xs font-bold text-white uppercase tracking-wider">
              <History className="w-4 h-4 text-cyan-400" />
              <span>Escalation Audit Trail & Incident Response Log</span>
            </div>
            <span className="text-[10px] font-mono text-slate-400">{escalationAuditLogs.length} Total Logs</span>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
            {escalationAuditLogs.length === 0 ? (
              <p className="text-xs text-slate-500 py-3 text-center">No escalation events logged yet.</p>
            ) : (
              escalationAuditLogs.map((log) => (
                <div
                  key={log.id}
                  className="bg-white/5 border border-white/5 rounded-xl p-3 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white font-mono">{log.machineCode}</span>
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded font-bold uppercase ${
                          log.stage.includes('ADMIN')
                            ? 'bg-red-500/20 text-red-300 border border-red-500/30'
                            : log.stage.includes('SUPERVISOR')
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                        }`}
                      >
                        {log.stage.replace(/_/g, ' ')}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">{log.timestamp}</span>
                    </div>
                    <p className="text-slate-300 text-[11px]">{log.message}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-400 font-mono block">Actor: {log.actor}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Filter Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex items-center bg-[#0b0e14] border border-white/10 rounded-xl p-1">
          {(['ALL', 'ACTIVE', 'ESCALATED', 'RESOLVED'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition uppercase tracking-wider ${
                filter === f
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <span className="text-xs font-mono text-slate-400">
          Showing {filteredAlerts.length} incidents
        </span>
      </div>

      {/* Alert Cards */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-12 text-center shadow-xl">
            <ShieldCheck className="w-12 h-12 text-emerald-400 mx-auto mb-3" />
            <h3 className="text-sm font-bold text-slate-200">All Factory Systems Nominal</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
              No alerts match your current filter. All 10 machines are operating within safe rated capacity limits.
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const machine = machines.find((m) => m.id === alert.machineId);
            const isCritical = alert.riskLevel === 'CRITICAL';
            const isResolved = alert.status === 'RESOLVED';
            const isAcknowledged = alert.status === 'ACKNOWLEDGED';
            const tier = getEscalationTier(alert);

            // Calculate Remaining Escalation Time (if active and unacknowledged)
            const alertCreatedMs = new Date(alert.timestamp).getTime() || Date.now();
            const elapsedSec = Math.floor((currentTime - alertCreatedMs) / 1000);
            const timeoutSec = alert.escalationTimerSeconds || escalationTimeoutSeconds || 120;
            const remainingSec = Math.max(0, timeoutSec - elapsedSec);

            return (
              <div
                key={alert.id}
                id={`alert-card-${alert.id}`}
                className={`bg-[#0b0e14] border rounded-2xl p-5 sm:p-6 transition-all duration-200 shadow-xl ${
                  isResolved
                    ? 'opacity-70 border-white/5'
                    : tier === 'ADMIN'
                    ? 'bg-red-950/20 border-red-500/60 shadow-[0_0_25px_rgba(255,62,62,0.2)]'
                    : tier === 'SUPERVISOR'
                    ? 'bg-amber-950/20 border-amber-500/50 shadow-[0_0_20px_rgba(245,158,11,0.15)]'
                    : isCritical
                    ? 'bg-red-500/5 border-red-500/40'
                    : 'border-orange-500/30'
                }`}
              >
                {/* Header Line */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full ${
                        isResolved
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                          : isCritical
                          ? 'bg-red-500/20 text-red-400 border border-red-500/40 shadow-[0_0_8px_rgba(255,62,62,0.3)]'
                          : 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                      }`}
                    >
                      {isResolved ? '✅ RESOLVED' : isCritical ? '🚨 CRITICAL OVERLOAD' : '⚠️ WARNING'}
                    </span>

                    {/* 3-Tier Escalation Pill */}
                    <span
                      className={`text-[10px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full border ${
                        tier === 'ADMIN'
                          ? 'bg-red-600/30 text-red-200 border-red-500 animate-pulse'
                          : tier === 'SUPERVISOR'
                          ? 'bg-amber-600/30 text-amber-200 border-amber-500 animate-pulse'
                          : 'bg-blue-600/20 text-blue-300 border-blue-400/40'
                      }`}
                    >
                      Tier: {tier} {tier === 'ADMIN' ? '(ADMIN LOCKOUT)' : tier === 'SUPERVISOR' ? '(SUPERVISOR PUSH)' : '(WORKER)'}
                    </span>

                    <span className="text-xs font-mono font-bold text-slate-400">
                      ID: {alert.id}
                    </span>
                    <span className="text-xs text-slate-500 font-mono">
                      • {alert.timestamp}
                    </span>
                  </div>

                  {/* Status & Escalation Countdown Timer */}
                  <div className="flex items-center gap-3">
                    {alert.status === 'ACTIVE' && tier === 'WORKER' && (
                      <div className="flex items-center gap-1 text-xs font-mono font-bold text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2.5 py-0.5 rounded-lg">
                        <Timer className="w-3.5 h-3.5 animate-spin" />
                        <span>Escalating in: {remainingSec}s</span>
                      </div>
                    )}

                    <span
                      className={`text-[10px] font-mono font-semibold px-2.5 py-0.5 rounded-full ${
                        alert.status === 'ACTIVE'
                          ? 'bg-red-500/10 text-red-400 border border-red-500/30'
                          : alert.status === 'ACKNOWLEDGED'
                          ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      Status: {alert.status}
                    </span>
                  </div>
                </div>

                {/* Machine Details & Overload Metrics */}
                <div className="mb-4">
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <span>{alert.machineCode} — {alert.machineName}</span>
                    {alert.acknowledgedBy && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/5 text-emerald-400 border border-emerald-500/20">
                        Ack: {alert.acknowledgedBy}
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{alert.message}</p>
                </div>

                {/* Metric Summary Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/40 border border-white/5 rounded-xl p-3.5 mb-4 text-xs font-mono">
                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Safe Capacity</span>
                    <span className="text-emerald-400 font-bold">{alert.safeCapacityHours}h</span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Assigned Work</span>
                    <span className="text-red-400 font-bold">{alert.workloadHours}h</span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Workload Ratio</span>
                    <span className="text-orange-400 font-bold">
                      {(alert.workloadRatio * 100).toFixed(0)}% ({((alert.workloadRatio - 1) * 100).toFixed(0)}% Overload)
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Risk Level</span>
                    <span className="text-red-400 font-bold">{alert.riskLevel}</span>
                  </div>
                </div>

                {/* AI Explanation / Action recommendation box */}
                <div className="bg-black/30 p-3.5 rounded-xl mb-4 text-xs border border-white/5">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-400 block mb-1">
                    AI Diagnostic Directive & Response Protocol
                  </span>
                  <p className="text-slate-300 leading-relaxed">
                    {alert.aiRecommendation ||
                      'Stop or redistribute the assigned workload immediately to prevent thermal and mechanical breakdown.'}
                  </p>

                  {alert.actionTaken && (
                    <div className="mt-2 pt-2 border-t border-white/5 text-emerald-400 font-medium flex items-center gap-1.5 text-xs">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Action Log: {alert.actionTaken}</span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                {!isResolved && (
                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/5">
                    {/* Acknowledge as System Role */}
                    {alert.status === 'ACTIVE' && (
                      <button
                        onClick={() => acknowledgeAlertByRole(alert.id, systemRole, `${systemRole} Console`)}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 transition uppercase tracking-wider"
                      >
                        <Check className="w-3.5 h-3.5 text-cyan-400" />
                        <span>ACKNOWLEDGE AS {systemRole}</span>
                      </button>
                    )}

                    {/* Condition 2 Specific: Halt & Inspect Machine */}
                    {alert.alertType === 'UNASSIGNED_OPERATION' && machine && (
                      <button
                        id={`btn-halt-${alert.id}`}
                        onClick={() => haltAndInspectMachine(machine.id, alert.id)}
                        className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold bg-amber-500 hover:bg-amber-400 text-black shadow-[0_0_12px_rgba(245,158,11,0.3)] transition active:scale-95 uppercase tracking-wider"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                        <span>Halt Machine & Clear Run</span>
                      </button>
                    )}

                    {/* Primary Mitigation: Redistribute Workload */}
                    {machine && machine.assignedHours > 0 && (
                      <button
                        id={`btn-redistribute-${alert.id}`}
                        onClick={() => setRedistributeSource({ machine, alert })}
                        className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_12px_rgba(0,212,255,0.3)] transition active:scale-95 uppercase tracking-wider"
                      >
                        <Zap className="w-3.5 h-3.5" />
                        <span>Auto-Redistribute Workload</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {/* Schedule Urgent Maintenance */}
                    <button
                      onClick={() => {
                        setSelectedMachineId(alert.machineId);
                        setActiveTab('maintenance');
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 transition uppercase tracking-wider"
                    >
                      <Wrench className="w-3.5 h-3.5 text-amber-400" />
                      <span>Schedule Maintenance</span>
                    </button>

                    {/* Manual Resolve */}
                    <button
                      id={`btn-resolve-${alert.id}`}
                      onClick={() => resolveAlert(alert.id, 'Manually inspected and verified safe by supervisor.')}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-400 hover:bg-emerald-500/10 border border-emerald-500/30 transition uppercase tracking-wider ml-auto"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Resolve Alert</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* Redistribution Modal */}
      {redistributeSource && (
        <RedistributionModal
          sourceMachine={redistributeSource.machine}
          alert={redistributeSource.alert}
          onClose={() => setRedistributeSource(null)}
        />
      )}
    </div>
  );
};
