import React, { useState, useEffect } from 'react';
import { useFactory } from '../context/FactoryContext';
import { Machine, AIDiagnosticResult } from '../types';
import {
  calculateWorkloadRatio,
  predictMTTFHours,
  predictFailureProbability,
  generateLocalAIDiagnosis,
} from '../services/predictiveEngine';
import {
  Sparkles,
  Cpu,
  Activity,
  AlertTriangle,
  Flame,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  BrainCircuit,
  Wrench,
  CheckCircle2,
  RefreshCw,
  Zap,
  HelpCircle
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  Cell,
  Legend
} from 'recharts';

export const PredictionsView: React.FC = () => {
  const { machines, selectedMachineId, setSelectedMachineId, fetchAIDiagnostics, setActiveTab } = useFactory();

  const [machineId, setMachineId] = useState<string>(selectedMachineId || 'M-01');
  const [aiResult, setAiResult] = useState<AIDiagnosticResult | null>(null);
  const [isLoadingAI, setIsLoadingAI] = useState<boolean>(false);

  useEffect(() => {
    if (selectedMachineId) {
      setMachineId(selectedMachineId);
    }
  }, [selectedMachineId]);

  const selectedMachine = machines.find((m) => m.id === machineId) || machines[0];
  const workloadRatio = calculateWorkloadRatio(selectedMachine.assignedHours, selectedMachine.safeHours);
  const workloadPercent = Math.round(workloadRatio * 100);
  const mttf = predictMTTFHours(selectedMachine.healthScore, workloadRatio);
  const failureProb = predictFailureProbability(
    selectedMachine.healthScore,
    workloadRatio,
    selectedMachine.overloadEvents
  );

  // Load initial AI diagnostics for selected machine
  useEffect(() => {
    const local = generateLocalAIDiagnosis(
      selectedMachine,
      selectedMachine.assignedHours,
      selectedMachine.safeHours
    );
    setAiResult(local);
  }, [selectedMachine]);

  const handleDeepDiagnose = async () => {
    setIsLoadingAI(true);
    const result = await fetchAIDiagnostics(selectedMachine);
    setAiResult(result);
    setIsLoadingAI(false);
  };

  // Recharts Data: Machine Health & Capacity comparison for all 10 machines
  const machineComparisonData = machines.map((m) => ({
    code: m.code.replace('MACHINE ', 'M-'),
    name: m.name,
    health: m.healthScore,
    workloadPercent: Math.round((m.assignedHours / m.safeHours) * 100),
    safeHours: m.safeHours,
    assignedHours: m.assignedHours,
    risk: m.riskLevel,
  }));

  // Historical Telemetry Simulation Curve (last 6 shifts)
  const healthTrendData = [
    { shift: 'Shift -5', health: Math.min(100, selectedMachine.healthScore + 12), temp: 42, vibration: 1.1 },
    { shift: 'Shift -4', health: Math.min(100, selectedMachine.healthScore + 9), temp: 44, vibration: 1.3 },
    { shift: 'Shift -3', health: Math.min(100, selectedMachine.healthScore + 6), temp: 46, vibration: 1.4 },
    { shift: 'Shift -2', health: Math.min(100, selectedMachine.healthScore + 4), temp: 48, vibration: 1.6 },
    { shift: 'Shift -1', health: Math.min(100, selectedMachine.healthScore + 2), temp: selectedMachine.temperature - 4, vibration: selectedMachine.vibration - 0.3 },
    { shift: 'Current', health: selectedMachine.healthScore, temp: selectedMachine.temperature, vibration: selectedMachine.vibration },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            AI Predictive Maintenance & Risk Diagnostics
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Machine learning failure prediction, telemetry stress correlation, and automated engineering explanations.
          </p>
        </div>

        {/* Machine Selector */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 whitespace-nowrap">Focus Node:</label>
          <select
            value={machineId}
            onChange={(e) => {
              setMachineId(e.target.value);
              setSelectedMachineId(e.target.value);
            }}
            className="bg-black/60 border border-white/10 text-white text-xs rounded-lg px-3 py-1.5 focus:outline-none focus:border-cyan-400"
          >
            {machines.map((m) => (
              <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                {m.code} — {m.name} ({m.healthScore}% Health)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Top 4 Predictive KPI Metrics for Selected Machine */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Dynamic Health Score */}
        <div className="glass-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Machine Health</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-2xl font-mono font-bold ${
                selectedMachine.healthScore >= 80
                  ? 'text-emerald-400'
                  : selectedMachine.healthScore >= 60
                  ? 'text-amber-400'
                  : 'text-red-400 animate-pulse'
              }`}
            >
              {selectedMachine.healthScore}%
            </span>
            <span className="text-[10px] uppercase font-mono text-slate-400">
              {selectedMachine.healthScore >= 80 ? 'Nominal' : selectedMachine.healthScore >= 60 ? 'Warning' : 'Critical'}
            </span>
          </div>
          <div className="health-bar w-full mt-3">
            <div
              className={`h-full ${
                selectedMachine.healthScore >= 80
                  ? 'bg-emerald-400'
                  : selectedMachine.healthScore >= 60
                  ? 'bg-amber-400'
                  : 'bg-red-500 shadow-[0_0_8px_#ff3e3e]'
              }`}
              style={{ width: `${selectedMachine.healthScore}%` }}
            />
          </div>
        </div>

        {/* Workload vs Safe Capacity */}
        <div className="glass-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Workload Ratio</span>
            <Cpu className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-2xl font-mono font-bold ${
                workloadRatio > 1.25 ? 'text-red-400' : workloadRatio > 1.0 ? 'text-orange-400' : 'text-white'
              }`}
            >
              {workloadPercent}%
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              ({selectedMachine.assignedHours}h / {selectedMachine.safeHours}h)
            </span>
          </div>
          <div className="text-[9px] text-slate-500 font-mono mt-3 uppercase">
            Rated Limit: {selectedMachine.safeHours}.0h max
          </div>
        </div>

        {/* Predicted Failure Probability */}
        <div className="glass-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">24h Failure Probability</span>
            <BrainCircuit className="w-4 h-4 text-purple-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span
              className={`text-2xl font-mono font-bold ${
                failureProb > 60 ? 'text-red-400' : failureProb > 30 ? 'text-amber-400' : 'text-emerald-400'
              }`}
            >
              {failureProb}%
            </span>
            <span className="text-[10px] font-mono text-purple-300">ML Risk Model</span>
          </div>
          <div className="text-[9px] text-slate-500 font-mono mt-3 uppercase">
            Overload Events: {selectedMachine.overloadEvents}
          </div>
        </div>

        {/* Estimated MTTF */}
        <div className="glass-card p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Mean Time To Failure</span>
            <Wrench className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-mono font-bold text-white">{mttf}</span>
            <span className="text-xs text-slate-400">hours</span>
          </div>
          <div className="text-[9px] text-slate-500 font-mono mt-3 uppercase">
            Continuous operating threshold
          </div>
        </div>
      </div>

      {/* Section: AI EXPLANATION & WHY IS MACHINE AT RISK */}
      <div className="glass-card p-6 relative overflow-hidden backdrop-blur-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4 mb-5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-cyan-400 shadow-[0_0_10px_rgba(0,212,255,0.2)]">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                AI Diagnostic Explanation: {selectedMachine.code}
                <span className="text-[10px] font-mono text-cyan-400 bg-cyan-500/10 border border-cyan-400/30 px-2 py-0.5 rounded uppercase">
                  {aiResult?.source || 'Gemini Predictive Reliability'}
                </span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Transparent explainable AI insights explaining the mechanical and mathematical root causes.
              </p>
            </div>
          </div>

          <button
            id="btn-run-deep-ai-diagnostics"
            onClick={handleDeepDiagnose}
            disabled={isLoadingAI}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)] transition active:scale-95 disabled:opacity-50 uppercase tracking-wider"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAI ? 'animate-spin' : ''}`} />
            <span>{isLoadingAI ? 'Analyzing Telemetry...' : 'Run Deep AI Diagnostics'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Why is Machine At Risk */}
          <div className="lg:col-span-7 space-y-4">
            <div className="glass-card bg-black/40 p-4 border-white/5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-2 mb-3">
                <HelpCircle className="w-4 h-4" />
                WHY IS {selectedMachine.code} AT RISK?
              </h4>

              <ul className="space-y-2.5">
                {aiResult?.explanation.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-200 leading-relaxed">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0" />
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* AI Recommendation Banner */}
            <div className="glass-card bg-cyan-500/5 border-cyan-400/30 p-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-2 mb-1.5">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                AI ENGINEERING DIRECTIVE
              </h4>
              <p className="text-xs text-slate-200 font-medium leading-relaxed">
                “{aiResult?.recommendation || 'Maintain monitoring and adhere to rated capacity schedule.'}”
              </p>
            </div>
          </div>

          {/* Machine Telemetry Live Matrix */}
          <div className="lg:col-span-5 glass-card bg-black/40 p-4 border-white/5 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
                Asset Physical Stress Sensors
              </h4>

              <div className="space-y-2.5 font-mono text-xs">
                <div className="flex justify-between items-center bg-black/50 p-2.5 rounded-lg border border-white/5">
                  <span className="text-slate-400">Spindle Temperature</span>
                  <span className={`font-bold ${selectedMachine.temperature > 65 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {selectedMachine.temperature}°C (Normal: 40-60°C)
                  </span>
                </div>

                <div className="flex justify-between items-center bg-black/50 p-2.5 rounded-lg border border-white/5">
                  <span className="text-slate-400">Vibration RMS</span>
                  <span className={`font-bold ${selectedMachine.vibration > 2.5 ? 'text-red-400' : 'text-emerald-400'}`}>
                    {selectedMachine.vibration} mm/s (Normal: &lt; 2.0)
                  </span>
                </div>

                <div className="flex justify-between items-center bg-black/50 p-2.5 rounded-lg border border-white/5">
                  <span className="text-slate-400">Power Consumption</span>
                  <span className="text-slate-200 font-bold">{selectedMachine.powerDraw} kW</span>
                </div>

                <div className="flex justify-between items-center bg-black/50 p-2.5 rounded-lg border border-white/5">
                  <span className="text-slate-400">Cumulative Overloads</span>
                  <span className="text-orange-400 font-bold">{selectedMachine.overloadEvents} events</span>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-white/5 mt-4 flex gap-2">
              <button
                onClick={() => setActiveTab('work-allocation')}
                className="flex-1 py-2 rounded-lg text-xs font-bold bg-white/5 hover:bg-white/10 text-slate-200 text-center border border-white/10 transition uppercase tracking-wider"
              >
                Re-allocate Work
              </button>
              <button
                onClick={() => setActiveTab('alerts')}
                className="flex-1 py-2 rounded-lg text-xs font-bold bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 text-center transition uppercase tracking-wider"
              >
                View Alerts
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Interactive Charts: Factory Workload Capacity & Health Degradation Trends */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Workload % Across 10 Machines */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">Workload Ratio (10 Assets)</h3>
              <p className="text-[10px] text-slate-400">Assigned work hours as % of safe capacity limit</p>
            </div>
            <span className="text-[10px] font-mono bg-white/5 text-slate-300 border border-white/10 px-2 py-0.5 rounded">
              Limit: 100%
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={machineComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f242e" />
                <XAxis dataKey="code" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} domain={[0, 'dataMax + 20']} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121418', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#fff' }}
                  formatter={(value: number) => [`${value}% Workload`, 'Ratio']}
                />
                <Bar dataKey="workloadPercent" radius={[4, 4, 0, 0]}>
                  {machineComparisonData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.workloadPercent > 125 ? '#ff3e3e' : entry.workloadPercent > 100 ? '#f97316' : entry.workloadPercent > 90 ? '#f2a154' : '#00ff88'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Machine Health & Sensor Stress Trend */}
        <div className="glass-card p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">{selectedMachine.code} Health Trend</h3>
              <p className="text-[10px] text-slate-400">Continuous degradation tracking vs thermal stress</p>
            </div>
            <span className="text-[10px] font-mono bg-cyan-500/10 text-cyan-300 border border-cyan-400/30 px-2 py-0.5 rounded">
              Shift Degradation
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={healthTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1f242e" />
                <XAxis dataKey="shift" stroke="#64748b" tick={{ fontSize: 10 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 10 }} domain={[30, 100]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#121418', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '12px', color: '#fff' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                <Line type="monotone" dataKey="health" name="Health Score (%)" stroke="#00ff88" strokeWidth={2.5} dot={{ r: 4 }} />
                <Line type="monotone" dataKey="temp" name="Temperature (°C)" stroke="#f2a154" strokeWidth={1.5} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
