import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import { Machine } from '../types';
import { calculateWorkloadRatio } from '../services/predictiveEngine';
import {
  Cpu,
  Edit2,
  Sliders,
  Sparkles,
  Zap,
  Activity,
  Gauge,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Wrench,
  Search,
  Check,
  X
} from 'lucide-react';

export const MachinesView: React.FC = () => {
  const { machines, updateMachineSafeCapacity, setSelectedMachineId, setActiveTab, assignWork } = useFactory();

  const [searchQuery, setSearchQuery] = useState('');
  const [editingMachine, setEditingMachine] = useState<Machine | null>(null);
  const [newSafeCapacity, setNewSafeCapacity] = useState<number>(1.0);

  const filteredMachines = machines.filter(
    (m) =>
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpenEdit = (m: Machine) => {
    setEditingMachine(m);
    setNewSafeCapacity(m.safeHours);
  };

  const handleSaveCapacity = () => {
    if (editingMachine) {
      updateMachineSafeCapacity(editingMachine.id, newSafeCapacity);
      setEditingMachine(null);
    }
  };

  const triggerOverloadStressTest = (m: Machine) => {
    // Assign 2x the safe capacity
    assignWork(
      m.id,
      Number((m.safeHours * 2.0).toFixed(1)),
      `Stress Test Overload: ${m.code}`,
      'Heavy Stress Production',
      'URGENT'
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <Cpu className="w-5 h-5 text-cyan-400" />
            Smart Factory Machine Assets (10 Units)
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time telemetry, administrator safe capacity tuning, and physical sensor telemetry.
          </p>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2 glass-card px-3 py-1.5 w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search machines or types..."
            className="bg-transparent text-xs text-white focus:outline-none w-full placeholder:text-slate-500"
          />
        </div>
      </div>

      {/* Machine Table / Detailed Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredMachines.map((machine) => {
          const ratio = calculateWorkloadRatio(machine.assignedHours, machine.safeHours);
          const ratioPercent = Math.round(ratio * 100);
          const isOverloaded = machine.status === 'OVERLOADED' || ratio > 1.25;

          return (
            <div
              key={machine.id}
              id={`machine-detail-${machine.id}`}
              className={`glass-card p-5 transition-all duration-200 backdrop-blur-md ${
                isOverloaded
                  ? 'bg-red-500/5 border-red-500/40 shadow-[0_0_20px_rgba(255,62,62,0.2)]'
                  : machine.riskLevel === 'HIGH_RISK'
                  ? 'border-orange-500/30'
                  : 'hover:border-white/20'
              }`}
            >
              {/* Card Top */}
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center font-mono font-bold text-xs ${
                    isOverloaded
                      ? 'bg-red-500 text-white animate-pulse shadow-[0_0_10px_#ff3e3e]'
                      : 'bg-cyan-500/10 text-cyan-400 border border-cyan-400/30'
                  }`}>
                    {machine.id}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      {machine.code} — {machine.name}
                    </h3>
                    <span className="text-[10px] text-slate-400 font-mono uppercase">{machine.location}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span
                    className={`text-[9px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                      machine.riskLevel === 'CRITICAL'
                        ? 'bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse'
                        : machine.riskLevel === 'HIGH_RISK'
                        ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                        : machine.riskLevel === 'CAUTION'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {machine.riskLevel}
                  </span>
                </div>
              </div>

              {/* Specifications & Capacity Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-black/40 border border-white/5 rounded-lg p-3 mb-4 text-xs font-mono">
                <div>
                  <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Safe Capacity</span>
                  <div className="flex items-center gap-1 text-emerald-400 font-bold">
                    <span>{machine.safeHours}h</span>
                    <button
                      onClick={() => handleOpenEdit(machine)}
                      className="p-0.5 hover:text-cyan-400 text-slate-500 rounded transition"
                      title="Edit Safe Capacity"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>

                <div>
                  <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Assigned</span>
                  <span className={`font-bold ${ratio > 1.0 ? 'text-red-400' : 'text-white'}`}>
                    {machine.assignedHours}h
                  </span>
                </div>

                <div>
                  <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Workload</span>
                  <span className={`font-bold ${ratio > 1.0 ? 'text-red-400' : 'text-cyan-300'}`}>
                    {ratioPercent}%
                  </span>
                </div>

                <div>
                  <span className="text-[9px] text-slate-500 block uppercase tracking-wider">Health</span>
                  <span className={`font-bold ${machine.healthScore < 60 ? 'text-red-400' : 'text-emerald-400'}`}>
                    {machine.healthScore}%
                  </span>
                </div>
              </div>

              {/* Sensor Telemetry Readings */}
              <div className="grid grid-cols-3 gap-2 text-[10px] font-mono text-slate-400 bg-black/30 p-2.5 rounded-lg border border-white/5 mb-4">
                <div>
                  <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Temperature</span>
                  <span className={machine.temperature > 65 ? 'text-amber-400 font-bold' : 'text-slate-200'}>
                    {machine.temperature}°C
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Vibration</span>
                  <span className={machine.vibration > 2.5 ? 'text-red-400 font-bold' : 'text-slate-200'}>
                    {machine.vibration} mm/s
                  </span>
                </div>

                <div>
                  <span className="text-slate-500 block text-[9px] uppercase tracking-wider">Power / RPM</span>
                  <span className="text-slate-200">
                    {machine.powerDraw}kW / {machine.rpm}
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                <button
                  onClick={() => {
                    setSelectedMachineId(machine.id);
                    setActiveTab('work-allocation');
                  }}
                  className="flex-1 py-1.5 rounded-lg text-xs font-semibold bg-white/5 hover:bg-white/10 text-slate-200 border border-white/10 transition uppercase tracking-wider"
                >
                  Allocate Work
                </button>

                <button
                  onClick={() => {
                    setSelectedMachineId(machine.id);
                    setActiveTab('predictions');
                  }}
                  className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-400/30 transition uppercase tracking-wider"
                >
                  AI Diagnostics
                </button>

                {/* Overload Stress Trigger */}
                <button
                  onClick={() => triggerOverloadStressTest(machine)}
                  className="py-1.5 px-2.5 rounded-lg text-xs font-medium bg-red-500/10 hover:bg-red-500/20 text-red-300 border border-red-500/30 transition"
                  title="Simulate Instant Overload Workload"
                >
                  <Flame className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Admin Capacity Edit Modal */}
      {editingMachine && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="glass-card max-w-md w-full p-6 shadow-2xl animate-in fade-in zoom-in duration-150 border-white/10">
            <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                Admin: Modify Safe Rated Capacity
              </h3>
              <button
                onClick={() => setEditingMachine(null)}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 mb-4">
              Update the engineering threshold for <strong className="text-white">{editingMachine.code} ({editingMachine.name})</strong>.
            </p>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Maximum Safe Operating Hours (hrs)
                </label>
                <input
                  type="number"
                  min="0.5"
                  max="24.0"
                  step="0.5"
                  value={newSafeCapacity}
                  onChange={(e) => setNewSafeCapacity(parseFloat(e.target.value) || 1.0)}
                  className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3.5 py-2 text-xs font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="bg-black/40 p-3 rounded-lg border border-white/5 text-xs text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>Current Assigned Work:</span>
                  <span className="font-mono text-white font-bold">{editingMachine.assignedHours} hr</span>
                </div>
                <div className="flex justify-between">
                  <span>New Workload Ratio:</span>
                  <span className="font-mono text-cyan-400 font-bold">
                    {((editingMachine.assignedHours / newSafeCapacity) * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setEditingMachine(null)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-400 hover:text-slate-200"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCapacity}
                className="px-4 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)] transition uppercase tracking-wider"
              >
                Save Capacity
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
