import React, { useState } from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  FileText,
  Sparkles,
  ShieldCheck,
  TrendingUp,
  AlertTriangle,
  DollarSign,
  Clock,
  Printer,
  RefreshCw,
  Award
} from 'lucide-react';
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid
} from 'recharts';

export const ReportsView: React.FC = () => {
  const { machines, alerts, stats, generateExecutiveReport } = useFactory();

  const [aiReport, setAiReport] = useState<string>('');
  const [isLoadingAI, setIsLoadingAI] = useState<boolean>(false);

  const handleGenerateAIReport = async () => {
    setIsLoadingAI(true);
    const summary = await generateExecutiveReport();
    setAiReport(summary);
    setIsLoadingAI(false);
  };

  const handlePrint = () => {
    window.print();
  };

  // Pie chart data: Status breakdown of 10 machines
  const statusPieData = [
    { name: 'Safe / Normal', value: stats.safeMachines, color: '#10b981' },
    { name: 'Caution (90-100%)', value: stats.cautionMachines, color: '#f59e0b' },
    { name: 'High Risk (101-125%)', value: stats.highRiskMachines, color: '#f97316' },
    { name: 'Critical (>125%)', value: stats.criticalMachines, color: '#ef4444' },
  ].filter((item) => item.value > 0);

  // Prevention metrics
  const preventedFailures = alerts.filter((a) => a.actionTaken && a.actionTaken.includes('Redistributed')).length || 1;
  const downtimeSavedHours = (preventedFailures * 8.5).toFixed(1);
  const costSavingsUSD = (preventedFailures * 14500).toLocaleString();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            Executive Reliability & Predictive Analytics Report
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Key factory performance metrics, downtime prevention ROI, and AI executive reliability briefings.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-white/5 hover:bg-white/10 text-white border border-white/10 transition uppercase tracking-wider"
          >
            <Printer className="w-4 h-4" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* ROI & Prevented Failure Hero Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-card p-4 border-emerald-500/30 bg-emerald-500/5">
          <div className="flex items-center justify-between text-xs text-emerald-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Failures Prevented</span>
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div className="text-2xl font-mono font-bold text-emerald-400">{preventedFailures}</div>
          <p className="text-[9px] text-emerald-400/80 font-mono mt-2 uppercase">Via Smart AI Redistribution</p>
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Downtime Hours Saved</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-cyan-400">{downtimeSavedHours} hrs</div>
          <p className="text-[9px] text-slate-500 font-mono mt-2 uppercase">Zero Catastrophic Stoppages</p>
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Estimated Savings</span>
            <DollarSign className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-amber-400">${costSavingsUSD}</div>
          <p className="text-[9px] text-slate-500 font-mono mt-2 uppercase">Spindle & Tooling Capital ROI</p>
        </div>

        <div className="glass-card p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Factory Availability</span>
            <Award className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-mono font-bold text-purple-400">{stats.factoryAvailability}%</div>
          <p className="text-[9px] text-slate-500 font-mono mt-2 uppercase">Overall Equipment Effectiveness</p>
        </div>
      </div>

      {/* AI Executive Report Generator */}
      <div className="glass-card p-5 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-sm font-bold text-white">
                Gemini AI Executive Reliability Assessment
              </h3>
              <p className="text-[10px] text-slate-400">
                Synthesizes capacity utilization, maintenance risks, and failure mitigations.
              </p>
            </div>
          </div>

          <button
            onClick={handleGenerateAIReport}
            disabled={isLoadingAI}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)] transition disabled:opacity-50 uppercase tracking-wider"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoadingAI ? 'animate-spin' : ''}`} />
            <span>{isLoadingAI ? 'Synthesizing Report...' : 'Generate AI Briefing'}</span>
          </button>
        </div>

        {aiReport ? (
          <div className="bg-black/60 p-4 rounded-lg border border-white/5 text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line">
            {aiReport}
          </div>
        ) : (
          <div className="bg-black/40 p-6 rounded-lg border border-dashed border-white/10 text-center text-xs text-slate-400">
            Click "Generate AI Briefing" to run the server-side Gemini intelligence engine and formulate an executive engineering summary.
          </div>
        )}
      </div>

      {/* Visual Charts: Fleet Health & Machine Risk Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Machine Status Breakdown (Pie Chart) */}
        <div className="glass-card p-5 shadow-2xl">
          <h3 className="text-sm font-bold text-white mb-1">Fleet Risk Distribution (10 Assets)</h3>
          <p className="text-[10px] text-slate-400 mb-4 uppercase font-mono">Proportion of machines across safe, caution, and risk zones</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusPieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#121418', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '11px', color: '#fff' }} />
                <Legend wrapperStyle={{ fontSize: '10px', paddingTop: '10px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Machine Health Scores Breakdown (Bar Chart) */}
        <div className="glass-card p-5 shadow-2xl">
          <h3 className="text-sm font-bold text-white mb-1">Asset Health Index (%)</h3>
          <p className="text-[10px] text-slate-400 mb-4 uppercase font-mono">Current mechanical and thermal health score across all 10 assets</p>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={machines.map((m) => ({ code: m.code.replace('MACHINE ', 'M-'), health: m.healthScore }))}
                margin={{ top: 10, right: 10, left: -20, bottom: 20 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="code" stroke="#64748b" tick={{ fontSize: 9 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 9 }} domain={[0, 100]} />
                <Tooltip contentStyle={{ backgroundColor: '#121418', borderColor: 'rgba(255,255,255,0.1)', borderRadius: '8px', fontSize: '11px', color: '#fff' }} />
                <Bar dataKey="health" fill="#00d4ff" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};
