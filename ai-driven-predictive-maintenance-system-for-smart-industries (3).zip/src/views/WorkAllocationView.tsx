import React, { useState, useEffect, useMemo } from 'react';
import { useFactory } from '../context/FactoryContext';
import { calculateWorkloadRatio, classifyRiskLevel } from '../services/predictiveEngine';
import {
  Sliders,
  Cpu,
  AlertTriangle,
  Flame,
  ShieldAlert,
  ShieldCheck,
  Zap,
  ArrowRight,
  Clock,
  CheckCircle2,
  Sparkles,
  Calendar,
  Award,
  Thermometer,
  Activity,
  Check,
  ChevronRight
} from 'lucide-react';
import { PriorityLevel } from '../types';

export const WorkAllocationView: React.FC = () => {
  const {
    machines,
    assignWork,
    selectedMachineId,
    setSelectedMachineId,
    setActiveTab,
    getSmartWorkloadRecommendation,
  } = useFactory();

  const [machineId, setMachineId] = useState<string>(selectedMachineId || 'M-01');
  const [workType, setWorkType] = useState<string>('Heavy 5-Axis Milling');
  const [durationHours, setDurationHours] = useState<number>(2.0);
  const [priority, setPriority] = useState<PriorityLevel>('HIGH');
  const [taskName, setTaskName] = useState<string>('High-Stress Turbine Bulkhead Run #104');
  const [startTime, setStartTime] = useState<string>('08:30');

  useEffect(() => {
    if (selectedMachineId) {
      setMachineId(selectedMachineId);
    }
  }, [selectedMachineId]);

  // AI Smart Workload Recommendation Engine
  const recommendation = useMemo(() => {
    return getSmartWorkloadRecommendation(durationHours);
  }, [durationHours, getSmartWorkloadRecommendation]);

  const selectedMachine = machines.find((m) => m.id === machineId) || machines[0];
  const safeCapacity = selectedMachine?.safeHours ?? 1.0;
  const workloadRatio = calculateWorkloadRatio(durationHours, safeCapacity);
  const workloadPercent = Math.round(workloadRatio * 100);
  const predictedRisk = classifyRiskLevel(workloadRatio);

  const isExceeded = workloadRatio > 1.0;
  const isCritical = workloadRatio > 1.25;

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    const result = assignWork(machineId, durationHours, taskName, workType, priority);
    if (result.alertCreated) {
      setActiveTab('alerts');
    }
  };

  const handleSelectRecommendedMachine = (targetId: string) => {
    setMachineId(targetId);
    setSelectedMachineId(targetId);
  };

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                <Sliders className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-white tracking-wide">
                Workload Allocation & AI Smart Machine Selection
              </h2>
              <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                ML OPTIMIZED
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Intelligent workload balancer evaluates machine thermal degradation, vibration harmonics, current capacity, and maintenance schedules to recommend optimal assignment.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Current Workload</div>
              <div className="text-sm font-bold text-cyan-400 font-mono">{durationHours} Hours</div>
            </div>
            {recommendation?.recommendedMachine && (
              <button
                onClick={() => handleSelectRecommendedMachine(recommendation.recommendedMachine.id)}
                className="px-3.5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,212,255,0.3)] transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Apply AI Top Pick ({recommendation.recommendedMachine.code})</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Feature 1 Highlight: AI Smart Machine Recommendation Banner */}
      {recommendation?.recommendedMachine && (
        <div className="bg-gradient-to-r from-cyan-950/40 via-slate-900/60 to-slate-900/40 border border-cyan-500/40 rounded-2xl p-5 shadow-xl">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
            <div className="space-y-1.5 max-w-3xl">
              <div className="flex items-center gap-2">
                <span className="flex items-center gap-1 text-xs font-bold text-cyan-400 uppercase tracking-wider bg-cyan-500/20 border border-cyan-400/40 px-2.5 py-0.5 rounded-md">
                  <Award className="w-3.5 h-3.5" />
                  Top Recommended Machine for {durationHours}h Workload
                </span>
                <span className="text-xs font-bold text-white">
                  {recommendation.recommendedMachine.code} — {recommendation.recommendedMachine.name}
                </span>
              </div>
              <p className="text-xs text-slate-300">
                {recommendation.primaryReason}
              </p>
              <div className="flex flex-wrap items-center gap-3 pt-1 text-[11px] text-slate-400">
                <span className="flex items-center gap-1 text-emerald-400">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Health Score: {recommendation.recommendedMachine.healthScore}%
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Thermometer className="w-3.5 h-3.5 text-cyan-400" />
                  Temp: {recommendation.recommendedMachine.temperature}°C
                </span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Activity className="w-3.5 h-3.5 text-cyan-400" />
                  Vibration: {recommendation.recommendedMachine.vibration} mm/s
                </span>
                <span>•</span>
                <span className="font-mono text-cyan-300">
                  Post-Shift Utilization: {recommendation.rankings?.[0]?.projectedUtilization ?? Math.round(((recommendation.recommendedMachine.assignedHours + durationHours) / recommendation.recommendedMachine.safeHours) * 100)}%
                </span>
              </div>
            </div>

            <button
              onClick={() => handleSelectRecommendedMachine(recommendation.recommendedMachine.id)}
              className={`px-4 py-2.5 rounded-xl font-bold text-xs flex items-center gap-2 transition shrink-0 ${
                machineId === recommendation.recommendedMachine.id
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40'
                  : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)]'
              }`}
            >
              {machineId === recommendation.recommendedMachine.id ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>Selected as Target Asset</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Select {recommendation.recommendedMachine.code}</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* Main Grid: Assignment Form + Pre-Check Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form (7 Cols) */}
        <form onSubmit={handleAssign} className="lg:col-span-7 bg-[#0b0e14] border border-white/10 rounded-2xl p-6 space-y-4 shadow-xl">
          {/* Select Machine */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              1. Select Production Machine
            </label>
            <select
              id="select-machine"
              value={machineId}
              onChange={(e) => {
                setMachineId(e.target.value);
                setSelectedMachineId(e.target.value);
              }}
              className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3.5 py-2.5 text-xs focus:outline-none focus:border-cyan-400"
            >
              {machines.map((m) => (
                <option key={m.id} value={m.id} className="bg-slate-900 text-slate-200">
                  {m.code} — {m.name} (Safe Limit: {m.safeHours}h | Health: {m.healthScore}%)
                </option>
              ))}
            </select>
          </div>

          {/* Work Task Name */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
              2. Task / Job Description
            </label>
            <input
              type="text"
              value={taskName}
              onChange={(e) => setTaskName(e.target.value)}
              placeholder="e.g. Body Panel Sheet Stamping Batch #4"
              className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3.5 py-2 text-xs focus:outline-none focus:border-cyan-400 placeholder:text-slate-600"
              required
            />
          </div>

          {/* Work Type & Priority */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                3. Work Type
              </label>
              <select
                value={workType}
                onChange={(e) => setWorkType(e.target.value)}
                className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
              >
                <option value="Heavy 5-Axis Milling" className="bg-slate-900 text-slate-200">Heavy 5-Axis Milling</option>
                <option value="Automated Robotic Welding" className="bg-slate-900 text-slate-200">Automated Robotic Welding</option>
                <option value="High-Precision Lathe Turning" className="bg-slate-900 text-slate-200">High-Precision Lathe Turning</option>
                <option value="Hydraulic Die Stamping" className="bg-slate-900 text-slate-200">Hydraulic Die Stamping</option>
                <option value="Injection Molding Cycle" className="bg-slate-900 text-slate-200">Injection Molding Cycle</option>
                <option value="Fiber Laser Profile Cutting" className="bg-slate-900 text-slate-200">Fiber Laser Profile Cutting</option>
                <option value="Vacuum Annealing Heat Treatment" className="bg-slate-900 text-slate-200">Vacuum Annealing Heat Treatment</option>
                <option value="Continuous Line Assembly" className="bg-slate-900 text-slate-200">Continuous Line Assembly</option>
                <option value="Ultrasonic Chemical Cleaning" className="bg-slate-900 text-slate-200">Ultrasonic Chemical Cleaning</option>
                <option value="High-Speed Packaging" className="bg-slate-900 text-slate-200">High-Speed Packaging</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                4. Priority Level
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {(['NORMAL', 'HIGH', 'URGENT'] as PriorityLevel[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => setPriority(p)}
                    className={`py-2 text-xs font-bold rounded-lg border transition uppercase tracking-wider ${
                      priority === p
                        ? p === 'URGENT'
                          ? 'bg-red-500/20 text-red-300 border-red-500/40 shadow-[0_0_10px_rgba(255,62,62,0.3)]'
                          : p === 'HIGH'
                          ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                          : 'bg-cyan-500/20 text-cyan-300 border-cyan-400/40'
                        : 'bg-black/40 text-slate-400 border-white/5 hover:bg-white/5'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Expected Work Duration Slider + Input */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                5. Expected Work Duration (Hours)
              </label>
              <div className="flex items-center gap-1">
                <span className="font-mono text-sm font-bold text-cyan-400">{durationHours}</span>
                <span className="text-xs text-slate-400">hours</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <input
                type="range"
                min="0.2"
                max="8.0"
                step="0.1"
                value={durationHours}
                onChange={(e) => setDurationHours(parseFloat(e.target.value))}
                className="w-full accent-cyan-400 h-2 bg-black/60 rounded-lg cursor-pointer"
              />
              <input
                type="number"
                min="0.1"
                max="12.0"
                step="0.1"
                value={durationHours}
                onChange={(e) => setDurationHours(Math.max(0.1, parseFloat(e.target.value) || 0.1))}
                className="w-20 bg-black/60 border border-white/10 text-white rounded-lg px-2 py-1.5 text-center font-mono text-xs focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1 uppercase">
              <span>0.2h (Light)</span>
              <span>1.0h</span>
              <span>2.0h</span>
              <span>4.0h</span>
              <span>8.0h (Heavy Shift)</span>
            </div>
          </div>

          {/* Start Time & Expected Completion */}
          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/5">
            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Start Time</label>
              <div className="flex items-center gap-2 bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-200">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className="bg-transparent focus:outline-none text-slate-100 text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] uppercase font-bold tracking-wider text-slate-400 mb-1">Est. Completion</label>
              <div className="flex items-center gap-2 bg-black/60 border border-white/10 rounded-lg px-3 py-2 text-xs text-slate-300 font-mono">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>+ {durationHours} hrs Shift</span>
              </div>
            </div>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            id="btn-submit-work-allocation"
            className={`w-full py-3 rounded-lg text-xs font-bold uppercase tracking-wider transition-all duration-200 flex items-center justify-center gap-2 shadow-lg active:scale-98 ${
              isCritical
                ? 'bg-red-500 hover:bg-red-400 text-white shadow-[0_0_15px_rgba(255,62,62,0.4)] animate-pulse'
                : isExceeded
                ? 'bg-orange-500 hover:bg-orange-400 text-black shadow-[0_0_15px_rgba(242,161,84,0.4)]'
                : 'bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)]'
            }`}
          >
            <Zap className="w-4 h-4" />
            <span>ASSIGN WORK TO {selectedMachine?.code ?? 'MACHINE'}</span>
          </button>
        </form>

        {/* Right Pre-Check Analysis Card (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          {/* Real-Time Prediction Gauge */}
          <div className={`bg-[#0b0e14] border rounded-2xl p-5 transition-all duration-200 shadow-xl ${
            isCritical
              ? 'border-red-500/40 shadow-[0_0_20px_rgba(255,62,62,0.15)] bg-red-500/5'
              : isExceeded
              ? 'border-orange-500/40 bg-orange-500/5'
              : 'border-white/10'
          }`}>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                AI Capacity Pre-Check
              </span>
              <span className={`text-[10px] font-mono font-bold uppercase px-2 py-0.5 rounded ${
                predictedRisk === 'CRITICAL'
                  ? 'bg-red-500/20 text-red-400 border border-red-500/40 shadow-[0_0_10px_rgba(255,62,62,0.3)] animate-pulse'
                  : predictedRisk === 'HIGH_RISK'
                  ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40'
                  : predictedRisk === 'CAUTION'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
              }`}>
                {predictedRisk}
              </span>
            </div>

            {/* Target Machine Summary */}
            <div className="bg-black/40 border border-white/5 rounded-xl p-3.5 mb-4">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <span>Selected Machine:</span>
                <span className="text-white font-bold">{selectedMachine?.code ?? ''} ({selectedMachine?.name ?? ''})</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <span>Safe Rated Capacity:</span>
                <span className="text-emerald-400 font-mono font-bold">{safeCapacity} hr</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                <span>Requested Workload:</span>
                <span className={`font-mono font-bold ${isExceeded ? 'text-red-400' : 'text-slate-200'}`}>
                  {durationHours} hr
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-400 pt-1.5 border-t border-white/5">
                <span>Workload Ratio:</span>
                <span className={`font-mono font-bold text-sm ${isExceeded ? 'text-red-400' : 'text-cyan-400'}`}>
                  {workloadPercent}%
                </span>
              </div>
            </div>

            {/* Warning or Safe Status Message */}
            {isExceeded ? (
              <div className="space-y-3">
                <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-200">
                  <ShieldAlert className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-[10px] font-bold uppercase tracking-wide text-red-300">
                      ⚠️ CAPACITY EXCEEDED
                    </h4>
                    <p className="text-xs text-red-200/90 mt-0.5 leading-relaxed">
                      Assigned work ({durationHours}h) exceeds maximum safe capacity ({safeCapacity}h).
                      Workload is {workloadPercent}%.
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-black/40 border border-white/5 text-xs">
                  <div className="flex items-center gap-1.5 text-cyan-400 font-bold mb-1 text-[11px] uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Recommended AI Action:</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-xs">
                    “Reduce workload or transfer the task to the top-ranked machine.”
                  </p>

                  {recommendation?.recommendedMachine && (
                    <div className="mt-2.5 pt-2.5 border-t border-white/5 flex items-center justify-between">
                      <span className="text-[11px] text-slate-400">
                        Top Pick: <strong className="text-cyan-400">{recommendation.recommendedMachine.code}</strong> ({recommendation.recommendedMachine.safeHours}h Cap)
                      </span>
                      <button
                        type="button"
                        onClick={() => handleSelectRecommendedMachine(recommendation.recommendedMachine.id)}
                        className="text-[10px] font-bold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 uppercase tracking-wider"
                      >
                        <span>Switch to {recommendation.recommendedMachine.code}</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex items-start gap-2.5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-200">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-[10px] font-bold text-emerald-300 uppercase tracking-wider">Within Safe Limits</h4>
                  <p className="text-xs text-emerald-200/90 mt-0.5">
                    Assigned workload ({durationHours}h) is within the safe rated threshold ({safeCapacity}h). Machine health will remain optimal.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Feature 1 Table: AI Fleet Ranking Matrix for this Workload */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/5 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2 uppercase tracking-wide">
              <Award className="w-4 h-4 text-cyan-400" />
              <span>AI Fleet Ranking Matrix for {durationHours}h Workload</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Comprehensive multi-criteria scoring of all 10 fleet nodes for this specific task duration.
            </p>
          </div>
          <span className="text-[10px] font-mono text-slate-400 bg-white/5 px-2.5 py-1 rounded-md border border-white/5">
            Ranked by AI Fitness Index (0-100)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-white/10 text-slate-400 text-[10px] uppercase font-mono tracking-wider">
                <th className="py-2.5 px-3">Rank</th>
                <th className="py-2.5 px-3">Machine</th>
                <th className="py-2.5 px-3">Health</th>
                <th className="py-2.5 px-3">Thermal / Vib</th>
                <th className="py-2.5 px-3">Current / Safe</th>
                <th className="py-2.5 px-3">Post Utilization</th>
                <th className="py-2.5 px-3">Suitability</th>
                <th className="py-2.5 px-3">AI Fit Score</th>
                <th className="py-2.5 px-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {(recommendation?.rankings || []).map((item) => {
                const isSelected = machineId === item.machine.id;
                const isBest = item.rank === 1;

                return (
                  <tr
                    key={item.machine.id}
                    className={`transition-colors ${
                      isSelected
                        ? 'bg-cyan-500/10'
                        : isBest
                        ? 'bg-cyan-500/5 hover:bg-cyan-500/10'
                        : 'hover:bg-white/5'
                    }`}
                  >
                    <td className="py-3 px-3 font-mono font-bold">
                      {isBest ? (
                        <span className="inline-flex items-center gap-1 text-cyan-400 bg-cyan-500/20 px-2 py-0.5 rounded-full text-[10px]">
                          <Award className="w-3 h-3" />
                          #1
                        </span>
                      ) : (
                        <span className="text-slate-500">#{item.rank}</span>
                      )}
                    </td>

                    <td className="py-3 px-3">
                      <div className="font-bold text-white flex items-center gap-1.5">
                        <span>{item.machine.code}</span>
                        {isSelected && (
                          <span className="text-[9px] bg-cyan-400 text-black px-1.5 py-0.2 rounded font-bold">
                            CURRENT
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 truncate max-w-[140px]">{item.machine.name}</div>
                    </td>

                    <td className="py-3 px-3 font-mono">
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            item.machine.healthScore > 80
                              ? 'indicator-green'
                              : item.machine.healthScore > 60
                              ? 'indicator-amber'
                              : 'indicator-red'
                          }`}
                        />
                        <span className="font-bold text-slate-200">{item.machine.healthScore}%</span>
                      </div>
                    </td>

                    <td className="py-3 px-3 font-mono text-[11px] text-slate-300">
                      <div>{item.machine.temperature}°C</div>
                      <div className="text-[10px] text-slate-500">{item.machine.vibration} mm/s</div>
                    </td>

                    <td className="py-3 px-3 font-mono text-slate-300">
                      <span>{item.machine.assignedHours}h</span>
                      <span className="text-slate-500"> / {item.machine.safeHours}h</span>
                    </td>

                    <td className="py-3 px-3 font-mono">
                      <span
                        className={`font-bold ${
                          item.projectedUtilization > 100
                            ? 'text-red-400'
                            : item.projectedUtilization > 80
                            ? 'text-amber-400'
                            : 'text-emerald-400'
                        }`}
                      >
                        {item.projectedUtilization}%
                      </span>
                    </td>

                    <td className="py-3 px-3">
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${
                          item.recommendation === 'BEST CHOICE'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : item.recommendation === 'RECOMMENDED'
                            ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                            : item.recommendation === 'ACCEPTABLE'
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {item.recommendation}
                      </span>
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-cyan-300">
                      {item.score} / 100
                    </td>

                    <td className="py-3 px-3 text-right">
                      {isSelected ? (
                        <span className="text-[10px] text-emerald-400 font-bold flex items-center justify-end gap-1">
                          <Check className="w-3.5 h-3.5" />
                          Selected
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => handleSelectRecommendedMachine(item.machine.id)}
                          className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-cyan-500 hover:text-black text-slate-300 text-[10px] font-bold border border-white/10 transition flex items-center gap-1 ml-auto"
                        >
                          <span>Select</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

