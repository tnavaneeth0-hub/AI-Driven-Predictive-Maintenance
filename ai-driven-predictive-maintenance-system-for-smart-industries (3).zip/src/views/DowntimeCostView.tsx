import React, { useState, useMemo } from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  DollarSign,
  Clock,
  TrendingUp,
  AlertOctagon,
  ShieldCheck,
  Zap,
  Download,
  BarChart2,
  PieChart,
  Activity,
  ArrowUpRight,
  Sparkles,
  RefreshCw,
  Layers
} from 'lucide-react';

export const DowntimeCostView: React.FC = () => {
  const { machines, downtimeRecords, downtimeStats, costAnalysis, setActiveTab } = useFactory();

  // Compute machine downtime aggregations from downtimeRecords & machine telemetry
  const machineDowntimeSummary = useMemo(() => {
    return machines.map((m) => {
      const records = downtimeRecords.filter((r) => r.machineId === m.id);
      const totalMinutes = records.reduce((sum, r) => sum + r.durationMinutes, 0);
      const totalCost = records.reduce((sum, r) => sum + r.estimatedCostLoss, 0);
      const incidentCount = records.length;
      const plannedMinutes = records
        .filter((r) => r.reason === 'SCHEDULED_MAINTENANCE' || r.reason === 'MANUAL_INSPECTION')
        .reduce((sum, r) => sum + r.durationMinutes, 0);
      const unplannedMinutes = records
        .filter((r) => r.reason === 'CRITICAL_OVERLOAD' || r.reason === 'EMERGENCY_OVERHAUL' || r.reason === 'THERMAL_TRIP')
        .reduce((sum, r) => sum + r.durationMinutes, 0);

      // Approximate MTBF & MTTR for display
      const mtbf = Math.round(m.totalOperatingHours / Math.max(1, m.failureHistoryCount || incidentCount));
      const mttr = (Math.max(1.2, totalMinutes / 60 / Math.max(1, incidentCount))).toFixed(1);

      return {
        id: m.id,
        code: m.code,
        name: m.name,
        healthScore: m.healthScore,
        mtbfHours: mtbf || 650,
        mttrHours: Number(mttr) || 2.1,
        totalHours: Number((totalMinutes / 60).toFixed(1)),
        plannedHours: Number((plannedMinutes / 60).toFixed(1)),
        unplannedHours: Number((unplannedMinutes / 60).toFixed(1)),
        totalCost,
        incidentCount,
      };
    });
  }, [machines, downtimeRecords]);

  // Root cause breakdown
  const rootCauseDistribution = useMemo(() => {
    const counts: Record<string, { count: number; minutes: number; cost: number }> = {};
    downtimeRecords.forEach((r) => {
      const label = r.reason.replace(/_/g, ' ');
      if (!counts[label]) {
        counts[label] = { count: 0, minutes: 0, cost: 0 };
      }
      counts[label].count += 1;
      counts[label].minutes += r.durationMinutes;
      counts[label].cost += r.estimatedCostLoss;
    });
    return Object.entries(counts).map(([cause, data]) => ({
      cause,
      hours: Number((data.minutes / 60).toFixed(1)),
      cost: data.cost,
      count: data.count,
    }));
  }, [downtimeRecords]);

  const totalDowntimeHours = machineDowntimeSummary.reduce((sum, m) => sum + m.totalHours, 0);
  const totalUnplannedHours = machineDowntimeSummary.reduce((sum, m) => sum + m.unplannedHours, 0);
  const avgMTBF = Math.round(machineDowntimeSummary.reduce((sum, m) => sum + m.mtbfHours, 0) / (machines.length || 1));
  const avgMTTR = (machineDowntimeSummary.reduce((sum, m) => sum + m.mttrHours, 0) / (machines.length || 1)).toFixed(1);

  const handleExportCSV = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      'Machine ID,Machine Name,Reason,Status,Duration (Min),Estimated Loss (INR),Start Time\n' +
      downtimeRecords
        .map(
          (r) =>
            `${r.machineCode},"${r.machineName}",${r.reason},${r.status},${r.durationMinutes},${r.estimatedCostLoss},${r.startTime}`
        )
        .join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `downtime_cost_matrix_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-150">
      {/* Header */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
                <DollarSign className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white tracking-wide">
                    Downtime Analytics & Financial Cost Matrix
                  </h2>
                  <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-400/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                    ROI ENGINE ACTIVE
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Real-time MTBF/MTTR telemetry, failure root-cause analysis, and AI preventative savings valuation.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition uppercase tracking-wider"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Export CSV Audit</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-black shadow-[0_0_15px_rgba(16,185,129,0.3)] transition uppercase tracking-wider"
            >
              <Sparkles className="w-4 h-4" />
              <span>View Executive Reports</span>
            </button>
          </div>
        </div>
      </div>

      {/* Financial ROI Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Net Predictive Savings */}
        <div className="bg-[#0b0e14] border border-emerald-500/30 rounded-2xl p-5 shadow-xl relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400">
              Net Loss Prevented by AI
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-bold text-emerald-300">
            {costAnalysis.currency}{costAnalysis.estimatedNetSavings.toLocaleString()}
          </div>
          <div className="flex items-center gap-1 text-[10px] text-emerald-400/90 font-mono mt-1">
            <ArrowUpRight className="w-3 h-3" />
            <span>{costAnalysis.savingsPercentage}% Net Cost Reduction</span>
          </div>
        </div>

        {/* Emergency Losses Avoided */}
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
              Emergency Overhauls Avoided
            </span>
            <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-400/30">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-bold text-cyan-300">
            {costAnalysis.currency}{costAnalysis.hypotheticalEmergencyCostAvoided.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            {costAnalysis.emergencyOverhaulsAvoidedCount} catastrophic failures prevented
          </div>
        </div>

        {/* MTBF (Mean Time Between Failures) */}
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
              Fleet MTBF Avg
            </span>
            <div className="p-1.5 rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-400/30">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-bold text-cyan-300">
            {avgMTBF} hrs
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Availability: {downtimeStats.fleetAvailabilityPercent}%
          </div>
        </div>

        {/* MTTR (Mean Time To Repair) */}
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between text-slate-400 mb-2">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">
              Fleet MTTR Avg
            </span>
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-mono font-bold text-amber-300">
            {avgMTTR} hrs
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            Total Fleet Downtime: {downtimeStats.totalFleetDowntimeHours}h
          </div>
        </div>
      </div>

      {/* Machine-by-Machine Downtime & MTBF Breakdown */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Machine Downtime & Reliability Comparison Matrix
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Live MTBF, MTTR, total downtime hours, and cumulative financial impact per industrial asset.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-white/10 text-[10px] uppercase font-mono font-bold text-slate-400 bg-white/[0.02]">
                <th className="py-3 px-4">Asset Code</th>
                <th className="py-3 px-4">Machine Name</th>
                <th className="py-3 px-4">Health</th>
                <th className="py-3 px-4">MTBF</th>
                <th className="py-3 px-4">MTTR</th>
                <th className="py-3 px-4">Total Downtime</th>
                <th className="py-3 px-4">Unplanned Hours</th>
                <th className="py-3 px-4 text-right">Incurred Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-mono">
              {machineDowntimeSummary.map((m) => (
                <tr key={m.id} className="hover:bg-white/[0.02] transition">
                  <td className="py-3 px-4 font-bold text-cyan-300">{m.code}</td>
                  <td className="py-3 px-4 text-white font-sans">{m.name}</td>
                  <td className="py-3 px-4">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        m.healthScore >= 80
                          ? 'bg-emerald-500/10 text-emerald-400'
                          : m.healthScore >= 50
                          ? 'bg-amber-500/10 text-amber-400'
                          : 'bg-red-500/10 text-red-400'
                      }`}
                    >
                      {m.healthScore}%
                    </span>
                  </td>
                  <td className="py-3 px-4 text-slate-300">{m.mtbfHours} hrs</td>
                  <td className="py-3 px-4 text-slate-300">{m.mttrHours} hrs</td>
                  <td className="py-3 px-4 text-slate-300 font-semibold">{m.totalHours} hrs</td>
                  <td className="py-3 px-4">
                    <span className={m.unplannedHours > 0 ? 'text-red-400 font-bold' : 'text-slate-500'}>
                      {m.unplannedHours} hrs
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right font-bold text-white">
                    {costAnalysis.currency}{m.totalCost.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Root Cause Analysis & Predictive Cost Savings */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Root Cause Distribution */}
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <PieChart className="w-4 h-4 text-cyan-400" />
              Downtime Root Cause Analysis
            </h3>
            <span className="text-[10px] font-mono text-slate-400">
              {downtimeRecords.length} Recorded Incidents
            </span>
          </div>

          <div className="space-y-3">
            {rootCauseDistribution.map((rc) => {
              const pct = totalDowntimeHours > 0 ? Math.min(100, Math.round((rc.hours / Math.max(0.1, totalDowntimeHours)) * 100)) : 0;
              return (
                <div key={rc.cause} className="bg-white/[0.02] border border-white/5 rounded-xl p-3">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-white uppercase font-mono text-[11px]">{rc.cause}</span>
                    <span className="font-mono text-slate-400">
                      {rc.hours} hrs ({pct}%) • {costAnalysis.currency}{rc.cost.toLocaleString()}
                    </span>
                  </div>
                  <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-cyan-400 h-full rounded-full transition-all duration-500"
                      style={{ width: `${Math.max(5, pct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Preventative vs Reactive Savings Modeling */}
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-white/5 pb-3">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <BarChart2 className="w-4 h-4 text-emerald-400" />
              Financial Savings Breakdown
            </h3>
            <span className="text-[10px] font-mono text-emerald-400 font-bold">
              AI ESTIMATION
            </span>
          </div>

          <div className="space-y-3 text-xs">
            <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex items-center justify-between">
              <div>
                <div className="font-bold text-white">Preventative Maintenance Outlay</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {costAnalysis.preventiveTasksCompletedCount} inspections @ {costAnalysis.currency}{costAnalysis.preventiveUnitCost.toLocaleString()}/ea
                </div>
              </div>
              <div className="text-right font-mono font-bold text-cyan-300">
                {costAnalysis.currency}{costAnalysis.actualPreventiveSpent.toLocaleString()}
              </div>
            </div>

            <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex items-center justify-between">
              <div>
                <div className="font-bold text-white">Avoided Emergency Overhaul Costs</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {costAnalysis.emergencyOverhaulsAvoidedCount} overhauls @ {costAnalysis.currency}{costAnalysis.emergencyUnitCost.toLocaleString()}/ea
                </div>
              </div>
              <div className="text-right font-mono font-bold text-emerald-400">
                +{costAnalysis.currency}{costAnalysis.hypotheticalEmergencyCostAvoided.toLocaleString()}
              </div>
            </div>

            <div className="bg-emerald-500/10 border border-emerald-500/40 rounded-xl p-4 flex items-center justify-between">
              <div>
                <div className="font-bold text-emerald-300 text-sm">Net Predictive Maintenance Benefit</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  Total savings after factoring scheduled maintenance costs
                </div>
              </div>
              <div className="text-right font-mono font-bold text-emerald-300 text-base">
                +{costAnalysis.currency}{costAnalysis.estimatedNetSavings.toLocaleString()}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
