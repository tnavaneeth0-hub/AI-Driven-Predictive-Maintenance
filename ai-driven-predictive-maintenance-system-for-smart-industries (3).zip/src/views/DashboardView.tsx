import React from 'react';
import { useFactory } from '../context/FactoryContext';
import { MachineCard } from '../components/MachineCard';
import { WorkloadEntryPanel } from '../components/WorkloadEntryPanel';
import {
  Cpu,
  ShieldCheck,
  AlertTriangle,
  Flame,
  ShieldAlert,
  Bell,
  Wrench,
  Sparkles,
  ArrowRight,
  Smartphone,
  Info,
  Radio,
  Zap,
  Clock,
  Activity
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const {
    machines,
    alerts,
    stats,
    setActiveTab,
    setSelectedMachineId,
    setIsWorkerMobileOpen,
    workerNotificationStats,
  } = useFactory();

  const activeCriticalAlerts = alerts.filter((a) => a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL');
  const activeAlerts = alerts.filter((a) => a.status === 'ACTIVE');

  return (
    <div className="space-y-5 animate-in fade-in duration-150">
      {/* Quick Direct Workload Assignment Section */}
      <WorkloadEntryPanel />

      {/* KPI Stats Grid - 8 Key Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* Total Machines */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-white/20 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Nodes</span>
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-light text-white mt-0.5 font-mono">{stats.totalMachines}</div>
          <span className="text-[9px] text-slate-500 font-mono">10 Industrial Units</span>
        </div>

        {/* Safe Machines */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-emerald-500/30 transition">
          <div className="flex items-center justify-between text-emerald-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Safe State</span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-light text-emerald-400 mt-0.5 font-mono">{stats.safeMachines}</div>
          <span className="text-[9px] text-emerald-500/70 font-mono">Within Capacity</span>
        </div>

        {/* Caution Machines */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-amber-500/30 transition">
          <div className="flex items-center justify-between text-amber-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Caution</span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-light text-amber-400 mt-0.5 font-mono">{stats.cautionMachines}</div>
          <span className="text-[9px] text-amber-500/70 font-mono">Unassigned / 90%</span>
        </div>

        {/* High-Risk Machines */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-orange-500/30 transition">
          <div className="flex items-center justify-between text-orange-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">High Risk</span>
            <Flame className="w-3.5 h-3.5 text-orange-400" />
          </div>
          <div className="text-2xl font-light text-orange-400 mt-0.5 font-mono">{stats.highRiskMachines}</div>
          <span className="text-[9px] text-orange-500/70 font-mono">Approaching Limit</span>
        </div>

        {/* Critical Overload */}
        <div
          className={`glass-card p-3 flex flex-col justify-between transition ${
            stats.criticalMachines > 0
              ? 'border-red-500/60 bg-red-500/10 shadow-[0_0_15px_rgba(255,62,62,0.25)]'
              : 'hover:border-white/20'
          }`}
        >
          <div className="flex items-center justify-between text-red-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-red-400">Critical</span>
            <ShieldAlert className="w-3.5 h-3.5 text-red-400 animate-pulse" />
          </div>
          <div
            className={`text-2xl font-light font-mono ${
              stats.criticalMachines > 0 ? 'text-red-400 animate-pulse' : 'text-white'
            } mt-0.5`}
          >
            {stats.criticalMachines}
          </div>
          <span className="text-[9px] text-red-400/80 font-mono">&gt;100% Load / Unassigned</span>
        </div>

        {/* Active Alerts */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-white/20 transition">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Alerts</span>
            <Bell className="w-3.5 h-3.5 text-amber-400" />
          </div>
          <div className="text-2xl font-light text-amber-400 mt-0.5 font-mono">{stats.activeAlerts}</div>
          <span className="text-[9px] text-slate-500 font-mono">Active Incidents</span>
        </div>

        {/* Worker Push Dispatch */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-cyan-500/30 transition">
          <div className="flex items-center justify-between text-cyan-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Push Sent</span>
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="text-2xl font-light text-cyan-400 mt-0.5 font-mono">
            {workerNotificationStats.sent}
          </div>
          <span className="text-[9px] text-slate-500 font-mono">{workerNotificationStats.acknowledged} Acked</span>
        </div>

        {/* Factory Availability */}
        <div className="glass-card p-3 flex flex-col justify-between hover:border-emerald-500/30 transition">
          <div className="flex items-center justify-between text-emerald-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Availability</span>
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="text-2xl font-light text-emerald-400 mt-0.5 font-mono">{stats.factoryAvailability}%</div>
          <span className="text-[9px] text-emerald-500/70 font-mono">Live Uptime</span>
        </div>
      </div>

      {/* Active Critical Alerts Callout Banner */}
      {activeCriticalAlerts.length > 0 && (
        <div className="glass-card bg-red-600/10 border-red-500/60 p-4 border-l-4 border-l-red-500 shadow-[0_0_25px_rgba(255,62,62,0.2)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-pulse">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600 border border-red-400 flex items-center justify-center text-white font-bold shadow-[0_0_15px_rgba(255,62,62,0.6)] shrink-0">
              <ShieldAlert className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                  {activeCriticalAlerts[0].title}
                </span>
                <span className="text-[10px] text-red-300 font-mono bg-red-500/20 px-2 py-0.2 rounded border border-red-500/40">
                  {activeCriticalAlerts[0].alertType}
                </span>
              </div>
              <p className="text-xs text-slate-200 mt-1">{activeCriticalAlerts[0].message}</p>
              {activeCriticalAlerts[0].aiRecommendation && (
                <p className="text-[11px] text-cyan-300 mt-1 font-mono">
                  <strong>Recommended Action:</strong> {activeCriticalAlerts[0].aiRecommendation}
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
            <button
              onClick={() => setIsWorkerMobileOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 shadow transition uppercase"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Worker App</span>
            </button>

            <button
              onClick={() => {
                setSelectedMachineId(activeCriticalAlerts[0].machineId);
                setActiveTab('alerts');
              }}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold bg-red-600 hover:bg-red-500 text-white shadow-[0_0_15px_rgba(255,62,62,0.5)] transition uppercase tracking-wider"
            >
              <span>Review in Alert Center</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* Factory Floor Machine Grid (10 Machines) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Factory Machine Fleet (10 Monitored Units)
            </h2>
            <span className="text-[10px] bg-white/5 border border-white/10 text-slate-400 px-2 py-0.5 rounded font-mono uppercase">
              Condition 1 & Condition 2 Live Monitor
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('work-allocation')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>Allocate Workload</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {machines.map((machine) => (
            <MachineCard
              key={machine.id}
              machine={machine}
              onOpenAssign={(m) => {
                setSelectedMachineId(m.id);
                setActiveTab('work-allocation');
              }}
              onOpenDiagnose={(m) => {
                setSelectedMachineId(m.id);
                setActiveTab('predictions');
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
