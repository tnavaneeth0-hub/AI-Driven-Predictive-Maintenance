import React, { useState } from 'react';
import {
  Layers,
  Database,
  Cpu,
  Server,
  Smartphone,
  ShieldAlert,
  Code,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  ExternalLink,
  BookOpen,
  GitBranch,
  Terminal,
  Radio
} from 'lucide-react';

export const ArchitectureDocsView: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'architecture' | 'database' | 'apis' | 'stack' | 'limitations'>('architecture');

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/5 pb-4">
        <div>
          <h2 className="text-lg font-bold tracking-tight text-white flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            System Architecture, Database Models & API Specifications
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Technical engineering documentation for CSE mini project review and demonstration.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] font-mono font-bold uppercase text-cyan-400 bg-cyan-500/10 border border-cyan-400/30 px-2.5 py-1 rounded-lg">
            CSE Project Specification
          </span>
        </div>
      </div>

      {/* Sub navigation bar */}
      <div className="glass-card p-1.5 flex items-center gap-1.5 overflow-x-auto scrollbar-none text-xs">
        <button
          onClick={() => setActiveSubTab('architecture')}
          className={`px-3 py-1.5 rounded-lg font-medium transition ${
            activeSubTab === 'architecture'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,212,255,0.3)]'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          1. System Architecture Flow
        </button>
        <button
          onClick={() => setActiveSubTab('database')}
          className={`px-3 py-1.5 rounded-lg font-medium transition ${
            activeSubTab === 'database'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,212,255,0.3)]'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          2. Database Relational Models (9 Tables)
        </button>
        <button
          onClick={() => setActiveSubTab('apis')}
          className={`px-3 py-1.5 rounded-lg font-medium transition ${
            activeSubTab === 'apis'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,212,255,0.3)]'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          3. REST API Specification
        </button>
        <button
          onClick={() => setActiveSubTab('stack')}
          className={`px-3 py-1.5 rounded-lg font-medium transition ${
            activeSubTab === 'stack'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,212,255,0.3)]'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          4. Tech Stack & ML Algorithms
        </button>
        <button
          onClick={() => setActiveSubTab('limitations')}
          className={`px-3 py-1.5 rounded-lg font-medium transition ${
            activeSubTab === 'limitations'
              ? 'bg-cyan-500 text-black font-bold shadow-[0_0_12px_rgba(0,212,255,0.3)]'
              : 'text-slate-400 hover:text-white hover:bg-white/5'
          }`}
        >
          5. Prototype Scope & Limitations
        </button>
      </div>

      {/* 1. SYSTEM ARCHITECTURE FLOW */}
      {activeSubTab === 'architecture' && (
        <div className="space-y-4">
          <div className="glass-card p-5 space-y-4">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              End-to-End Predictive Maintenance Architecture Pipeline
            </h3>

            {/* Architecture Diagram Visual Flow */}
            <div className="bg-black/60 rounded-xl p-4 border border-white/5 space-y-3 font-mono text-xs">
              <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-center">
                <div className="w-full md:w-1/4 p-3 rounded-lg bg-cyan-500/10 border border-cyan-400/30 text-cyan-300">
                  <span className="font-bold block text-white">ADMIN DASHBOARD</span>
                  <span className="text-[10px] text-slate-400">Work Allocation & Monitoring</span>
                </div>
                <span className="text-slate-500">➔</span>
                <div className="w-full md:w-1/4 p-3 rounded-lg bg-white/5 border border-white/10 text-white">
                  <span className="font-bold block">FASTAPI / EXPRESS BACKEND</span>
                  <span className="text-[10px] text-slate-400">REST APIs & Data Persistence</span>
                </div>
                <span className="text-slate-500">➔</span>
                <div className="w-full md:w-1/4 p-3 rounded-lg bg-purple-500/10 border border-purple-400/30 text-purple-300">
                  <span className="font-bold block text-white">AI / ML RISK ENGINE</span>
                  <span className="text-[10px] text-slate-400">Capacity & Health Analysis</span>
                </div>
              </div>

              <div className="text-center text-slate-500 py-1">⬇ (Critical Overload Detected)</div>

              <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-center">
                <div className="w-full md:w-1/3 p-3 rounded-lg bg-red-500/10 border border-red-500/40 text-red-300">
                  <span className="font-bold block text-white">ALERT ENGINE & SIREN</span>
                  <span className="text-[10px] text-slate-400">Web Audio Frequency Siren</span>
                </div>
                <span className="text-slate-500">➔</span>
                <div className="w-full md:w-1/3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/40 text-amber-300">
                  <span className="font-bold block text-white">PUSH NOTIFICATION SERVICE</span>
                  <span className="text-[10px] text-slate-400">FCM High Priority Broadcast</span>
                </div>
                <span className="text-slate-500">➔</span>
                <div className="w-full md:w-1/3 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/40 text-emerald-300">
                  <span className="font-bold block text-white">WORKER ANDROID APP</span>
                  <span className="text-[10px] text-slate-400">Lock-Screen Banner + Sound/Vibe</span>
                </div>
              </div>

              <div className="text-center text-slate-500 py-1">⬇ (Worker Acknowledgment & Smart Work Redistribution)</div>

              <div className="p-3 rounded-lg bg-gradient-to-r from-emerald-950/40 via-cyan-950/30 to-slate-900 border border-emerald-500/40 text-center">
                <span className="font-bold text-emerald-400 block">
                  AUTOMATED SMART LOAD REDISTRIBUTION & RISK MITIGATION
                </span>
                <span className="text-[11px] text-slate-300">
                  Work transferred from overloaded asset (M-01) to high-buffer alternative (M-06) ➔ Workload normalized ➔ Siren deactivated ➔ Event logged to History Audit
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. DATABASE RELATIONAL MODELS */}
      {activeSubTab === 'database' && (
        <div className="space-y-4">
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              PostgreSQL Relational Database Schema (9 Required Tables)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-cyan-400 block border-b border-white/5 pb-1">1. users</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">name (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">email (VARCHAR UNIQUE)</p>
                <p className="text-[11px] text-slate-400">password_hash (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">role ('ADMIN' | 'WORKER')</p>
                <p className="text-[11px] text-slate-400">created_at (TIMESTAMP)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-cyan-400 block border-b border-white/5 pb-1">2. machines</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">machine_code (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">name (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">safe_capacity_hours (FLOAT)</p>
                <p className="text-[11px] text-slate-400">health_score (INT)</p>
                <p className="text-[11px] text-slate-400">status (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">last_maintenance (DATE)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-cyan-400 block border-b border-white/5 pb-1">3. work_assignments</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">machine_id (FK machines)</p>
                <p className="text-[11px] text-slate-400">worker_id (FK users)</p>
                <p className="text-[11px] text-slate-400">task_name (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">work_hours (FLOAT)</p>
                <p className="text-[11px] text-slate-400">priority (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">expected_completion (TIMESTAMP)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-purple-400 block border-b border-white/5 pb-1">4. predictions</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">machine_id (FK machines)</p>
                <p className="text-[11px] text-slate-400">risk_score (FLOAT)</p>
                <p className="text-[11px] text-slate-400">risk_level (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">explanation (JSON)</p>
                <p className="text-[11px] text-slate-400">recommendation (TEXT)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-red-400 block border-b border-white/5 pb-1">5. alerts</span>
                <p className="text-[11px] text-slate-400">id (VARCHAR PK)</p>
                <p className="text-[11px] text-slate-400">machine_id (FK machines)</p>
                <p className="text-[11px] text-slate-400">alert_type (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">severity ('CRITICAL' | 'HIGH')</p>
                <p className="text-[11px] text-slate-400">risk_score (FLOAT)</p>
                <p className="text-[11px] text-slate-400">status ('ACTIVE' | 'RESOLVED')</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-emerald-400 block border-b border-white/5 pb-1">6. workers</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">user_id (FK users)</p>
                <p className="text-[11px] text-slate-400">department (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">device_token (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">notification_enabled (BOOL)</p>
                <p className="text-[11px] text-slate-400">last_seen (TIMESTAMP)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-amber-400 block border-b border-white/5 pb-1">7. notifications</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">alert_id (FK alerts)</p>
                <p className="text-[11px] text-slate-400">worker_id (FK workers)</p>
                <p className="text-[11px] text-slate-400">delivery_status (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">opened_at (TIMESTAMP)</p>
                <p className="text-[11px] text-slate-400">acknowledged_at (TIMESTAMP)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-cyan-400 block border-b border-white/5 pb-1">8. maintenance</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">machine_id (FK machines)</p>
                <p className="text-[11px] text-slate-400">maintenance_type (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">scheduled_date (DATE)</p>
                <p className="text-[11px] text-slate-400">status (VARCHAR)</p>
                <p className="text-[11px] text-slate-400">notes (TEXT)</p>
              </div>

              <div className="p-3 rounded-xl bg-black/40 border border-white/5 space-y-1">
                <span className="font-bold text-slate-300 block border-b border-white/5 pb-1">9. machine_history</span>
                <p className="text-[11px] text-slate-400">id (UUID PK)</p>
                <p className="text-[11px] text-slate-400">machine_id (FK machines)</p>
                <p className="text-[11px] text-slate-400">workload (FLOAT)</p>
                <p className="text-[11px] text-slate-400">operating_hours (FLOAT)</p>
                <p className="text-[11px] text-slate-400">health_score (INT)</p>
                <p className="text-[11px] text-slate-400">overload_event (BOOL)</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. REST API SPECIFICATION */}
      {activeSubTab === 'apis' && (
        <div className="space-y-4">
          <div className="glass-card p-5">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
              <Server className="w-4 h-4 text-cyan-400" />
              REST API Endpoints Specification
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-black/60 text-slate-400 uppercase tracking-wider border-b border-white/5 text-[10px]">
                  <tr>
                    <th className="py-2.5 px-3">Method</th>
                    <th className="py-2.5 px-3">Endpoint</th>
                    <th className="py-2.5 px-3">Description</th>
                    <th className="py-2.5 px-3">Response Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-bold">POST</td>
                    <td className="py-2 px-3 text-white">/api/auth/login</td>
                    <td className="py-2 px-3 text-slate-300">Authenticate admin/worker JWT</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK + Token</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-cyan-400 font-bold">GET</td>
                    <td className="py-2 px-3 text-white">/api/machines</td>
                    <td className="py-2 px-3 text-slate-300">Fetch all 10 monitored machines</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-bold">POST</td>
                    <td className="py-2 px-3 text-white">/api/work-assignments</td>
                    <td className="py-2 px-3 text-slate-300">Allocate workload and calculate risk</td>
                    <td className="py-2 px-3 text-cyan-400">201 Created</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-bold">POST</td>
                    <td className="py-2 px-3 text-white">/api/ai/diagnose</td>
                    <td className="py-2 px-3 text-slate-300">Multi-factor ML risk prediction & explanation</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-cyan-400 font-bold">GET</td>
                    <td className="py-2 px-3 text-white">/api/alerts</td>
                    <td className="py-2 px-3 text-slate-300">Retrieve active & historical incident logs</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-bold">POST</td>
                    <td className="py-2 px-3 text-white">/api/alerts/:id/acknowledge</td>
                    <td className="py-2 px-3 text-slate-300">Worker emergency acknowledgment</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK</td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-bold">POST</td>
                    <td className="py-2 px-3 text-white">/api/notifications/send</td>
                    <td className="py-2 px-3 text-slate-300">Dispatch FCM push notification payload</td>
                    <td className="py-2 px-3 text-cyan-400">200 OK</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. TECH STACK & ML ALGORITHMS */}
      {activeSubTab === 'stack' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="glass-card p-5 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Code className="w-4 h-4 text-cyan-400" />
                Frontend & UI Engineering
              </h3>
              <ul className="space-y-2 text-xs text-slate-300">
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400">▪</span>
                  <span><strong>React 18 + TypeScript:</strong> Modular state-driven architecture with context synchronization.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400">▪</span>
                  <span><strong>Tailwind CSS + Glassmorphism:</strong> Dark industrial control center aesthetic.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400">▪</span>
                  <span><strong>Web Audio API:</strong> Synthesized 750 Hz ± 250 Hz LFO frequency modulated software siren.</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-400">▪</span>
                  <span><strong>Recharts Data Visualizations:</strong> Real-time workload ratios, health trends, and failure risk indexes.</span>
                </li>
              </ul>
            </div>

            <div className="glass-card p-5 space-y-3">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                AI / ML Predictive Risk Formula
              </h3>
              <div className="bg-black/60 rounded-xl p-3 border border-white/5 font-mono text-xs space-y-1.5">
                <p className="text-purple-300 font-bold">Risk Equation:</p>
                <p className="text-slate-300">Workload Ratio (R) = Assigned Hours / Safe Capacity Hours</p>
                <p className="text-slate-300">Health Penalty (H) = (100 - HealthScore) * 0.35</p>
                <p className="text-slate-300">Overload Weight (O) = OverloadEvents * 6.5</p>
                <p className="text-emerald-400 font-bold">Predicted Failure Risk % = Min(98%, R * 48% + H + O)</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 5. PROTOTYPE SCOPE & LIMITATIONS (Master Prompt Section 33) */}
      {activeSubTab === 'limitations' && (
        <div className="space-y-4">
          <div className="glass-card p-5 border-amber-500/30 bg-amber-500/5 space-y-3">
            <h3 className="text-sm font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              CSE Project Scope & Real-World Realization Notes
            </h3>

            <div className="space-y-2 text-xs text-slate-300 leading-relaxed">
              <p>
                <strong>1. Software-Only Simulation:</strong> This platform is an engineering simulation for demonstration and evaluation purposes. There are <strong>no physical hardware or physical sirens</strong> attached.
              </p>
              <p>
                <strong>2. Simulated Sensor Telemetry:</strong> Machine vibration, thermal dissipation, RPM, and power draw are modeled mathematically based on industrial degradation profiles. The system is architected with standard REST ingestion endpoints ready for physical IoT gateway integration (MQTT / OPC-UA).
              </p>
              <p>
                <strong>3. Software Siren & Push Notifications:</strong> The siren is generated in the browser via Web Audio oscillator nodes. Mobile push notifications and lock-screen alerts are simulated via progressive web patterns and interactive Android device frames.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
