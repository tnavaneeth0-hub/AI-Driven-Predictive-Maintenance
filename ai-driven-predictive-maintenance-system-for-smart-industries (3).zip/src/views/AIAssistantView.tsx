import React, { useState, useRef, useEffect } from 'react';
import { useFactory } from '../context/FactoryContext';
import {
  Bot,
  Send,
  Sparkles,
  AlertTriangle,
  Flame,
  Activity,
  CheckCircle2,
  Clock,
  ArrowRight,
  Zap,
  HelpCircle,
  RotateCcw,
  Sliders,
  Wrench,
  ShieldAlert
} from 'lucide-react';

export const AIAssistantView: React.FC = () => {
  const {
    chatMessages,
    askAIAssistant,
    machines,
    alerts,
    stats,
    setActiveTab,
    setSelectedMachineId,
    autoScheduleMaintenanceForRisk,
  } = useFactory();

  const [inputQuery, setInputQuery] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isTyping]);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim()) return;

    setInputQuery('');
    setIsTyping(true);

    try {
      await askAIAssistant(textToSend.trim());
    } finally {
      setIsTyping(false);
    }
  };

  const quickPrompts = [
    {
      title: 'Maintenance Priority',
      query: 'Which machine needs maintenance first?',
      icon: Wrench,
      color: 'text-amber-400 border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20',
    },
    {
      title: 'Danger Analysis',
      query: 'Which machine is most dangerous right now?',
      icon: Flame,
      color: 'text-red-400 border-red-500/30 bg-red-500/10 hover:bg-red-500/20',
    },
    {
      title: 'Workload Allocation',
      query: 'Which machine should receive this workload?',
      icon: Sliders,
      color: 'text-cyan-400 border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20',
    },
    {
      title: 'Alert Root Cause',
      query: "What caused today's alerts and anomalies?",
      icon: ShieldAlert,
      color: 'text-purple-400 border-purple-500/30 bg-purple-500/10 hover:bg-purple-500/20',
    },
    {
      title: 'Cost Savings Breakdown',
      query: 'What is the financial cost comparison between preventive and emergency maintenance?',
      icon: Zap,
      color: 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10 hover:bg-emerald-500/20',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center text-cyan-400 shadow-[0_0_20px_rgba(0,212,255,0.25)]">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-wide">
                  AI Smart Maintenance Assistant
                </h2>
                <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                  LIVE TELEMETRY CO-PILOT
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Real-time natural language queries grounded directly in 10-node physical telemetry, predictive ML models, and maintenance logs.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Telemetry Status</div>
              <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5 justify-end">
                <span className="w-1.5 h-1.5 rounded-full indicator-green" />
                <span>10 Nodes Stream Active</span>
              </div>
            </div>
            <div className="bg-white/5 border border-white/10 rounded-xl px-3.5 py-2 text-right">
              <div className="text-[10px] text-slate-400 uppercase font-mono">Active Alerts</div>
              <div className="text-xs font-bold text-amber-400">
                {stats.activeAlerts} Active
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Grid: Chat Area + Context Sidebar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Panel */}
        <div className="lg:col-span-2 bg-[#0b0e14] border border-white/10 rounded-2xl flex flex-col h-[650px] shadow-xl overflow-hidden">
          {/* Chat Messages Body */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
            {chatMessages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex items-start gap-3 ${isUser ? 'flex-row-reverse' : ''}`}
                >
                  <div
                    className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                      isUser
                        ? 'bg-slate-700 text-slate-200 border border-slate-600'
                        : 'bg-cyan-500/20 text-cyan-400 border border-cyan-400/40'
                    }`}
                  >
                    {isUser ? <span className="text-xs font-bold">ME</span> : <Bot className="w-4 h-4" />}
                  </div>

                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed ${
                      isUser
                        ? 'bg-cyan-600/20 border border-cyan-500/40 text-cyan-50 rounded-tr-none'
                        : 'bg-white/5 border border-white/10 text-slate-200 rounded-tl-none shadow-lg'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-4 mb-1.5 pb-1 border-b border-white/5">
                      <span className="font-semibold text-xs text-slate-400">
                        {isUser ? 'Operator Request' : 'AI Maintenance Engine'}
                      </span>
                      <span className="text-[10px] text-slate-500 font-mono">{msg.timestamp}</span>
                    </div>

                    <div className="whitespace-pre-wrap space-y-2">
                      {msg.text.split('\n\n').map((paragraph, idx) => (
                        <p key={idx}>{paragraph}</p>
                      ))}
                    </div>

                    {/* Referenced Metrics Pills */}
                    {msg.metricsReferenced && msg.metricsReferenced.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center gap-1.5 flex-wrap">
                        <span className="text-[10px] text-slate-400 uppercase font-mono">Live Grounding:</span>
                        {msg.metricsReferenced.map((metric, i) => (
                          <span
                            key={i}
                            className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-cyan-300 border border-white/10"
                          >
                            {metric}
                          </span>
                        ))}
                      </div>
                    )}

                    {/* Action Links */}
                    {msg.actionLink && (
                      <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center gap-2">
                        <button
                          onClick={() => {
                            if (msg.actionLink?.tab) setActiveTab(msg.actionLink.tab);
                            if (msg.actionLink?.machineId) setSelectedMachineId(msg.actionLink.machineId);
                          }}
                          className="flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-400/40 transition"
                        >
                          <span>{msg.actionLink.label}</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}

                    {/* Follow-up Prompts */}
                    {msg.suggestedPrompts && msg.suggestedPrompts.length > 0 && (
                      <div className="mt-3 pt-2.5 border-t border-white/10">
                        <div className="text-[10px] text-slate-400 mb-1.5 font-medium">Follow-up inquiries:</div>
                        <div className="flex flex-wrap gap-1.5">
                          {msg.suggestedPrompts.map((prompt, i) => (
                            <button
                              key={i}
                              onClick={() => handleSend(prompt)}
                              className="text-[11px] px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/10 transition text-left"
                            >
                              {prompt}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {isTyping && (
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-400/40 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
                <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-none p-4 text-xs text-slate-400 flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span>AI Predictive Engine analyzing real-time fleet telemetry...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input Box */}
          <div className="p-4 border-t border-white/10 bg-[#080a0f]">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                id="ai-assistant-input"
                type="text"
                value={inputQuery}
                onChange={(e) => setInputQuery(e.target.value)}
                placeholder="Ask about machine health, overloads, maintenance priorities..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition"
              />
              <button
                id="ai-assistant-send-btn"
                type="submit"
                disabled={!inputQuery.trim() || isTyping}
                className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-40 text-black font-bold text-xs flex items-center gap-1.5 shadow-[0_0_15px_rgba(0,212,255,0.3)] transition"
              >
                <span>Send</span>
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>

        {/* Sidebar: Quick Prompts & Fleet At-A-Glance */}
        <div className="space-y-6">
          {/* Quick Prompts Panel */}
          <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-300 uppercase tracking-wider">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span>Recommended Inquiries</span>
            </div>

            <div className="space-y-2">
              {quickPrompts.map((p, idx) => {
                const Icon = p.icon;
                return (
                  <button
                    key={idx}
                    onClick={() => handleSend(p.query)}
                    className={`w-full p-3 rounded-xl border text-left transition flex items-start gap-3 ${p.color}`}
                  >
                    <Icon className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-semibold text-xs">{p.title}</div>
                      <div className="text-[11px] opacity-80 mt-0.5 line-clamp-1">{p.query}</div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Machine Condition Quick Matrix */}
          <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-5 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold text-slate-300 uppercase tracking-wider">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>Live Fleet Status</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">10 Nodes</span>
            </div>

            <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
              {machines.map((m) => (
                <div
                  key={m.id}
                  onClick={() => {
                    setSelectedMachineId(m.id);
                    setActiveTab('machines');
                  }}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/5 cursor-pointer transition text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        m.healthScore > 80
                          ? 'indicator-green'
                          : m.healthScore > 60
                          ? 'indicator-amber'
                          : 'indicator-red'
                      }`}
                    />
                    <span className="font-bold text-white">{m.code}</span>
                    <span className="text-[10px] text-slate-400 truncate max-w-[110px]">{m.name}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-slate-300">{m.healthScore}%</span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                        m.riskLevel === 'SAFE'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : m.riskLevel === 'CAUTION'
                          ? 'bg-amber-500/20 text-amber-400'
                          : 'bg-red-500/20 text-red-400'
                      }`}
                    >
                      {m.riskLevel}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
