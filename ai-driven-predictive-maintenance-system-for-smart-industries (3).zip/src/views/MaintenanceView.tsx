import React, { useState, useMemo } from 'react';
import { useFactory } from '../context/FactoryContext';
import { MaintenanceRecord, PriorityLevel } from '../types';
import {
  Wrench,
  Calendar as CalendarIcon,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  ShieldCheck,
  Cpu,
  User,
  X,
  FileText,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  Trash2,
  Edit3
} from 'lucide-react';

export const MaintenanceView: React.FC = () => {
  const {
    machines,
    maintenanceRecords,
    scheduleMaintenance,
    completeMaintenance,
    autoScheduleMaintenanceForRisk,
    rescheduleMaintenance,
    cancelMaintenance,
    selectedMachineId,
  } = useFactory();

  const [viewMode, setViewMode] = useState<'CALENDAR' | 'LIST'>('CALENDAR');
  const [filter, setFilter] = useState<'ALL' | 'UPCOMING' | 'COMPLETED'>('ALL');
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState<MaintenanceRecord | null>(null);

  // Calendar month state
  const [currentMonthDate, setCurrentMonthDate] = useState(() => new Date());

  // Form states
  const [selectedMachine, setSelectedMachine] = useState<string>(selectedMachineId || 'M-01');
  const [maintType, setMaintType] = useState<MaintenanceRecord['type']>('PREVENTATIVE');
  const [maintPriority, setMaintPriority] = useState<PriorityLevel>('NORMAL');
  const [techName, setTechName] = useState<string>('Alex Vance (Lead Mech Tech)');
  const [notes, setNotes] = useState<string>('Routine spindle balance and lubrication overhaul.');
  const [scheduledDate, setScheduledDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const filteredRecords = maintenanceRecords.filter((r) => {
    if (filter === 'UPCOMING') return r.status === 'UPCOMING' || r.status === 'IN_PROGRESS' || r.status === 'OVERDUE';
    if (filter === 'COMPLETED') return r.status === 'COMPLETED';
    return true;
  });

  const handleScheduleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingRecord) {
      rescheduleMaintenance(editingRecord.id, scheduledDate, techName, notes);
      setEditingRecord(null);
    } else {
      scheduleMaintenance(selectedMachine, maintType, maintPriority, notes, techName, scheduledDate);
    }
    setShowScheduleModal(false);
  };

  const openRescheduleModal = (record: MaintenanceRecord) => {
    setEditingRecord(record);
    setSelectedMachine(record.machineId);
    setMaintType(record.type);
    setMaintPriority(record.priority);
    setTechName(record.technicianName);
    setNotes(record.notes);
    setScheduledDate(record.scheduledDate);
    setShowScheduleModal(true);
  };

  const machinesNeedingService = machines.filter((m) => m.healthScore < 80 || m.status === 'OVERLOADED');

  // Calendar calculations
  const year = currentMonthDate.getFullYear();
  const month = currentMonthDate.getMonth();
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay();

  const calendarDays = useMemo(() => {
    const days: Array<{ dayNumber: number; dateStr: string; records: MaintenanceRecord[] }> = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const dayStr = d < 10 ? `0${d}` : `${d}`;
      const monthStr = month + 1 < 10 ? `0${month + 1}` : `${month + 1}`;
      const dateStr = `${year}-${monthStr}-${dayStr}`;
      const dayRecords = maintenanceRecords.filter((r) => r.scheduledDate === dateStr);
      days.push({ dayNumber: d, dateStr, records: dayRecords });
    }
    return days;
  }, [year, month, daysInMonth, maintenanceRecords]);

  const handlePrevMonth = () => {
    setCurrentMonthDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentMonthDate(new Date(year, month + 1, 1));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-400">
                <Wrench className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-white tracking-wide">
                    Predictive Maintenance Calendar & Fleet Scheduling
                  </h2>
                  <span className="bg-cyan-500/20 text-cyan-300 border border-cyan-400/40 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full">
                    AUTO-DISPATCH READY
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">
                  Plan, visualize, and auto-dispatch preventative overhauls to preserve machine health scores above 85%.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2.5 flex-wrap">
            {/* View Mode Toggle */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-1 flex items-center">
              <button
                onClick={() => setViewMode('CALENDAR')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition uppercase tracking-wider flex items-center gap-1.5 ${
                  viewMode === 'CALENDAR'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <CalendarIcon className="w-3.5 h-3.5" />
                <span>Calendar</span>
              </button>
              <button
                onClick={() => setViewMode('LIST')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition uppercase tracking-wider flex items-center gap-1.5 ${
                  viewMode === 'LIST'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>List View</span>
              </button>
            </div>

            {/* AI Auto-Schedule Button */}
            <button
              onClick={autoScheduleMaintenanceForRisk}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 transition uppercase tracking-wider"
              title="Automatically schedule maintenance for all high-risk or degraded machines"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>AI Auto-Schedule</span>
            </button>

            {/* Manual Schedule Button */}
            <button
              onClick={() => {
                setEditingRecord(null);
                setShowScheduleModal(true);
              }}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)] transition uppercase tracking-wider"
            >
              <Plus className="w-4 h-4" />
              <span>Schedule Service</span>
            </button>
          </div>
        </div>
      </div>

      {/* Recommended Maintenance Alert if any machine health < 80 */}
      {machinesNeedingService.length > 0 && (
        <div className="bg-[#0b0e14] border border-amber-500/40 rounded-2xl p-5 shadow-xl">
          <div className="flex items-center justify-between gap-2.5 mb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <h3 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                AI Priority Attention Queue ({machinesNeedingService.length} Assets Need Service)
              </h3>
            </div>
            <button
              onClick={autoScheduleMaintenanceForRisk}
              className="text-[11px] font-bold text-amber-400 hover:text-amber-300 underline font-mono"
            >
              1-Click Schedule All High-Risk
            </button>
          </div>
          <p className="text-xs text-slate-300 mb-3">
            Assets below 80% health or bearing thermal fatigue risk:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {machinesNeedingService.map((m) => (
              <div
                key={m.id}
                className="bg-black/40 border border-white/5 rounded-xl p-3 flex items-center justify-between"
              >
                <div>
                  <h4 className="text-xs font-bold text-white">{m.code}</h4>
                  <span className="text-[10px] text-slate-400 font-mono">{m.name}</span>
                </div>
                <div className="text-right">
                  <span className={`text-xs font-mono font-bold block ${m.healthScore < 50 ? 'text-red-400' : 'text-amber-400'}`}>
                    Health: {m.healthScore}%
                  </span>
                  <button
                    onClick={() => {
                      setSelectedMachine(m.id);
                      setMaintType('CORRECTIVE');
                      setMaintPriority('HIGH');
                      setNotes(`Comprehensive mechanical overhaul for ${m.code} to alleviate fatigue strain.`);
                      setShowScheduleModal(true);
                    }}
                    className="text-[10px] text-cyan-400 hover:text-cyan-300 font-bold uppercase tracking-wider mt-0.5"
                  >
                    Schedule Service →
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main View: Calendar or List */}
      {viewMode === 'CALENDAR' ? (
        /* Feature 3: Interactive Calendar Grid */
        <div className="bg-[#0b0e14] border border-white/10 rounded-2xl p-6 shadow-xl space-y-4">
          {/* Calendar Month Header Navigation */}
          <div className="flex items-center justify-between border-b border-white/5 pb-4">
            <div className="flex items-center gap-3">
              <h3 className="text-base font-bold text-white tracking-wide">
                {monthNames[month]} {year}
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                ({maintenanceRecords.length} total scheduled / completed)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrevMonth}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => setCurrentMonthDate(new Date())}
                className="px-3 py-1 text-xs font-bold rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition"
              >
                Today
              </button>
              <button
                onClick={handleNextMonth}
                className="p-2 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5 transition"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Weekday Labels */}
          <div className="grid grid-cols-7 gap-2 text-center text-[10px] uppercase font-mono font-bold text-slate-400 py-1">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Days Grid */}
          <div className="grid grid-cols-7 gap-2">
            {/* Empty offset padding for first day */}
            {Array.from({ length: firstDayOfWeek }).map((_, i) => (
              <div key={`empty-${i}`} className="min-h-[100px] rounded-xl bg-white/[0.01] border border-white/5 opacity-30" />
            ))}

            {calendarDays.map((item) => {
              const isToday =
                item.dateStr === new Date().toISOString().split('T')[0];

              return (
                <div
                  key={item.dateStr}
                  className={`min-h-[110px] rounded-xl p-2.5 border transition-all flex flex-col justify-between ${
                    isToday
                      ? 'bg-cyan-500/10 border-cyan-400/40 shadow-[0_0_12px_rgba(0,212,255,0.1)]'
                      : item.records.length > 0
                      ? 'bg-[#12151d] border-white/10 hover:border-cyan-500/30'
                      : 'bg-white/[0.02] border-white/5 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-mono font-bold ${
                        isToday ? 'text-cyan-400 font-black' : 'text-slate-400'
                      }`}
                    >
                      {item.dayNumber}
                    </span>
                    {item.records.length > 0 && (
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-white/10 text-cyan-300">
                        {item.records.length} {item.records.length === 1 ? 'task' : 'tasks'}
                      </span>
                    )}
                  </div>

                  {/* Tasks on this Day */}
                  <div className="space-y-1 mt-1.5 flex-1 overflow-y-auto max-h-[85px] pr-0.5">
                    {item.records.map((r) => {
                      const isDone = r.status === 'COMPLETED';
                      return (
                        <div
                          key={r.id}
                          onClick={() => openRescheduleModal(r)}
                          className={`p-1.5 rounded-lg text-[10px] cursor-pointer transition border ${
                            isDone
                              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                              : r.priority === 'URGENT'
                              ? 'bg-red-500/20 border-red-500/40 text-red-200 shadow-sm animate-pulse'
                              : r.priority === 'HIGH'
                              ? 'bg-amber-500/20 border-amber-500/40 text-amber-200'
                              : 'bg-cyan-500/15 border-cyan-400/30 text-cyan-200'
                          }`}
                          title={`${r.machineCode}: ${r.notes} (${r.technicianName}) - Click to Reschedule/Edit`}
                        >
                          <div className="flex items-center justify-between font-bold">
                            <span>{r.machineCode}</span>
                            <span>{isDone ? '✓' : r.priority.slice(0, 1)}</span>
                          </div>
                          <div className="truncate text-[9px] opacity-80">{r.notes}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        /* List View */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center bg-[#0b0e14] border border-white/10 rounded-xl p-1">
              {(['ALL', 'UPCOMING', 'COMPLETED'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1.5 text-xs font-bold uppercase tracking-wider rounded-lg transition ${
                    filter === f
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {f} ({maintenanceRecords.filter((r) => (f === 'ALL' ? true : f === 'COMPLETED' ? r.status === 'COMPLETED' : r.status !== 'COMPLETED')).length})
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            {filteredRecords.map((record) => {
              const isCompleted = record.status === 'COMPLETED';

              return (
                <div
                  key={record.id}
                  className={`bg-[#0b0e14] border rounded-2xl p-5 transition-all shadow-xl ${
                    isCompleted
                      ? 'opacity-75 border-white/5'
                      : record.priority === 'URGENT'
                      ? 'border-red-500/40 bg-red-500/5'
                      : record.priority === 'HIGH'
                      ? 'border-amber-500/40 bg-amber-500/5'
                      : 'border-white/10'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[9px] font-mono font-bold uppercase px-2.5 py-0.5 rounded-full ${
                          isCompleted
                            ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        {record.status}
                      </span>
                      <h3 className="text-sm font-bold text-white">
                        {record.machineCode} — {record.machineName}
                      </h3>
                      <span className="text-[10px] text-slate-400 font-mono uppercase">({record.type})</span>
                    </div>

                    <div className="flex items-center gap-3 text-xs font-mono text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <CalendarIcon className="w-3.5 h-3.5 text-slate-500" />
                        <span>Scheduled: {record.scheduledDate}</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 mb-3 leading-relaxed">{record.notes}</p>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-3 border-t border-white/5 text-xs">
                    <div className="flex items-center gap-4 text-slate-400 text-[10px] font-mono">
                      <span>Assigned Tech: <strong className="text-white">{record.technicianName}</strong></span>
                      <span>Est. Duration: <strong className="text-white">{record.estimatedHours} hrs</strong></span>
                      <span>Est. Cost: <strong className="text-cyan-300">₹{(record.estimatedHours * 1500).toLocaleString()}</strong></span>
                    </div>

                    <div className="flex items-center gap-2">
                      {!isCompleted && (
                        <>
                          <button
                            onClick={() => openRescheduleModal(record)}
                            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-semibold flex items-center gap-1 transition"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                            <span>Reschedule</span>
                          </button>
                          <button
                            onClick={() => cancelMaintenance(record.id)}
                            className="px-2.5 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-semibold flex items-center gap-1 transition"
                            title="Cancel task"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => completeMaintenance(record.id)}
                            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition active:scale-95 uppercase tracking-wider"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Complete (Restore Health)</span>
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Schedule / Reschedule Maintenance Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#0b0e14] border border-white/10 rounded-2xl max-w-lg w-full p-6 shadow-2xl animate-in fade-in zoom-in duration-150">
            <div className="flex justify-between items-center border-b border-white/5 pb-3 mb-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Wrench className="w-4 h-4 text-cyan-400" />
                {editingRecord ? `Reschedule ${editingRecord.machineCode}` : 'Schedule Maintenance & Overhaul'}
              </h3>
              <button
                onClick={() => {
                  setShowScheduleModal(false);
                  setEditingRecord(null);
                }}
                className="text-slate-400 hover:text-slate-200"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleScheduleSubmit} className="space-y-4">
              {!editingRecord && (
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Machine Asset
                  </label>
                  <select
                    value={selectedMachine}
                    onChange={(e) => setSelectedMachine(e.target.value)}
                    className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  >
                    {machines.map((m) => (
                      <option key={m.id} value={m.id} className="bg-[#121418] text-white">
                        {m.code} — {m.name} (Health: {m.healthScore}%)
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Maintenance Type
                  </label>
                  <select
                    value={maintType}
                    onChange={(e) => setMaintType(e.target.value as MaintenanceRecord['type'])}
                    className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="PREVENTATIVE" className="bg-[#121418] text-white">PREVENTATIVE</option>
                    <option value="CORRECTIVE" className="bg-[#121418] text-white">CORRECTIVE</option>
                    <option value="EMERGENCY_OVERHAUL" className="bg-[#121418] text-white">EMERGENCY OVERHAUL</option>
                    <option value="INSPECTION" className="bg-[#121418] text-white">INSPECTION</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                    Priority
                  </label>
                  <select
                    value={maintPriority}
                    onChange={(e) => setMaintPriority(e.target.value as PriorityLevel)}
                    className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  >
                    <option value="NORMAL" className="bg-[#121418] text-white">NORMAL</option>
                    <option value="HIGH" className="bg-[#121418] text-white">HIGH</option>
                    <option value="URGENT" className="bg-[#121418] text-white">URGENT</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Lead Technician
                </label>
                <input
                  type="text"
                  value={techName}
                  onChange={(e) => setTechName(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Scheduled Service Date
                </label>
                <input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                  Technical Work Notes
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full bg-black/60 border border-white/10 text-white rounded-lg px-3 py-2 text-xs focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setShowScheduleModal(false);
                    setEditingRecord(null);
                  }}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-xs font-bold bg-cyan-500 hover:bg-cyan-400 text-black shadow-[0_0_15px_rgba(0,212,255,0.3)] uppercase tracking-wider"
                >
                  {editingRecord ? 'Update Schedule' : 'Save Maintenance Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

