import React, { createContext, useContext, useState, useEffect, useCallback, ReactNode, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  Machine,
  AlertItem,
  AlertLevel,
  Worker,
  WorkerNotification,
  SupervisorNotification,
  EscalationAuditLog,
  MaintenanceRecord,
  WorkAssignment,
  TelemetryPoint,
  PriorityLevel,
  RiskLevel,
  AlertType,
  AIDiagnosticResult,
  UserRole,
  DowntimeRecord,
  DowntimeSummaryStats,
  CostComparisonAnalysis,
  SmartRecommendationResult,
  AssistantChatMessage
} from '../types';
import {
  INITIAL_MACHINES,
  INITIAL_WORKERS,
  INITIAL_MAINTENANCE_RECORDS,
  INITIAL_WORK_ASSIGNMENTS,
  INITIAL_DOWNTIME_RECORDS
} from '../data/initialData';
import {
  calculateWorkloadRatio,
  classifyRiskLevel,
  calculateDynamicHealthScore,
  evaluateMachineCondition,
  calculateFactoryHealth,
  findBestRedistributionTarget,
  generateLocalAIDiagnosis,
  predictMTTFHours,
  evaluateSmartMachineWorkloadRecommendation,
  calculateCostComparisonAnalysis,
  calculateFleetDowntimeStats,
  answerAIAssistantQuestion
} from '../services/predictiveEngine';
import { sirenEngine } from '../services/sirenService';

interface ToastInfo {
  id: string;
  text: string;
  type: 'success' | 'warning' | 'error' | 'info';
}

interface WorkerNotificationStats {
  sent: number;
  delivered: number;
  opened: number;
  acknowledged: number;
}

interface FactoryContextType {
  machines: Machine[];
  alerts: AlertItem[];
  workers: Worker[];
  workerNotifications: WorkerNotification[];
  supervisorNotifications: SupervisorNotification[];
  escalationAuditLogs: EscalationAuditLog[];
  maintenanceRecords: MaintenanceRecord[];
  workAssignments: WorkAssignment[];
  telemetryHistory: TelemetryPoint[];
  downtimeRecords: DowntimeRecord[];
  chatMessages: AssistantChatMessage[];
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedMachineId: string | null;
  setSelectedMachineId: (id: string | null) => void;
  
  // Machine Comparison State
  comparedMachineIds: string[];
  setComparedMachineIds: (ids: string[]) => void;
  toggleMachineComparison: (machineId: string) => void;

  // Escalation Controls
  escalationTimeoutSeconds: number;
  setEscalationTimeoutSeconds: (sec: number) => void;
  acknowledgeAlertByRole: (alertId: string, role: 'WORKER' | 'SUPERVISOR' | 'ADMIN', name: string) => void;

  // Siren & Audio
  isSirenActive: boolean;
  isAudioMuted: boolean;
  isAudioUnlocked: boolean;
  enableAudio: () => boolean;
  stopSiren: () => void;
  toggleAudioMute: () => void;

  // Simulation Controls
  isSimulationRunning: boolean;
  simulationSpeed: number;
  setSimulationSpeed: (speed: number) => void;
  toggleSimulation: () => void;
  resetFactoryToDefault: () => void;

  // Machine Actions
  startMachine: (machineId: string) => void;
  stopMachine: (machineId: string) => void;
  simulateMachineOperation: (machineId: string, addHours: number) => void;
  updateMachineSafeCapacity: (machineId: string, newSafeHours: number) => void;

  // Work & Alert Workflows
  assignWork: (
    machineId: string,
    durationHours: number,
    taskName?: string,
    workType?: string,
    priority?: PriorityLevel
  ) => { alertCreated: boolean; riskLevel: RiskLevel; alertId?: string };
  
  redistributeWork: (
    sourceMachineId: string,
    targetMachineId: string,
    alertId?: string,
    transferHours?: number
  ) => boolean;

  haltAndInspectMachine: (machineId: string, alertId?: string) => void;

  triggerCriticalAlert: (
    machine: Machine,
    alertType: AlertType,
    customDetails?: Partial<AlertItem>
  ) => AlertItem;

  acknowledgeAlert: (alertId: string, workerName?: string) => void;
  resolveAlert: (alertId: string, actionNote?: string) => void;

  // Smart Recommender
  getSmartWorkloadRecommendation: (workloadHours: number) => SmartRecommendationResult;

  // Maintenance & Planner
  scheduleMaintenance: (
    machineId: string,
    type: MaintenanceRecord['type'],
    priority: PriorityLevel,
    notes: string,
    technicianName: string,
    scheduledDate?: string,
    scheduledTime?: string
  ) => void;
  autoScheduleMaintenanceForRisk: (machineId?: string) => void;
  rescheduleMaintenance: (maintenanceId: string, newDate: string, technicianName?: string, notes?: string) => void;
  deleteMaintenanceTask: (maintenanceId: string) => void;
  cancelMaintenance: (maintenanceId: string) => void;
  completeMaintenance: (maintenanceId: string) => void;

  // Downtime Tracking
  startDowntime: (machineId: string, reason: DowntimeRecord['reason']) => void;
  resolveDowntime: (machineId: string) => void;
  downtimeStats: DowntimeSummaryStats;

  // Cost Analysis
  costAnalysis: CostComparisonAnalysis;

  // AI Assistant Chat
  askAIAssistant: (query: string) => Promise<void>;

  // Worker Mobile App & Push
  isWorkerMobileOpen: boolean;
  setIsWorkerMobileOpen: (open: boolean) => void;
  currentMobileWorker: Worker;
  setCurrentMobileWorker: (worker: Worker) => void;
  openWorkerNotification: (notificationId: string) => void;
  acknowledgeWorkerNotification: (notificationId: string, workerName?: string) => void;
  acknowledgeAllWorkerNotifications: (alertId: string) => void;
  workerNotificationStats: WorkerNotificationStats;

  // Diagnostics & AI
  fetchAIDiagnostics: (machine: Machine) => Promise<AIDiagnosticResult>;
  generateExecutiveReport: () => Promise<{ executiveSummary: string; keyInsights: string[]; safetyIndex: number }>;

  // UI Toast & State
  toasts: ToastInfo[];
  showToast: (text: string, type?: 'success' | 'warning' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;

  // Aggregated Stats
  stats: {
    totalMachines: number;
    safeMachines: number;
    cautionMachines: number;
    highRiskMachines: number;
    criticalMachines: number;
    activeAlerts: number;
    maintenanceRequired: number;
    predictedFailures: number;
    averageHealth: number;
    factoryAvailability: number;
  };
}

const FactoryContext = createContext<FactoryContextType | undefined>(undefined);

const STORAGE_KEY_MACHINES = 'ai_smart_factory_machines_v3';
const STORAGE_KEY_ALERTS = 'ai_smart_factory_alerts_v3';
const STORAGE_KEY_MAINTENANCE = 'ai_smart_factory_maintenance_v3';
const STORAGE_KEY_NOTIFICATIONS = 'ai_smart_factory_notifications_v3';
const STORAGE_KEY_SUPERVISOR_NOTIFS = 'ai_smart_factory_sup_notifs_v3';
const STORAGE_KEY_ESCALATION_LOGS = 'ai_smart_factory_escalation_logs_v3';
const STORAGE_KEY_ASSIGNMENTS = 'ai_smart_factory_assignments_v3';
const STORAGE_KEY_WORKERS = 'ai_smart_factory_workers_v3';
const STORAGE_KEY_DOWNTIME = 'ai_smart_factory_downtime_v3';
const STORAGE_KEY_CHAT = 'ai_smart_factory_chat_v3';

export const FactoryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [machines, setMachines] = useState<Machine[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MACHINES);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return INITIAL_MACHINES;
  });

  const [alerts, setAlerts] = useState<AlertItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ALERTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return [];
  });

  const [workers, setWorkers] = useState<Worker[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_WORKERS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return INITIAL_WORKERS;
  });
  const [currentMobileWorker, setCurrentMobileWorker] = useState<Worker>(INITIAL_WORKERS[0]);
  const [isWorkerMobileOpen, setIsWorkerMobileOpen] = useState(false);

  const [workerNotifications, setWorkerNotifications] = useState<WorkerNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_NOTIFICATIONS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return [];
  });

  const [supervisorNotifications, setSupervisorNotifications] = useState<SupervisorNotification[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SUPERVISOR_NOTIFS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return [];
  });

  const [escalationAuditLogs, setEscalationAuditLogs] = useState<EscalationAuditLog[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ESCALATION_LOGS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return [];
  });

  const [maintenanceRecords, setMaintenanceRecords] = useState<MaintenanceRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_MAINTENANCE);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return INITIAL_MAINTENANCE_RECORDS;
  });

  const [workAssignments, setWorkAssignments] = useState<WorkAssignment[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_ASSIGNMENTS);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return INITIAL_WORK_ASSIGNMENTS;
  });

  const [downtimeRecords, setDowntimeRecords] = useState<DowntimeRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DOWNTIME);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return INITIAL_DOWNTIME_RECORDS;
  });

  const [chatMessages, setChatMessages] = useState<AssistantChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_CHAT);
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
    return [
      {
        id: 'msg-init-1',
        sender: 'assistant',
        text: 'Hello! I am your **AI Smart Maintenance Assistant**. I am connected directly to real-time telemetry from all 10 machine nodes.\n\nAsk me anything about machine health, critical overloads, maintenance priorities, or smart workload allocation.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedPrompts: [
          'Which machine needs maintenance first?',
          'Which machine is most dangerous?',
          'Which machine should receive this workload?',
          "What caused today's alerts?"
        ],
      },
    ];
  });

  const [comparedMachineIds, setComparedMachineIds] = useState<string[]>(['M-01', 'M-02', 'M-04']);
  const [escalationTimeoutSeconds, setEscalationTimeoutSeconds] = useState<number>(120); // 2 minutes standard timeout

  const [telemetryHistory, setTelemetryHistory] = useState<TelemetryPoint[]>([]);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedMachineId, setSelectedMachineId] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>('ADMIN');

  // Audio & Siren states
  const [isSirenActive, setIsSirenActive] = useState<boolean>(false);
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const [isAudioUnlocked, setIsAudioUnlocked] = useState<boolean>(false);

  // Simulation controls
  const [isSimulationRunning, setIsSimulationRunning] = useState<boolean>(true);
  const [simulationSpeed, setSimulationSpeed] = useState<number>(1.0);

  // Toast UI
  const [toasts, setToasts] = useState<ToastInfo[]>([]);

  const showToast = useCallback(
    (text: string, type: 'success' | 'warning' | 'error' | 'info' = 'info') => {
      const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
      setToasts((prev) => [...prev, { id, text, type }]);
      setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4000);
    },
    []
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Prevent multiple duplicate alerts firing in quick succession for the same condition
  const activeAlertTracker = useRef<Set<string>>(new Set());

  // Listen to SirenAudioEngine
  useEffect(() => {
    const unsub = sirenEngine.subscribe((isPlaying, isMuted, isUnlocked) => {
      setIsSirenActive(isPlaying);
      setIsAudioMuted(isMuted);
      setIsAudioUnlocked(isUnlocked);
    });
    return unsub;
  }, []);

  // Save to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_MACHINES, JSON.stringify(machines));
      localStorage.setItem(STORAGE_KEY_ALERTS, JSON.stringify(alerts));
      localStorage.setItem(STORAGE_KEY_MAINTENANCE, JSON.stringify(maintenanceRecords));
      localStorage.setItem(STORAGE_KEY_NOTIFICATIONS, JSON.stringify(workerNotifications));
      localStorage.setItem(STORAGE_KEY_SUPERVISOR_NOTIFS, JSON.stringify(supervisorNotifications));
      localStorage.setItem(STORAGE_KEY_ESCALATION_LOGS, JSON.stringify(escalationAuditLogs));
      localStorage.setItem(STORAGE_KEY_ASSIGNMENTS, JSON.stringify(workAssignments));
      localStorage.setItem(STORAGE_KEY_WORKERS, JSON.stringify(workers));
      localStorage.setItem(STORAGE_KEY_DOWNTIME, JSON.stringify(downtimeRecords));
      localStorage.setItem(STORAGE_KEY_CHAT, JSON.stringify(chatMessages));
    } catch (e) {
      console.warn('LocalStorage write error:', e);
    }
  }, [
    machines,
    alerts,
    maintenanceRecords,
    workerNotifications,
    supervisorNotifications,
    escalationAuditLogs,
    workAssignments,
    workers,
    downtimeRecords,
    chatMessages,
  ]);

  const enableAudio = useCallback(() => {
    const ok = sirenEngine.enableAudio();
    if (ok) {
      showToast('🔊 Industrial Emergency Audio & Siren Initialized', 'success');
    }
    return ok;
  }, [showToast]);

  const stopSiren = useCallback(() => {
    sirenEngine.stopSiren();
    setIsSirenActive(false);
    showToast('Software Siren Muted / Stopped', 'info');
  }, [showToast]);

  const toggleAudioMute = useCallback(() => {
    const newMute = !isAudioMuted;
    sirenEngine.setMuted(newMute);
    setIsAudioMuted(newMute);
    showToast(newMute ? 'Emergency Audio Muted' : 'Emergency Audio Enabled', 'info');
  }, [isAudioMuted, showToast]);

  /**
   * Machine Comparison Toggle (2 to 4 machines)
   */
  const toggleMachineComparison = useCallback((machineId: string) => {
    setComparedMachineIds((prev) => {
      if (prev.includes(machineId)) {
        if (prev.length <= 2) {
          showToast('Select at least 2 machines for comparison.', 'warning');
          return prev;
        }
        return prev.filter((id) => id !== machineId);
      }
      if (prev.length >= 4) {
        showToast('Maximum 4 machines can be compared side-by-side.', 'warning');
        return prev;
      }
      return [...prev, machineId];
    });
  }, [showToast]);

  /**
   * Start Downtime Tracking
   */
  const startDowntime = useCallback((machineId: string, reason: DowntimeRecord['reason']) => {
    const target = machines.find((m) => m.id === machineId);
    if (!target) return;

    setDowntimeRecords((prev) => {
      const existing = prev.find((r) => r.machineId === machineId && r.status === 'ACTIVE');
      if (existing) return prev;

      const newRecord: DowntimeRecord = {
        id: `DT-${Date.now()}`,
        machineId,
        machineCode: target.code,
        machineName: target.name,
        startTime: new Date().toISOString(),
        durationMinutes: 1,
        reason,
        status: 'ACTIVE',
        estimatedCostLoss: 2500,
      };
      return [newRecord, ...prev];
    });
  }, [machines]);

  /**
   * Resolve Downtime Tracking
   */
  const resolveDowntime = useCallback((machineId: string) => {
    setDowntimeRecords((prev) =>
      prev.map((r) => {
        if (r.machineId === machineId && r.status === 'ACTIVE') {
          const startMs = new Date(r.startTime).getTime();
          const nowMs = Date.now();
          const durationMin = Math.max(1, Math.round((nowMs - startMs) / 60000));
          return {
            ...r,
            status: 'RESOLVED',
            endTime: new Date().toISOString(),
            durationMinutes: durationMin,
            estimatedCostLoss: Math.round(durationMin * 125), // ₹125/min demo downtime impact
          };
        }
        return r;
      })
    );
  }, []);

  /**
   * Critical Alert Trigger (Siren + Modal + Worker FCM Broadcast + Escalation Timer)
   */
  const triggerCriticalAlert = useCallback(
    (
      machine: Machine,
      alertType: AlertType = 'ASSIGNED_OVERLOAD',
      customMessage?: string
    ): AlertItem => {
      // Start emergency audio siren
      sirenEngine.startSiren();
      setIsSirenActive(true);

      const isUnassigned = alertType === 'UNASSIGNED_OPERATION';
      const actualHours = machine.actualOperatingHours || machine.currentOperatingHours || 0;
      const assigned = machine.assignedHours;
      const safe = machine.safeHours;
      const ratio = calculateWorkloadRatio(isUnassigned ? 0 : assigned, safe);

      const aiDiag = generateLocalAIDiagnosis(machine, isUnassigned ? 0 : assigned, safe);

      const title = isUnassigned
        ? `EMERGENCY: Unauthorized Unassigned Run on Machine ${machine.code}`
        : `CRITICAL OVERLOAD: Machine ${machine.code} Capacity Exceeded`;

      const message =
        customMessage ||
        (isUnassigned
          ? `Machine ${machine.code} has accumulated ${actualHours}h without scheduled work order (Safe: ${safe}h). AI predicts severe thermal runaway and structural wear.`
          : `Assigned workload (${assigned}h) exceeds safe threshold (${safe}h) by ${(assigned - safe).toFixed(1)}h (${Math.round((assigned / safe) * 100)}%). Immediate redistribution or shutdown mandatory.`);

      const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      const deadline = Date.now() + escalationTimeoutSeconds * 1000;

      const newAlert: AlertItem = {
        id: `ALERT-${Date.now()}`,
        machineId: machine.id,
        machineCode: machine.code,
        machineName: machine.name,
        alertType,
        alertLevel: 'LEVEL_3_CRITICAL',
        riskLevel: 'CRITICAL',
        riskScore: machine.riskScore || 92,
        workloadHours: assigned,
        assignedWorkHours: assigned,
        operatingHours: actualHours,
        safeCapacityHours: safe,
        workloadRatio: ratio,
        title,
        message,
        timestamp: nowTimeStr,
        status: 'ACTIVE',
        workerNotificationCount: workers.length,
        sirenTriggered: true,
        aiExplanation: aiDiag.explanation,
        aiRecommendation: aiDiag.recommendation,
        contributingFactors: aiDiag.contributingFactors,

        // Escalation Workflow fields
        escalationStage: 'WORKER_PENDING',
        workerNotifiedAt: nowTimeStr,
        escalationTimerSeconds: escalationTimeoutSeconds,
        escalationDeadline: deadline,
      };

      setAlerts((prev) => [newAlert, ...prev]);

      // Start downtime tracking for critical machine
      startDowntime(machine.id, 'CRITICAL_OVERLOAD');

      // Trigger Push Notifications to Workers
      const notifications: WorkerNotification[] = workers.map((w, idx) => {
        return {
          id: `NOTIF-${newAlert.id}-${idx}`,
          alertId: newAlert.id,
          workerId: w.id,
          workerName: w.name,
          role: w.role,
          machineCode: machine.code,
          machineName: machine.name,
          alertType,
          alertLevel: 'LEVEL_3_CRITICAL',
          message: `🚨 [CRITICAL ALERT] Machine ${machine.code} in ${machine.location} has reached critical overload capacity. Urgent acknowledgement required within 2 minutes.`,
          priority: 'CRITICAL',
          status: 'DELIVERED',
          sentAt: nowTimeStr,
          deliveredAt: nowTimeStr,
          triggeringMachineCode: machine.code,
          sirenTriggered: true,
        };
      });
      setWorkerNotifications((prev) => [...notifications, ...prev]);

      // Log initial escalation audit entry
      const initialLog: EscalationAuditLog = {
        id: `ESC-LOG-${Date.now()}`,
        alertId: newAlert.id,
        machineCode: machine.code,
        stage: 'WORKER_DISPATCH',
        message: `Dispatched to ${workers.length} on-duty workers. 2-minute acknowledgement countdown started.`,
        timestamp: nowTimeStr,
        actor: 'Predictive Escalation Engine',
        details: `Timeout set to ${escalationTimeoutSeconds}s.`,
      };
      setEscalationAuditLogs((prev) => [initialLog, ...prev]);

      // Pop open Android phone emulator for instant worker visibility
      setIsWorkerMobileOpen(true);

      showToast(`🚨 ${title} - SIREN & WORKER DISPATCH ACTIVATED!`, 'error');

      return newAlert;
    },
    [workers, escalationTimeoutSeconds, startDowntime, showToast, setIsWorkerMobileOpen]
  );

  /**
   * Escalation Timer Monitor Effect
   * Monitors active critical alerts for 2-minute timeout and escalates:
   * Level 1: Worker -> Level 2: Supervisor (after timeout) -> Level 3: Admin (after 2x timeout)
   */
  useEffect(() => {
    const escalationInterval = setInterval(() => {
      const now = Date.now();
      const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      setAlerts((prevAlerts) => {
        let hasChanges = false;
        const updated = prevAlerts.map((alert) => {
          if (alert.status !== 'ACTIVE' || !alert.escalationDeadline) return alert;

          // Check Stage 1: WORKER_PENDING -> SUPERVISOR_NOTIFIED
          if (alert.escalationStage === 'WORKER_PENDING' && now >= alert.escalationDeadline) {
            hasChanges = true;
            const newDeadline = now + escalationTimeoutSeconds * 1000;

            // Add Supervisor Notification
            const supNotif: SupervisorNotification = {
              id: `SUP-NOTIF-${alert.id}`,
              alertId: alert.id,
              machineId: alert.machineId,
              machineCode: alert.machineCode,
              machineName: alert.machineName,
              alertLevel: alert.alertLevel,
              riskLevel: alert.riskLevel,
              riskScore: alert.riskScore,
              workloadHours: alert.workloadHours,
              safeCapacityHours: alert.safeCapacityHours,
              reason: `Unacknowledged by workers after ${escalationTimeoutSeconds}s timeout. Escalated to Shift Supervisor.`,
              recommendedMaintenanceAction: 'Authorize immediate load redistribution or execute emergency shutdown.',
              contributingFactors: alert.aiExplanation || [],
              timestamp: nowTimeStr,
              status: 'ACTIVE',
            };
            setSupervisorNotifications((prev) => [supNotif, ...prev]);

            // Add Escalation Audit Log
            const auditLog: EscalationAuditLog = {
              id: `ESC-LOG-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              alertId: alert.id,
              machineCode: alert.machineCode,
              stage: 'SUPERVISOR_ESCALATION',
              message: `2-minute worker acknowledgement window expired. Alert escalated to Plant Supervisor.`,
              timestamp: nowTimeStr,
              actor: 'Automated Escalation System',
              details: `Supervisor push notification delivered.`,
            };
            setEscalationAuditLogs((prev) => [auditLog, ...prev]);

            showToast(`⚠️ [ESCALATION] Alert ${alert.id} escalated to Plant Supervisor (2 min unacknowledged).`, 'warning');

            return {
              ...alert,
              escalationStage: 'SUPERVISOR_NOTIFIED' as const,
              supervisorNotified: true,
              supervisorNotifiedAt: nowTimeStr,
              escalationDeadline: newDeadline,
            };
          }

          // Check Stage 2: SUPERVISOR_NOTIFIED -> ADMIN_NOTIFIED
          if (alert.escalationStage === 'SUPERVISOR_NOTIFIED' && now >= alert.escalationDeadline) {
            hasChanges = true;

            const auditLog: EscalationAuditLog = {
              id: `ESC-LOG-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
              alertId: alert.id,
              machineCode: alert.machineCode,
              stage: 'ADMIN_CRITICAL_ESCALATION',
              message: `Supervisor acknowledgement timeout expired. Critical emergency escalated to General Plant Admin.`,
              timestamp: nowTimeStr,
              actor: 'Automated Escalation System',
              details: `Executive priority override activated.`,
            };
            setEscalationAuditLogs((prev) => [auditLog, ...prev]);

            showToast(`🚨 [CRITICAL ESCALATION] Alert ${alert.id} escalated to Plant Admin / General Manager!`, 'error');

            return {
              ...alert,
              escalationStage: 'ADMIN_NOTIFIED' as const,
              adminNotified: true,
              adminNotifiedAt: nowTimeStr,
              escalationDeadline: undefined, // Final tier
            };
          }

          return alert;
        });

        return hasChanges ? updated : prevAlerts;
      });
    }, 1000);

    return () => clearInterval(escalationInterval);
  }, [escalationTimeoutSeconds, showToast]);

  /**
   * Alert Acknowledgement by Role
   */
  const acknowledgeAlertByRole = useCallback(
    (alertId: string, role: 'WORKER' | 'SUPERVISOR' | 'ADMIN', name: string) => {
      const nowTimeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      setAlerts((prev) =>
        prev.map((a) => {
          if (a.id === alertId) {
            return {
              ...a,
              status: 'ACKNOWLEDGED',
              escalationStage: 'RESOLVED_ACKNOWLEDGED',
              acknowledgedBy: `${name} (${role})`,
              workerAcknowledgedAt: role === 'WORKER' ? nowTimeStr : a.workerAcknowledgedAt,
              supervisorAcknowledgedAt: role === 'SUPERVISOR' ? nowTimeStr : a.supervisorAcknowledgedAt,
              adminAcknowledgedAt: role === 'ADMIN' ? nowTimeStr : a.adminAcknowledgedAt,
            };
          }
          return a;
        })
      );

      setWorkerNotifications((prev) =>
        prev.map((n) => (n.alertId === alertId ? { ...n, status: 'ACKNOWLEDGED', acknowledgedAt: nowTimeStr } : n))
      );

      setSupervisorNotifications((prev) =>
        prev.map((n) => (n.alertId === alertId ? { ...n, status: 'ACKNOWLEDGED', acknowledgedAt: nowTimeStr } : n))
      );

      const auditLog: EscalationAuditLog = {
        id: `ESC-LOG-${Date.now()}`,
        alertId,
        machineCode: alerts.find((a) => a.id === alertId)?.machineCode || 'MACHINE',
        stage: 'ACKNOWLEDGED',
        message: `Alert successfully acknowledged by ${name} (${role}). Escalation timer halted.`,
        timestamp: nowTimeStr,
        actor: `${name} [${role}]`,
        details: 'Timer halted.',
      };
      setEscalationAuditLogs((prev) => [auditLog, ...prev]);

      sirenEngine.playBeep(900, 0.08);
      showToast(`Alert acknowledged by ${name} (${role})`, 'success');
    },
    [alerts, showToast]
  );

  const acknowledgeAlert = useCallback(
    (alertId: string, workerName = 'Lead Operator') => {
      acknowledgeAlertByRole(alertId, 'WORKER', workerName);
    },
    [acknowledgeAlertByRole]
  );

  /**
   * Machine Start / Stop / Runtime Controls
   */
  const startMachine = useCallback(
    (machineId: string) => {
      let startedMachine: Machine | undefined;
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            startedMachine = m;
            const isUnassigned = m.assignedHours === 0;
            const operating = m.actualOperatingHours || 0.1;
            let status = m.status;
            if (isUnassigned) {
              status = operating > m.safeHours ? 'CRITICAL' : 'WARNING';
            } else if (m.assignedHours > m.safeHours) {
              status = 'OVERLOADED';
            } else {
              status = 'RUNNING';
            }
            return {
              ...m,
              status,
              actualOperatingHours: operating,
              currentOperatingHours: operating,
            };
          }
          return m;
        })
      );

      // Resolve downtime if machine is running normally
      resolveDowntime(machineId);

      if (startedMachine) {
        const sm = startedMachine as Machine;
        sirenEngine.playBeep(600, 0.05);
        showToast(`Machine ${sm.code} Started`, 'info');
      }
    },
    [resolveDowntime, showToast]
  );

  const stopMachine = useCallback(
    (machineId: string) => {
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            return {
              ...m,
              status: 'STOPPED',
              riskLevel: m.assignedHours > m.safeHours ? 'HIGH_RISK' : 'SAFE',
            };
          }
          return m;
        })
      );
      sirenEngine.playBeep(400, 0.05);
      showToast(`Machine ${machineId} Stopped & Safe`, 'info');

      // Check if this resolved an unassigned operation alert
      setAlerts((prev) =>
        prev.map((a) => {
          if (a.machineId === machineId && a.alertType === 'UNASSIGNED_OPERATION' && a.status === 'ACTIVE') {
            return {
              ...a,
              status: 'RESOLVED',
              actionTaken: 'Machine stopped by operator and cleared for inspection.',
              resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
          }
          return a;
        })
      );
    },
    [showToast]
  );

  const simulateMachineOperation = useCallback(
    (machineId: string, addHours: number) => {
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            const newOperating = Number(((m.actualOperatingHours || 0) + addHours).toFixed(2));
            const newTotal = Number(((m.totalOperatingHours || 1000) + addHours).toFixed(2));
            const healthObj = calculateDynamicHealthScore(m, m.assignedHours, m.safeHours, newOperating);

            // Check Condition 2B: Unassigned operation exceeding safe capacity
            if (m.assignedHours === 0 && m.status === 'RUNNING' && newOperating > m.safeHours) {
              const trackerKey = `unassigned_${m.id}`;
              if (!activeAlertTracker.current.has(trackerKey)) {
                activeAlertTracker.current.add(trackerKey);
                setTimeout(() => {
                  triggerCriticalAlert(
                    {
                      ...m,
                      actualOperatingHours: newOperating,
                      currentOperatingHours: newOperating,
                    },
                    'UNASSIGNED_OPERATION'
                  );
                }, 50);
              }
            }

            return {
              ...m,
              actualOperatingHours: newOperating,
              currentOperatingHours: newOperating,
              totalOperatingHours: newTotal,
              healthScore: healthObj.healthScore,
              riskLevel: healthObj.riskLevel,
              riskScore: healthObj.riskScore,
            };
          }
          return m;
        })
      );
      showToast(`Simulated +${addHours}h runtime on Machine ${machineId}`, 'info');
    },
    [triggerCriticalAlert, showToast]
  );

  const updateMachineSafeCapacity = useCallback(
    (machineId: string, newSafeHours: number) => {
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            const safe = Math.max(0.5, Number(newSafeHours.toFixed(1)));
            const healthObj = calculateDynamicHealthScore(m, m.assignedHours, safe, m.actualOperatingHours);
            return {
              ...m,
              safeHours: safe,
              healthScore: healthObj.healthScore,
              riskLevel: healthObj.riskLevel,
              riskScore: healthObj.riskScore,
            };
          }
          return m;
        })
      );
      showToast(`Safe capacity for ${machineId} updated to ${newSafeHours}h`, 'success');
    },
    [showToast]
  );

  /**
   * Work Assignment Function (Evaluates Condition 1 Automatically)
   */
  const assignWork = useCallback(
    (
      machineId: string,
      durationHours: number,
      taskName = 'Production Batch',
      workType = 'Standard Machining',
      priority: PriorityLevel = 'NORMAL'
    ) => {
      const targetMachine = machines.find((m) => m.id === machineId);
      if (!targetMachine) return { alertCreated: false, riskLevel: 'SAFE' as RiskLevel };

      const isOverload = durationHours > targetMachine.safeHours;
      const ratio = calculateWorkloadRatio(durationHours, targetMachine.safeHours);
      const riskLevel = classifyRiskLevel(ratio);

      // Create Work Assignment Record
      const newAssignment: WorkAssignment = {
        id: `JOB-${Date.now()}`,
        machineId: targetMachine.id,
        machineCode: targetMachine.code,
        machineName: targetMachine.name,
        taskName,
        workType,
        durationHours,
        priority,
        assignedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        expectedCompletionTime: new Date(Date.now() + durationHours * 3600 * 1000).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        status: 'ACTIVE',
      };

      setWorkAssignments((prev) => [newAssignment, ...prev]);

      // Update machine
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            const healthObj = calculateDynamicHealthScore(m, durationHours, m.safeHours, m.actualOperatingHours);
            return {
              ...m,
              assignedHours: durationHours,
              status: isOverload ? 'OVERLOADED' : 'RUNNING',
              riskLevel: isOverload ? 'CRITICAL' : riskLevel,
              riskScore: isOverload ? 92 : healthObj.riskScore,
              healthScore: isOverload ? Math.min(48, healthObj.healthScore) : healthObj.healthScore,
              currentTaskName: taskName,
              currentTaskPriority: priority,
            };
          }
          return m;
        })
      );

      // Automatically trigger Condition 1 Alert if Overload
      if (isOverload) {
        const createdAlert = triggerCriticalAlert(
          {
            ...targetMachine,
            assignedHours: durationHours,
          },
          'ASSIGNED_OVERLOAD'
        );
        return { alertCreated: true, riskLevel: 'CRITICAL', alertId: createdAlert.id };
      } else {
        sirenEngine.playBeep(700, 0.05);
        showToast(`Workload of ${durationHours}h assigned to ${targetMachine.code}`, 'success');
        return { alertCreated: false, riskLevel };
      }
    },
    [machines, triggerCriticalAlert, showToast]
  );

  /**
   * Smart Work Redistribution (Guarantees target safety & eliminates secondary overload)
   */
  const redistributeWork = useCallback(
    (
      sourceMachineId: string,
      targetMachineId: string,
      alertId?: string,
      transferHours?: number
    ) => {
      const source = machines.find((m) => m.id === sourceMachineId);
      const target = machines.find((m) => m.id === targetMachineId);

      if (!source || !target) {
        showToast('Invalid source or target machine.', 'error');
        return false;
      }

      let actualTransfer = transferHours;
      if (actualTransfer === undefined || actualTransfer <= 0) {
        if (source.assignedHours > source.safeHours) {
          actualTransfer = Number((source.assignedHours - source.safeHours).toFixed(1));
        } else if (source.assignedHours > 0) {
          actualTransfer = source.assignedHours;
        } else {
          actualTransfer = Math.min(1.0, target.safeHours - target.assignedHours);
        }
      }

      if (source.assignedHours > 0) {
        actualTransfer = Math.min(actualTransfer, source.assignedHours);
      }

      actualTransfer = Number(actualTransfer.toFixed(1));
      const targetNewTotal = Number((target.assignedHours + actualTransfer).toFixed(1));
      const sourceNewAssigned = source.assignedHours > 0
        ? Number(Math.max(0, source.assignedHours - actualTransfer).toFixed(1))
        : 0;

      // 1. Update Machines Safely
      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === sourceMachineId) {
            const healthObj = calculateDynamicHealthScore(m, sourceNewAssigned, m.safeHours, 0);
            return {
              ...m,
              assignedHours: sourceNewAssigned,
              actualOperatingHours: 0,
              currentOperatingHours: 0,
              unassignedOperationCount: 0,
              status: sourceNewAssigned > 0 ? 'RUNNING' : 'IDLE',
              riskLevel: 'SAFE',
              riskScore: Math.min(20, healthObj.riskScore),
              healthScore: Math.max(94, Math.min(98, healthObj.healthScore + 20)),
              currentTaskName: sourceNewAssigned > 0 ? m.currentTaskName : undefined,
            };
          }
          if (m.id === targetMachineId) {
            const isTargetWithinSafe = targetNewTotal <= m.safeHours;
            const healthObj = calculateDynamicHealthScore(m, targetNewTotal, m.safeHours, m.actualOperatingHours);
            const targetRatio = targetNewTotal / m.safeHours;
            return {
              ...m,
              assignedHours: targetNewTotal,
              status: 'RUNNING',
              riskLevel: isTargetWithinSafe
                ? targetRatio > 0.85
                  ? 'NORMAL'
                  : 'SAFE'
                : 'HIGH_RISK',
              riskScore: healthObj.riskScore,
              healthScore: Math.max(88, healthObj.healthScore),
              currentTaskName: `Production: ${source.currentTaskName || 'Transferred Batch'} (from ${source.code})`,
            };
          }
          return m;
        })
      );

      // Resolve downtime on source machine
      resolveDowntime(sourceMachineId);

      // 2. Resolve Alert & Stop Siren
      setAlerts((prev) =>
        prev.map((a) => {
          if (
            (alertId && a.id === alertId) ||
            (a.machineId === sourceMachineId && a.status === 'ACTIVE')
          ) {
            return {
              ...a,
              status: 'RESOLVED',
              actionTaken: `Workload (${actualTransfer}h) successfully balanced to ${target.code} (${target.name}). Target capacity preserved safely (${targetNewTotal}h / ${target.safeHours}h).`,
              resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
          }
          return a;
        })
      );

      // Update work assignments
      setWorkAssignments((prev) =>
        prev.map((job) => {
          if (job.machineId === sourceMachineId && job.status === 'ACTIVE') {
            return {
              ...job,
              status: 'REDISTRIBUTED',
              machineId: target.id,
              machineCode: target.code,
              machineName: target.name,
            };
          }
          return job;
        })
      );

      // Check if any other critical active alert exists
      const remainingCritical = alerts.filter(
        (a) => a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL' && a.machineId !== sourceMachineId
      );
      if (remainingCritical.length === 0) {
        sirenEngine.stopSiren();
      }

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00d4ff', '#00ff88', '#ffffff'],
        });
      } catch {
        // Ignore confetti error
      }

      showToast(
        `✅ Successfully balanced ${actualTransfer}h from ${source.code} to ${target.code}! All machines nominal.`,
        'success'
      );
      return true;
    },
    [machines, alerts, resolveDowntime, showToast]
  );

  /**
   * Dedicated Resolution for Condition 2 (Unassigned Machine Operation)
   */
  const haltAndInspectMachine = useCallback(
    (machineId: string, alertId?: string) => {
      const target = machines.find((m) => m.id === machineId);

      setMachines((prev) =>
        prev.map((m) => {
          if (m.id === machineId) {
            return {
              ...m,
              status: 'STOPPED',
              actualOperatingHours: 0,
              currentOperatingHours: 0,
              unassignedOperationCount: 0,
              assignedHours: 0,
              riskLevel: 'SAFE',
              riskScore: 8,
              healthScore: Math.max(95, m.healthScore + 20),
            };
          }
          return m;
        })
      );

      resolveDowntime(machineId);

      setAlerts((prev) =>
        prev.map((a) => {
          if (
            (alertId && a.id === alertId) ||
            (a.machineId === machineId && a.alertType === 'UNASSIGNED_OPERATION' && a.status !== 'RESOLVED')
          ) {
            return {
              ...a,
              status: 'RESOLVED',
              actionTaken: 'Machine halted by supervisor. Safe inspection completed and unauthorized run counter reset to 0.',
              resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
          }
          return a;
        })
      );

      const remainingCritical = alerts.filter(
        (a) => a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL' && a.machineId !== machineId
      );
      if (remainingCritical.length === 0) {
        sirenEngine.stopSiren();
      }

      try {
        confetti({
          particleCount: 60,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#00ff88', '#00d4ff'],
        });
      } catch {
        // Ignore
      }

      showToast(
        `✅ Machine ${target?.code || machineId} halted & inspected. Operating state cleared safely.`,
        'success'
      );
    },
    [machines, alerts, resolveDowntime, showToast]
  );

  const resolveAlert = useCallback(
    (alertId: string, actionNote = 'Issue inspected and mitigated.') => {
      let resolvedMachineId = '';
      setAlerts((prev) =>
        prev.map((a) => {
          if (a.id === alertId) {
            resolvedMachineId = a.machineId;
            return {
              ...a,
              status: 'RESOLVED',
              actionTaken: actionNote,
              resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
          }
          return a;
        })
      );

      // Stop siren if no other active critical alerts
      const activeOthers = alerts.filter(
        (a) => a.id !== alertId && a.status === 'ACTIVE' && a.riskLevel === 'CRITICAL'
      );
      if (activeOthers.length === 0) {
        sirenEngine.stopSiren();
      }

      if (resolvedMachineId) {
        resolveDowntime(resolvedMachineId);
        setMachines((prev) =>
          prev.map((m) => {
            if (m.id === resolvedMachineId) {
              return {
                ...m,
                status: m.assignedHours > 0 ? 'RUNNING' : 'STOPPED',
                riskLevel: 'SAFE',
              };
            }
            return m;
          })
        );
      }

      showToast(`Alert resolved: ${actionNote}`, 'success');
    },
    [alerts, resolveDowntime, showToast]
  );

  /**
   * Worker Mobile App Push Notifications Management
   */
  const openWorkerNotification = useCallback((notificationId: string) => {
    setWorkerNotifications((prev) =>
      prev.map((n) => (n.id === notificationId && n.status !== 'ACKNOWLEDGED' ? { ...n, status: 'READ' } : n))
    );
  }, []);

  const acknowledgeWorkerNotification = useCallback(
    (notificationId: string, workerName = 'Technician') => {
      let targetAlertId = '';
      setWorkerNotifications((prev) =>
        prev.map((n) => {
          if (n.id === notificationId) {
            targetAlertId = n.alertId;
            return {
              ...n,
              status: 'ACKNOWLEDGED',
              acknowledgedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            };
          }
          return n;
        })
      );
      if (targetAlertId) {
        acknowledgeAlertByRole(targetAlertId, 'WORKER', workerName);
      }
      sirenEngine.playBeep(900, 0.08);
      showToast(`Acknowledged by ${workerName} via Android Mobile App`, 'success');
    },
    [acknowledgeAlertByRole, showToast]
  );

  const acknowledgeAllWorkerNotifications = useCallback(
    (alertId: string) => {
      setWorkerNotifications((prev) =>
        prev.map((n) =>
          n.alertId === alertId
            ? {
                ...n,
                status: 'ACKNOWLEDGED',
                acknowledgedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              }
            : n
        )
      );
      acknowledgeAlertByRole(alertId, 'WORKER', 'All Technicians');
    },
    [acknowledgeAlertByRole]
  );

  const workerNotificationStats = {
    sent: workerNotifications.length,
    delivered: workerNotifications.filter((n) => n.status !== 'SENT').length,
    opened: workerNotifications.filter((n) => n.status === 'READ' || n.status === 'ACKNOWLEDGED').length,
    acknowledged: workerNotifications.filter((n) => n.status === 'ACKNOWLEDGED').length,
  };

  /**
   * Smart Workload Recommender Helper
   */
  const getSmartWorkloadRecommendation = useCallback(
    (workloadHours: number) => {
      return evaluateSmartMachineWorkloadRecommendation(workloadHours, machines);
    },
    [machines]
  );

  /**
   * Maintenance Planner Management
   */
  const scheduleMaintenance = useCallback(
    (
      machineId: string,
      type: MaintenanceRecord['type'],
      priority: PriorityLevel,
      notes: string,
      technicianName: string,
      scheduledDate = new Date().toISOString().split('T')[0],
      scheduledTime = '09:00'
    ) => {
      const targetMachine = machines.find((m) => m.id === machineId);
      const newRec: MaintenanceRecord = {
        id: `MAINT-${Date.now()}`,
        machineId,
        machineCode: targetMachine?.code || machineId,
        machineName: targetMachine?.name || 'Industrial Machine',
        type,
        priority,
        scheduledDate,
        scheduledTime,
        status: 'UPCOMING',
        technicianName,
        notes,
        estimatedHours: 2.5,
      };

      setMaintenanceRecords((prev) => [newRec, ...prev]);
      setMachines((prev) =>
        prev.map((m) => (m.id === machineId ? { ...m, maintenanceStatus: 'UPCOMING' } : m))
      );
      showToast(`Maintenance scheduled for ${targetMachine?.code || machineId}`, 'success');
    },
    [machines, showToast]
  );

  /**
   * FEATURE 4: Automatic Maintenance Scheduling for High/Critical Risk Machines
   */
  const autoScheduleMaintenanceForRisk = useCallback(
    (machineId?: string) => {
      const targets = machineId
        ? machines.filter((m) => m.id === machineId)
        : machines.filter((m) => m.healthScore < 80 || m.riskLevel === 'CRITICAL' || m.riskLevel === 'HIGH_RISK' || m.status === 'OVERLOADED');

      if (targets.length === 0) {
        showToast('All machines are in safe operating condition. No urgent maintenance required.', 'info');
        return;
      }

      const tech = workers[0]?.name || 'Senior Mechanical Tech';
      const today = new Date().toISOString().split('T')[0];

      const newRecs: MaintenanceRecord[] = targets.map((target, idx) => ({
        id: `AUTO-MAINT-${Date.now()}-${idx}`,
        machineId: target.id,
        machineCode: target.code,
        machineName: target.name,
        type: target.healthScore < 50 ? 'EMERGENCY_OVERHAUL' : 'CORRECTIVE',
        priority: target.healthScore < 50 ? 'URGENT' : 'HIGH',
        scheduledDate: today,
        scheduledTime: `${10 + idx}:00`,
        status: 'UPCOMING',
        technicianName: workers[idx % workers.length]?.name || tech,
        isAutoRecommended: true,
        autoRecommendationTriggerRisk: target.riskLevel,
        problemDetected: `AI Risk Alert: Health at ${target.healthScore}%, ${target.temperature}°C thermal accumulation, and ${target.vibration} mm/s vibration.`,
        actionTaken: 'High-speed bearing flush, lubrication renewal, and optical calibration.',
        notes: `Automatically scheduled by AI Predictive System to prevent catastrophic structural breakdown.`,
        estimatedHours: 3.0,
      }));

      setMaintenanceRecords((prev) => [...newRecs, ...prev]);
      const targetIds = new Set(targets.map((t) => t.id));
      setMachines((prev) =>
        prev.map((m) => (targetIds.has(m.id) ? { ...m, maintenanceStatus: 'UPCOMING', status: 'MAINTENANCE' } : m))
      );

      // Start downtime tracking for targets
      targets.forEach((t) => startDowntime(t.id, 'SCHEDULED_MAINTENANCE'));

      showToast(`⚡ AI Auto-Scheduled Maintenance for ${targets.length} at-risk asset(s)`, 'success');
    },
    [machines, workers, startDowntime, showToast]
  );

  const rescheduleMaintenance = useCallback(
    (maintenanceId: string, newDate: string, technicianName?: string, notes?: string) => {
      setMaintenanceRecords((prev) =>
        prev.map((rec) =>
          rec.id === maintenanceId
            ? {
                ...rec,
                scheduledDate: newDate,
                technicianName: technicianName || rec.technicianName,
                notes: notes || rec.notes,
                status: 'UPCOMING',
              }
            : rec
        )
      );
      showToast('Maintenance task rescheduled successfully', 'info');
    },
    [showToast]
  );

  const deleteMaintenanceTask = useCallback(
    (maintenanceId: string) => {
      setMaintenanceRecords((prev) => prev.filter((r) => r.id !== maintenanceId));
      showToast('Maintenance task removed', 'info');
    },
    [showToast]
  );

  const cancelMaintenance = useCallback(
    (maintenanceId: string) => {
      setMaintenanceRecords((prev) => prev.filter((r) => r.id !== maintenanceId));
      showToast('Maintenance task cancelled', 'info');
    },
    [showToast]
  );

  const completeMaintenance = useCallback(
    (maintenanceId: string) => {
      let mId = '';
      setMaintenanceRecords((prev) =>
        prev.map((rec) => {
          if (rec.id === maintenanceId) {
            mId = rec.machineId;
            return {
              ...rec,
              status: 'COMPLETED',
              completedDate: new Date().toISOString().split('T')[0],
            };
          }
          return rec;
        })
      );

      if (mId) {
        resolveDowntime(mId);
        setMachines((prev) =>
          prev.map((m) =>
            m.id === mId
              ? {
                  ...m,
                  healthScore: 98,
                  riskLevel: 'SAFE',
                  riskScore: 8,
                  status: 'RUNNING',
                  maintenanceStatus: 'OPTIMAL',
                  lastMaintenance: new Date().toISOString().split('T')[0],
                }
              : m
          )
        );
      }

      showToast('Maintenance completed! Machine health restored to 98%', 'success');
    },
    [resolveDowntime, showToast]
  );

  /**
   * AI Maintenance Assistant Ask Method
   */
  const askAIAssistant = useCallback(
    async (query: string) => {
      const userMsg: AssistantChatMessage = {
        id: `msg-${Date.now()}`,
        sender: 'user',
        text: query,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setChatMessages((prev) => [...prev, userMsg]);

      // Call local AI responder
      const response = answerAIAssistantQuestion(query, {
        machines,
        alerts,
        maintenanceRecords,
        downtimeRecords,
      });

      const assistantMsg: AssistantChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: response.text,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedPrompts: response.suggestedPrompts,
        actionLink: response.actionLink,
        metricsReferenced: response.metricsReferenced,
      };

      setChatMessages((prev) => [...prev, assistantMsg]);
    },
    [machines, alerts, maintenanceRecords, downtimeRecords]
  );

  /**
   * Factory Simulation Loop
   */
  const toggleSimulation = useCallback(() => {
    setIsSimulationRunning((prev) => {
      const next = !prev;
      if (next) enableAudio();
      showToast(next ? 'Live Factory Simulation Running' : 'Simulation Paused', 'info');
      return next;
    });
  }, [enableAudio, showToast]);

  useEffect(() => {
    if (!isSimulationRunning) return;

    const interval = setInterval(() => {
      setMachines((prev) =>
        prev.map((m) => {
          if (m.status === 'RUNNING' || m.status === 'WARNING' || m.status === 'OVERLOADED') {
            const increment = 0.05 * simulationSpeed;
            const newOperating = Number(((m.actualOperatingHours || 0) + increment).toFixed(2));
            const newTotal = Number(((m.totalOperatingHours || 1000) + increment).toFixed(2));
            const tempJitter = Number(((Math.random() - 0.5) * 0.4).toFixed(1));
            const vibJitter = Number(((Math.random() - 0.5) * 0.05).toFixed(2));

            const newTemp = Math.max(30, Math.min(95, Number((m.temperature + tempJitter).toFixed(1))));
            const newVib = Math.max(0.5, Math.min(5.0, Number((m.vibration + vibJitter).toFixed(2))));

            const healthObj = calculateDynamicHealthScore(
              { ...m, temperature: newTemp, vibration: newVib },
              m.assignedHours,
              m.safeHours,
              newOperating
            );

            // Condition 2B Check during simulation
            if (m.assignedHours === 0 && newOperating > m.safeHours && m.status !== 'CRITICAL') {
              const trackerKey = `unassigned_${m.id}`;
              if (!activeAlertTracker.current.has(trackerKey)) {
                activeAlertTracker.current.add(trackerKey);
                setTimeout(() => {
                  triggerCriticalAlert(
                    {
                      ...m,
                      actualOperatingHours: newOperating,
                      currentOperatingHours: newOperating,
                    },
                    'UNASSIGNED_OPERATION'
                  );
                }, 50);
              }
            }

            return {
              ...m,
              actualOperatingHours: newOperating,
              currentOperatingHours: newOperating,
              totalOperatingHours: newTotal,
              temperature: newTemp,
              vibration: newVib,
              healthScore: healthObj.healthScore,
              riskScore: healthObj.riskScore,
              riskLevel: healthObj.riskLevel,
            };
          }
          return m;
        })
      );
    }, 2500 / simulationSpeed);

    return () => clearInterval(interval);
  }, [isSimulationRunning, simulationSpeed, triggerCriticalAlert]);

  const resetFactoryToDefault = useCallback(() => {
    sirenEngine.stopSiren();
    setMachines(INITIAL_MACHINES);
    setAlerts([]);
    setWorkerNotifications([]);
    setSupervisorNotifications([]);
    setEscalationAuditLogs([]);
    setMaintenanceRecords(INITIAL_MAINTENANCE_RECORDS);
    setWorkAssignments(INITIAL_WORK_ASSIGNMENTS);
    setDowntimeRecords(INITIAL_DOWNTIME_RECORDS);
    activeAlertTracker.current.clear();
    showToast('Factory state reset to initial factory baseline.', 'info');
  }, [showToast]);

  /**
   * AI Diagnostics API Request
   */
  const fetchAIDiagnostics = useCallback(
    async (machine: Machine): Promise<AIDiagnosticResult> => {
      try {
        const res = await fetch('/api/ai/diagnose', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            machine,
            workloadRatio: calculateWorkloadRatio(machine.assignedHours, machine.safeHours),
          }),
        });

        if (res.ok) {
          const data = await res.json();
          return data;
        }
      } catch (err) {
        console.warn('AI diagnose fetch error, falling back to local engine:', err);
      }
      return generateLocalAIDiagnosis(machine, machine.assignedHours, machine.safeHours);
    },
    []
  );

  const generateExecutiveReport = useCallback(async () => {
    const factorySummary = {
      totalMachines: machines.length,
      averageHealth: Math.round(machines.reduce((a, b) => a + b.healthScore, 0) / machines.length),
      overloadedMachines: machines.filter((m) => m.assignedHours > m.safeHours).length,
      activeAlerts: alerts.filter((a) => a.status === 'ACTIVE').length,
    };

    try {
      const res = await fetch('/api/ai/generate-report', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ factorySummary }),
      });
      if (res.ok) {
        return await res.json();
      }
    } catch {
      // Fallback
    }

    return {
      executiveSummary:
        'AI Predictive telemetry demonstrates high structural stability with automated redistribution preventing component breakdown.',
      keyInsights: [
        'Dynamic capacity enforcement maintained 98.4% uptime.',
        'Continuous vibration monitoring prevented 3 catastrophic motor seizures.',
        'Redistribution algorithms balanced peak load effectively.',
      ],
      safetyIndex: 95.4,
    };
  }, [machines, alerts]);

  // Aggregate Stats
  const factoryHealthObj = calculateFactoryHealth(machines);
  const criticalCount = machines.filter((m) => m.riskLevel === 'CRITICAL' || m.status === 'OVERLOADED').length;
  const downtimeStats = calculateFleetDowntimeStats(machines, downtimeRecords);
  const costAnalysis = calculateCostComparisonAnalysis(machines, maintenanceRecords, alerts);

  const stats = {
    totalMachines: machines.length,
    safeMachines: machines.filter((m) => m.riskLevel === 'SAFE' || m.riskLevel === 'NORMAL').length,
    cautionMachines: machines.filter((m) => m.riskLevel === 'CAUTION').length,
    highRiskMachines: machines.filter((m) => m.riskLevel === 'HIGH_RISK').length,
    criticalMachines: criticalCount,
    activeAlerts: alerts.filter((a) => a.status === 'ACTIVE').length,
    maintenanceRequired: machines.filter((m) => m.healthScore < 75 || m.maintenanceStatus === 'OVERDUE').length,
    predictedFailures: machines.filter((m) => m.healthScore < 60 || m.riskLevel === 'CRITICAL').length,
    averageHealth: factoryHealthObj.score,
    factoryAvailability: downtimeStats.fleetAvailabilityPercent,
  };

  return (
    <FactoryContext.Provider
      value={{
        machines,
        alerts,
        workers,
        workerNotifications,
        supervisorNotifications,
        escalationAuditLogs,
        maintenanceRecords,
        workAssignments,
        telemetryHistory,
        downtimeRecords,
        chatMessages,
        activeTab,
        setActiveTab,
        selectedMachineId,
        setSelectedMachineId,
        comparedMachineIds,
        setComparedMachineIds,
        toggleMachineComparison,
        escalationTimeoutSeconds,
        setEscalationTimeoutSeconds,
        acknowledgeAlertByRole,
        isSirenActive,
        isAudioMuted,
        isAudioUnlocked,
        enableAudio,
        stopSiren,
        toggleAudioMute,
        isSimulationRunning,
        simulationSpeed,
        setSimulationSpeed,
        toggleSimulation,
        resetFactoryToDefault,
        startMachine,
        stopMachine,
        simulateMachineOperation,
        updateMachineSafeCapacity,
        assignWork,
        redistributeWork,
        haltAndInspectMachine,
        triggerCriticalAlert,
        acknowledgeAlert,
        resolveAlert,
        getSmartWorkloadRecommendation,
        scheduleMaintenance,
        autoScheduleMaintenanceForRisk,
        rescheduleMaintenance,
        deleteMaintenanceTask,
        cancelMaintenance,
        completeMaintenance,
        startDowntime,
        resolveDowntime,
        downtimeStats,
        costAnalysis,
        askAIAssistant,
        isWorkerMobileOpen,
        setIsWorkerMobileOpen,
        currentMobileWorker,
        setCurrentMobileWorker,
        openWorkerNotification,
        acknowledgeWorkerNotification,
        acknowledgeAllWorkerNotifications,
        workerNotificationStats,
        fetchAIDiagnostics,
        generateExecutiveReport,
        toasts,
        showToast,
        dismissToast,
        userRole,
        setUserRole,
        stats,
      }}
    >
      {children}
    </FactoryContext.Provider>
  );
};

export const useFactory = (): FactoryContextType => {
  const context = useContext(FactoryContext);
  if (!context) {
    throw new Error('useFactory must be used within a FactoryProvider');
  }
  return context;
};

