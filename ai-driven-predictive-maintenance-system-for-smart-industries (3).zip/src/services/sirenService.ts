/**
 * Software Siren Simulation using browser Web Audio API
 * Generates an authentic industrial modulated siren sweep sound without external audio files.
 * Reuses a single audio context safely across React renders.
 */

type AudioStateCallback = (isPlaying: boolean, isMuted: boolean, isUnlocked: boolean) => void;

class SirenAudioEngine {
  private audioCtx: AudioContext | null = null;
  private primaryOsc: OscillatorNode | null = null;
  private secondaryOsc: OscillatorNode | null = null;
  private lfo: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private lfoGain: GainNode | null = null;
  private isPlaying = false;
  private isMuted = false;
  private isUnlocked = false;
  private volume = 0.28; // Authentic industrial tone volume
  private listeners: Set<AudioStateCallback> = new Set();

  public subscribe(cb: AudioStateCallback): () => void {
    this.listeners.add(cb);
    cb(this.isPlaying, this.isMuted, this.isUnlocked);
    return () => this.listeners.delete(cb);
  }

  private notifyListeners() {
    this.listeners.forEach((cb) => cb(this.isPlaying, this.isMuted, this.isUnlocked));
  }

  public initAudio(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.audioCtx) {
      const AudioContextClass =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        this.audioCtx = new AudioContextClass();
      }
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume().then(() => {
        this.isUnlocked = true;
        this.notifyListeners();
      }).catch(() => {});
    } else if (this.audioCtx && this.audioCtx.state === 'running') {
      this.isUnlocked = true;
      this.notifyListeners();
    }
    return this.audioCtx;
  }

  public enableAudio(): boolean {
    const ctx = this.initAudio();
    if (ctx) {
      if (ctx.state === 'suspended') {
        ctx.resume().then(() => {
          this.isUnlocked = true;
          this.playBeep(880, 0.08);
          this.notifyListeners();
        }).catch(() => {});
      } else {
        this.isUnlocked = true;
        this.playBeep(880, 0.08);
        this.notifyListeners();
      }
      return true;
    }
    return false;
  }

  public playBeep(freq = 880, duration = 0.1): void {
    if (this.isMuted) return;
    try {
      const ctx = this.initAudio();
      if (!ctx || ctx.state !== 'running') return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, ctx.currentTime);
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch {
      // Ignore audio error
    }
  }

  public playNotificationChime(): void {
    if (this.isMuted) return;
    try {
      const ctx = this.initAudio();
      if (!ctx || ctx.state !== 'running') return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, now); // D5
      osc.frequency.setValueAtTime(880.0, now + 0.1); // A5
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch {
      // Ignore chime error
    }
  }

  public startSiren(): boolean {
    if (this.isPlaying) return true;

    try {
      const ctx = this.initAudio();
      if (!ctx) return false;

      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }

      const now = ctx.currentTime;

      // Master Gain
      this.gainNode = ctx.createGain();
      this.gainNode.gain.setValueAtTime(this.isMuted ? 0 : this.volume, now);
      this.gainNode.connect(ctx.destination);

      // Primary Siren Oscillator (Carrier sawtooth 750 Hz)
      this.primaryOsc = ctx.createOscillator();
      this.primaryOsc.type = 'sawtooth';
      this.primaryOsc.frequency.setValueAtTime(750, now);

      // Secondary Harmonic Oscillator for authentic industrial resonance
      this.secondaryOsc = ctx.createOscillator();
      this.secondaryOsc.type = 'sine';
      this.secondaryOsc.frequency.setValueAtTime(1500, now);

      // LFO to modulate frequency between ~470 Hz and ~1030 Hz
      this.lfo = ctx.createOscillator();
      this.lfo.type = 'sine';
      this.lfo.frequency.setValueAtTime(0.85, now); // ~0.85 Hz siren oscillation period

      this.lfoGain = ctx.createGain();
      this.lfoGain.gain.setValueAtTime(280, now); // ±280 Hz sweep

      this.lfo.connect(this.lfoGain);
      this.lfoGain.connect(this.primaryOsc.frequency);
      this.lfoGain.connect(this.secondaryOsc.frequency);

      // Connect oscillators to master gain
      this.primaryOsc.connect(this.gainNode);
      this.secondaryOsc.connect(this.gainNode);

      // Start oscillators
      this.primaryOsc.start(now);
      this.secondaryOsc.start(now);
      this.lfo.start(now);

      this.isPlaying = true;
      this.notifyListeners();
      return true;
    } catch (err) {
      console.warn('Audio siren start failed (possibly waiting for user gesture):', err);
      this.isPlaying = false;
      this.notifyListeners();
      return false;
    }
  }

  public stopSiren(): void {
    if (!this.isPlaying) return;

    try {
      if (this.gainNode && this.audioCtx) {
        const now = this.audioCtx.currentTime;
        this.gainNode.gain.setValueAtTime(this.gainNode.gain.value, now);
        this.gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.12);
      }

      setTimeout(() => {
        try {
          this.primaryOsc?.stop();
          this.secondaryOsc?.stop();
          this.lfo?.stop();

          this.primaryOsc?.disconnect();
          this.secondaryOsc?.disconnect();
          this.lfo?.disconnect();
          this.gainNode?.disconnect();
          this.lfoGain?.disconnect();
        } catch {
          // Ignore teardown errors
        } finally {
          this.primaryOsc = null;
          this.secondaryOsc = null;
          this.lfo = null;
          this.gainNode = null;
          this.lfoGain = null;
          this.isPlaying = false;
          this.notifyListeners();
        }
      }, 130);
    } catch {
      this.isPlaying = false;
      this.notifyListeners();
    }
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (this.gainNode && this.audioCtx) {
      const now = this.audioCtx.currentTime;
      this.gainNode.gain.setValueAtTime(muted ? 0 : this.volume, now);
    }
    this.notifyListeners();
  }

  public setVolume(vol: number): void {
    this.volume = Math.max(0, Math.min(1, vol));
    if (this.gainNode && this.audioCtx && !this.isMuted) {
      const now = this.audioCtx.currentTime;
      this.gainNode.gain.setValueAtTime(this.volume, now);
    }
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getIsUnlocked(): boolean {
    return this.isUnlocked;
  }
}

export const sirenEngine = new SirenAudioEngine();
