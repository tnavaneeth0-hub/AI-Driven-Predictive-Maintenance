export type RiskLevel = 'SAFE' | 'NORMAL' | 'CAUTION' | 'HIGH_RISK' | 'CRITICAL';

export type AlertLevel =
  | 'LEVEL_1_INFO'
  | 'LEVEL_2_WARNING'
  | 'LEVEL_3_CRITICAL'
  | 'LEVEL_4_EMERGENCY';

export type MachineStatus =
  | 'STOPPED'
  | 'IDLE'
  | 'RUNNING'
  | 'WARNING'
  | 'OVERLOADED'
  | 'CRITICAL'
  | 'EMERGENCY'
  | 'MAINTENANCE';

export type PriorityLevel = 'NORMAL' | 'HIGH' | 'URGENT';

export type AlertType =
  | 'ASSIGNED_OVERLOAD'
  | 'UNASSIGNED_OPERATION'
  | 'CRITICAL_OVERLOAD'
  | 'MAINTENANCE_RISK'
  | 'CAPACITY_WARNING'
  | 'EMERGENCY_SHUTDOWN';

export interface ExplainabilityFactor {
  factor: string;
  percentage: number;
  description: string;
  category: 'WORKLOAD' | 'OVERLOADS' | 'UTILIZATION' | 'RUNTIME' | 'MAINTENANCE';
}

export interface Machine {
  id: string; // e.g. "M-01"
  code: string; // e.g. "MACHINE 01"
  name: string; // e.g. "CNC Milling Station Alpha"
  type: string; // e.g. "High-Precision 5-Axis Milling"
  safeHours: number; // Maximum safe operating capacity (e.g. 1.0)
  assignedHours: number; // Currently assigned work duration
  actualOperatingHours: number; // Continuous operating time in current shift
  currentOperatingHours: number; // Alias for actualOperatingHours
  totalOperatingHours: number; // Lifetime hours
  healthScore: number; // 0 - 100%
  riskScore: number; // 0 - 100%
  riskLevel: RiskLevel;
  status: MachineStatus;
  isEmergencyLocked?: boolean; // Locked when Level 4 Emergency until maintenance/reset
  estimatedRUL?: string; // e.g. "52 minutes" or "4.5 hours"
  rulHours?: number;
  maintenanceStatus: 'OPTIMAL' | 'UPCOMING' | 'OVERDUE' | 'IN_PROGRESS' | 'MAINTENANCE_REQUIRED';
  lastMaintenance: string;
  nextMaintenance: string;
  lastMaintenanceDate?: string;
  nextMaintenanceDue?: string;
  historicalOverloadCount: number;
  overloadEvents?: number;
  unassignedOperationCount: number;
  failureHistoryCount: number;
  temperature: number; // in Celsius (°C)
  vibration: number; // in mm/s RMS
  powerDraw: number; // in kW
  rpm: number; // Motor speed
  efficiency: number; // %
  location: string; // e.g. "Sector A - Bay 01"
  currentTaskName?: string;
  currentTaskPriority?: PriorityLevel;
}

export interface AlertItem {
  id: string; // e.g. "AL-001"
  machineId: string;
  machineName: string;
  machineCode: string;
  alertType: AlertType;
  alertLevel: AlertLevel;
  timestamp: string;
  workloadHours: number; // assigned hours or effective load
  assignedWorkHours: number;
  operatingHours: number; // actual operating time
  safeCapacityHours: number;
  workloadRatio: number; // e.g. 2.0 (200%)
  riskScore: number; // 0 - 100%
  riskLevel: RiskLevel;
  title: string;
  message: string;
  status: 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
  actionTaken?: string;
  workerNotificationCount: number;
  supervisorNotified?: boolean;
  adminNotified?: boolean;
  sirenTriggered: boolean;
  recommendedTargetMachineId?: string;
  aiExplanation?: string[];
  aiRecommendation?: string;
  contributingFactors?: ExplainabilityFactor[];
  resolvedAt?: string;

  // Alert Escalation Workflow Fields
  escalationStage?: 'WORKER_PENDING' | 'SUPERVISOR_NOTIFIED' | 'ADMIN_NOTIFIED' | 'RESOLVED_ACKNOWLEDGED';
  workerNotifiedAt?: string;
  workerAcknowledgedAt?: string;
  supervisorNotifiedAt?: string;
  supervisorAcknowledgedAt?: string;
  adminNotifiedAt?: string;
  adminAcknowledgedAt?: string;
  acknowledgedBy?: string;
  escalationTimerSeconds?: number;
  escalationDeadline?: number; // epoch ms
}

export interface Worker {
  id: string; // e.g. "W-01"
  name: string; // e.g. "Worker 01 - Lead Mech Tech"
  role: string; // e.g. "Senior Mechanical Technician"
  department: string;
  shift: string;
  status: 'ONLINE' | 'BUSY' | 'ON_DUTY';
  avatarInitials: string;
  deviceToken?: string;
  pushRegistered: boolean;
}

export interface WorkerNotification {
  id: string;
  alertId: string;
  workerId: string;
  workerName: string;
  role: string;
  machineCode: string;
  machineName: string;
  alertType: AlertType;
  alertLevel?: AlertLevel;
  message: string;
  priority: 'CRITICAL' | 'HIGH' | 'WARNING' | 'INFO';
  status: 'SENT' | 'DELIVERED' | 'READ' | 'ACKNOWLEDGED';
  sentAt: string;
  deliveredAt?: string;
  readAt?: string;
  acknowledgedAt?: string;
  recommendedAction?: string;
  riskPercent?: number;
  sirenTriggered?: boolean;
  triggeringMachineCode?: string;
}

export interface SupervisorNotification {
  id: string;
  alertId: string;
  machineId: string;
  machineCode: string;
  machineName: string;
  alertLevel: AlertLevel;
  riskLevel: RiskLevel;
  riskScore: number;
  workloadHours: number;
  safeCapacityHours: number;
  reason: string;
  recommendedMaintenanceAction: string;
  contributingFactors: string[];
  timestamp: string;
  status: 'ACTIVE' | 'ACKNOWLEDGED';
  acknowledgedAt?: string;
}

export interface EscalationAuditLog {
  id: string;
  alertId: string;
  machineCode: string;
  stage: 'WORKER_DISPATCH' | 'SUPERVISOR_ESCALATION' | 'ADMIN_CRITICAL_ESCALATION' | 'ACKNOWLEDGED' | 'RESOLVED';
  message: string;
  timestamp: string;
  actor: string;
  details: string;
}

export interface MaintenanceRecord {
  id: string;
  machineId: string;
  machineCode: string;
  machineName: string;
  type: 'PREVENTATIVE' | 'CORRECTIVE' | 'EMERGENCY_OVERHAUL' | 'INSPECTION';
  priority: PriorityLevel;
  scheduledDate: string;
  scheduledTime?: string;
  completedDate?: string;
  status: 'UPCOMING' | 'OVERDUE' | 'IN_PROGRESS' | 'COMPLETED';
  technicianName: string;
  problemDetected?: string;
  actionTaken?: string;
  notes: string;
  durationHours?: number;
  estimatedHours: number;
  nextRecommendedMaintenance?: string;
  partsReplaced?: string[];
  isAutoRecommended?: boolean;
  autoRecommendationTriggerRisk?: RiskLevel;
}

export interface WorkAssignment {
  id: string;
  machineId: string;
  machineCode: string;
  machineName: string;
  taskName: string;
  workType: string;
  durationHours: number;
  priority: PriorityLevel;
  assignedAt: string;
  expectedCompletionTime: string;
  status: 'ACTIVE' | 'COMPLETED' | 'REDISTRIBUTED' | 'CANCELLED';
  originalMachineId?: string;
}

export interface TelemetryPoint {
  timestamp: string;
  machineId: string;
  workloadRatio: number;
  healthScore: number;
  temperature: number;
  vibration: number;
  riskScore: number;
}

// Machine Ranking & Smart AI Recommendation
export interface MachineRankingItem {
  machine: Machine;
  score: number; // 0 - 100
  rank: number;
  recommendation: 'BEST CHOICE' | 'RECOMMENDED' | 'ACCEPTABLE' | 'NOT RECOMMENDED' | 'CRITICAL DANGER';
  badgeColor: string;
  availableCapacity: number;
  projectedUtilization: number;
  rulDisplay: string;
  reasons: string[];
  isEligible: boolean;
}

export interface SmartRecommendationResult {
  workloadHours: number;
  recommendedMachine: Machine;
  recommendationType: string;
  primaryReason: string;
  keyFactors: { label: string; value: string; positive: boolean }[];
  rankings: MachineRankingItem[];
  timestamp: string;
}

// Downtime Tracking
export interface DowntimeRecord {
  id: string;
  machineId: string;
  machineCode: string;
  machineName: string;
  startTime: string; // ISO
  endTime?: string; // ISO
  durationMinutes: number;
  reason: 'CRITICAL_OVERLOAD' | 'SCHEDULED_MAINTENANCE' | 'EMERGENCY_OVERHAUL' | 'MANUAL_INSPECTION' | 'THERMAL_TRIP';
  status: 'ACTIVE' | 'RESOLVED';
  estimatedCostLoss: number; // in INR
}

export interface DowntimeSummaryStats {
  activeDowntimeMachinesCount: number;
  currentActiveDowntimeMinutes: number;
  dailyDowntimeHours: number;
  weeklyDowntimeHours: number;
  monthlyDowntimeHours: number;
  totalFleetDowntimeHours: number;
  averageDowntimePerMachineHours: number;
  fleetAvailabilityPercent: number;
}

// Preventive vs Emergency Cost Analysis
export interface CostComparisonAnalysis {
  currency: string;
  preventiveUnitCost: number; // e.g. ₹2,000
  emergencyUnitCost: number; // e.g. ₹12,000
  preventiveTasksCompletedCount: number;
  emergencyOverhaulsAvoidedCount: number;
  actualPreventiveSpent: number;
  hypotheticalEmergencyCostAvoided: number;
  estimatedNetSavings: number;
  savingsPercentage: number;
  perMachineSavings: {
    machineId: string;
    machineCode: string;
    machineName: string;
    preventiveCount: number;
    avoidedFailures: number;
    savings: number;
  }[];
}

// AI Assistant Chat
export interface AssistantChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  suggestedPrompts?: string[];
  actionLink?: {
    tab: string;
    label: string;
    machineId?: string;
  };
  metricsReferenced?: {
    machineCode: string;
    metric: string;
    value: string | number;
  }[];
}

export type UserRole = 'ADMIN' | 'SUPERVISOR' | 'WORKER';

export type MobileScreen =
  | 'splash'
  | 'login'
  | 'dashboard'
  | 'emergency'
  | 'tasks'
  | 'alerts'
  | 'history'
  | 'profile'
  | 'settings';

export interface AIDiagnosticResult {
  source: string;
  explanation: string[];
  recommendation: string;
  mttfHours: string;
  estimatedRUL: string;
  failureRiskPercent: number;
  riskLevel: RiskLevel;
  alertLevel: AlertLevel;
  contributingFactors: ExplainabilityFactor[];
  loading?: boolean;
}

export interface WhatIfSimulationResult {
  machineId: string;
  machineCode: string;
  machineName: string;
  workloadHours: number;
  operatingHours: number;
  safeCapacity: number;
  predictedUtilization: number;
  predictedHealthScore: number;
  predictedRiskScore: number;
  predictedRiskLevel: RiskLevel;
  predictedAlertLevel: AlertLevel;
  predictedRUL: string;
  statusOutcome: 'SAFE' | 'WARNING' | 'CRITICAL' | 'EMERGENCY';
  recommendedAction: string;
  explainability: ExplainabilityFactor[];
  recommendedAlternativeId?: string;
}
