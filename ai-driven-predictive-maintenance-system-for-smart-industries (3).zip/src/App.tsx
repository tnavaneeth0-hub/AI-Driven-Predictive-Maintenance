/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { FactoryProvider, useFactory } from './context/FactoryContext';
import { Navbar } from './components/Navbar';
import { SirenBanner } from './components/SirenBanner';
import { WorkerMobileAppModal } from './components/WorkerMobileAppModal';
import { DashboardView } from './views/DashboardView';
import { MachinesView } from './views/MachinesView';
import { WorkAllocationView } from './views/WorkAllocationView';
import { PredictionsView } from './views/PredictionsView';
import { AlertsView } from './views/AlertsView';
import { WorkerAlertsView } from './views/WorkerAlertsView';
import { MaintenanceView } from './views/MaintenanceView';
import { AIAssistantView } from './views/AIAssistantView';
import { DowntimeCostView } from './views/DowntimeCostView';
import { HistoryView } from './views/HistoryView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';
import { ArchitectureDocsView } from './views/ArchitectureDocsView';
import { Radio, ShieldCheck, Cpu, CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

const AppContent: React.FC = () => {
  const { activeTab, toasts, dismissToast } = useFactory();

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardView />;
      case 'machines':
        return <MachinesView />;
      case 'work-allocation':
        return <WorkAllocationView />;
      case 'predictions':
        return <PredictionsView />;
      case 'alerts':
        return <AlertsView />;
      case 'worker-alerts':
        return <WorkerAlertsView />;
      case 'maintenance':
        return <MaintenanceView />;
      case 'ai-assistant':
        return <AIAssistantView />;
      case 'downtime-cost':
        return <DowntimeCostView />;
      case 'history':
        return <HistoryView />;
      case 'reports':
        return <ReportsView />;
      case 'architecture':
        return <ArchitectureDocsView />;
      case 'settings':
        return <SettingsView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div className="min-h-screen bg-[#08090a] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900/40 via-[#0d1015] to-[#08090a] text-slate-200 flex flex-col font-sans selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Siren Warning Banner (Web Audio Modulated Frequency) */}
      <SirenBanner />

      {/* Industrial Navigation Header */}
      <Navbar />

      {/* Main Command Center Body */}
      <main className="flex-1 w-full max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8 py-5">
        {renderActiveView()}
      </main>

      {/* Android Worker Mobile Companion App Modal */}
      <WorkerMobileAppModal />

      {/* Floating System Notification Toasts */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-md w-full pointer-events-none px-4 sm:px-0">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-xl border shadow-2xl flex items-start gap-3 transition-all duration-300 animate-in slide-in-from-bottom-5 ${
              toast.type === 'error'
                ? 'bg-red-950/90 border-red-500/60 text-red-100 shadow-red-950/50'
                : toast.type === 'warning'
                ? 'bg-amber-950/90 border-amber-500/60 text-amber-100 shadow-amber-950/50'
                : toast.type === 'success'
                ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-100 shadow-emerald-950/50'
                : 'bg-slate-900/90 border-cyan-500/60 text-cyan-100 shadow-cyan-950/50'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
            ) : toast.type === 'warning' ? (
              <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            ) : toast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <Info className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            )}

            <div className="flex-1 text-xs">
              <span className="font-semibold block">{toast.text}</span>
            </div>

            <button
              onClick={() => dismissToast(toast.id)}
              className="text-slate-400 hover:text-white p-0.5 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {/* Industrial Platform Footer */}
      <footer className="border-t border-white/5 bg-[#050607] py-4 text-xs text-slate-500">
        <div className="w-full max-w-[1850px] mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full indicator-green" />
            <span className="text-slate-400 font-medium">Factory Telemetry Grid: 10 Nodes Connected</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <FactoryProvider>
      <AppContent />
    </FactoryProvider>
  );
}
